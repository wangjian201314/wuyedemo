//
//  UIView+returnVC.h
//  UI12-task03-响应者连
//
//  Created by wangjin on 15/11/17.
//  Copyright (c) 2015年 wangjin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (returnVC)

-(UIViewController *)returnVC;

@end
