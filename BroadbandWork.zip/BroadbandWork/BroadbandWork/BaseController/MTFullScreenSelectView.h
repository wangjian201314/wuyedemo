//
//  MTFullScreenSelectView.h
//  GDWWNOP
//
//  Created by kingste on 2018/1/29.
//  Copyright © 2018年 cn.mastercom. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^doneClickBlock)(NSArray * selecteds);

typedef enum{
    MTFullScreenSelectViewStyleSingle = 0,
    MTFullScreenSelectViewStyleMulti
}MTFullScreenSelectViewStyle;

@interface MTFullScreenSelectView : UIView

/**
 多选框实例化(全屏,模拟push)

 @param title 标题
 @param selectedbuttons 已选对象
 @param buttons 可选对象
 @param clickBlock <#clickBlock description#>
 @return void
 */
-(instancetype)initWithStyle:(MTFullScreenSelectViewStyle)style title:(NSString *)title selectedbuttons:(NSArray*)selectedbuttons buttons:(NSArray*)buttons clickBlock:(doneClickBlock)clickBlock;


-(void)show;

@end
