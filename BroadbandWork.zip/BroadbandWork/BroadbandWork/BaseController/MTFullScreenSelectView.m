//
//  MTFullScreenSelectView.m
//  GDWWNOP
//
//  Created by kingste on 2018/1/29.
//  Copyright © 2018年 cn.mastercom. All rights reserved.
//

#define NAVIBARHEIGHT 44
#define THEMECOLOR #

#import "MTFullScreenSelectView.h"

@interface MTFullScreenSelectView() <UITableViewDataSource,UITableViewDelegate> {
    
    MTFullScreenSelectViewStyle _style;
    
    /** navi */
    UIView      * _navibarView;
    UILabel     * _titleLabel;
    UIButton    * _leftButton;
    UIButton    * _rightButton;
    UITableView * _tableView;
    
    
    /** data */
    doneClickBlock _doneClickBlock;
    NSMutableArray * _selectArray;
    NSMutableArray * _array;
    
    
}

@end


@implementation MTFullScreenSelectView

#pragma mark - LifeCycle
-(instancetype)initWithStyle:(MTFullScreenSelectViewStyle)style title:(NSString *)title selectedbuttons:(NSArray*)selectedbuttons buttons:(NSArray*)buttons clickBlock:(doneClickBlock)clickBlock {
    
    
    _selectArray = [[NSMutableArray alloc]init];
    _array = [[NSMutableArray alloc]init];
    
    [_selectArray addObjectsFromArray:selectedbuttons?selectedbuttons:@[]];
    [_array addObjectsFromArray:buttons?buttons:@[]];
    _style = style;
    
    //init
    CGRect rect = [UIScreen mainScreen].bounds;
    
    CGFloat statusBarHeight = [UIApplication sharedApplication].statusBarFrame.size.height;
    rect = CGRectMake(rect.origin.x, rect.origin.y, rect.size.width, rect.size.height);
    CGFloat width = rect.size.width;
    CGFloat space = 10;
    
    self = [super initWithFrame:rect];
    self.backgroundColor = [UIColor colorWithHexString:@"#0085CE"];
    
    
    _doneClickBlock = clickBlock;
    
    //navi
    UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, statusBarHeight, width, NAVIBARHEIGHT)];
    view.backgroundColor = [UIColor clearColor];
    [self addSubview:view];
    _navibarView = view;
    
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(space, 0, NAVIBARHEIGHT, NAVIBARHEIGHT);
//    NSBundle *bdl   = [MTGlobalInfo sharedInstance].commBundle;
//    UIImage * icon  = [UIImage imageNamed:@"btn_back_normal" bundle:bdl];
    [button setImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(leftButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:button];
    _leftButton = button;
    
    button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(width-NAVIBARHEIGHT-space, 0, NAVIBARHEIGHT, NAVIBARHEIGHT);
    button.titleLabel.font = [UIFont systemFontOfSize:14];
    [button setTitle:@"确定" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(rightButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    if (style == MTFullScreenSelectViewStyleMulti) {
        [view addSubview:button];
    }
    _rightButton = button;
    
    UILabel * label = [[UILabel alloc]init];
    label.frame = CGRectMake(NAVIBARHEIGHT+space, 0, width-2*(NAVIBARHEIGHT+space), NAVIBARHEIGHT);
    label.font = [UIFont systemFontOfSize:16];
    label.textColor = [UIColor whiteColor];
    label.numberOfLines = 0;
    label.textAlignment = NSTextAlignmentCenter;
    label.text = title;
    [view addSubview:label];
    _titleLabel = label;
    
    //tableView
    UITableView * tableView = [[UITableView alloc]init];
    tableView.frame = CGRectMake(0, CGRectGetMaxY(view.frame), width, rect.size.height-NAVIBARHEIGHT-statusBarHeight);
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.delegate = self;
    tableView.dataSource = self;
    [self addSubview:tableView];
    _tableView = tableView;
    
    return self;
}

#pragma mark - Actions
- (void)show {
    
    UIWindow * window = [UIApplication sharedApplication].keyWindow;
    CGRect rect = self.frame;
    CGRect startRect = CGRectMake(rect.size.width, rect.origin.y, rect.size.width, rect.size.height);
    self.frame = startRect;
    
    [window addSubview:self];
    
    [UIView animateWithDuration:0.2 animations:^{
        CGRect rect = self.frame;
        self.frame = CGRectMake(0, rect.origin.y, rect.size.width, rect.size.height);
    }];
}

- (void)dismiss {
    CGRect rect = self.frame;
    CGRect startRect = CGRectMake(0, rect.origin.y, rect.size.width, rect.size.height);
    self.frame = startRect;
    
    
    [UIView animateWithDuration:0.2 animations:^{
        CGRect rect = self.frame;
        self.frame = CGRectMake(rect.size.width, rect.origin.y, rect.size.width, rect.size.height);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}

- (void)leftButtonClick:(UIButton *)button {
    [self dismiss];
}

- (void)rightButtonClick:(UIButton *)button {
    if (_doneClickBlock) {
        NSMutableArray * resultArray = [[NSMutableArray alloc]init];
        for (id item in _array) {
            NSString * str = [NSString stringWithFormat:@"%@",item];
            if ([_selectArray containsObject:str]) {
                [resultArray addObject:item];
            }
        }
        _doneClickBlock(resultArray);
    }
    [self dismiss];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (_style == MTFullScreenSelectViewStyleMulti) {
        id object = _array[indexPath.row];
        NSString * str = [NSString stringWithFormat:@"%@",object];
        if ([_selectArray containsObject:str]) {
            [_selectArray removeObject:str];
        }else{
            [_selectArray addObject:str];
        }
        [_tableView reloadData];
    }else if (_style == MTFullScreenSelectViewStyleSingle) {
        
        id object = _array[indexPath.row];
        _selectArray = [@[[NSString stringWithFormat:@"%@",object]] mutableCopy];
        [_tableView reloadData];
        
        if (_doneClickBlock) {
            _doneClickBlock(@[object]);
        }
        [self dismiss];
    }
}

#pragma mark - UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _array.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * reuseID = @"cell";
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:reuseID];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseID];
        cell.textLabel.font = [UIFont systemFontOfSize:14];
        cell.textLabel.numberOfLines = 0;
        
        //grayline
        UIView * grayLine = [[UIView alloc]init];
        grayLine.backgroundColor = [UIColor lightGrayColor];
        [cell addSubview:grayLine];
        grayLine.translatesAutoresizingMaskIntoConstraints = NO;
        [cell addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"H:|-15-[grayLine]-0-|"] options:0 metrics:nil views:NSDictionaryOfVariableBindings(grayLine)]];
        [cell addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"V:[grayLine(0.5)]-0-|"] options:0 metrics:nil views:NSDictionaryOfVariableBindings(grayLine)]];
    }
    
    //data
    id object = _array[indexPath.row];
    NSString * str = [NSString stringWithFormat:@"%@",object];
    
    
    cell.textLabel.text = str;
    
    if ([_selectArray containsObject:str]) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }else{
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    return cell;
}


#pragma mark - Other
-(void)dealloc {
    DLog(@"%s",__func__);
}


/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */


@end
