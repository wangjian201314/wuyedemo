//
//  SCUser.h
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/3.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^handler)(NSArray * array);



@interface SCUser : NSObject

+ (NSDictionary *)currentUserInfo;
+ (void)saveCurrentUserInfo:(NSDictionary *)dict;
+ (BOOL)ismanager;
+ (BOOL)isLagerManager;


//分公司枚举
+ (NSArray *)getCompanysName;
//公司枚举
+ (NSArray *)compsNames:(NSString *)name;
//部门枚举
+ (NSArray *)comNames:(NSString *)name;
//专业室枚举
+ (NSArray *)zysNames:(NSString *)name;
//项目枚举
+ (NSArray *)xmNames;

@end
