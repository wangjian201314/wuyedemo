//
//  SCUser.m
//  SCATTENDANCE
//
//  Created by kingste on 2018/4/3.
//  Copyright © 2018年 MasterCom. All rights reserved.
//

#import "SCUser.h"

static NSString * currentUserInfoGlobalKey = @"currentUser";

static NSString * companyName   = @"分公司枚举";
static NSString * compName      = @"公司枚举";
static NSString * comName       = @"部门枚举";
static NSString * zysName       = @"专业室枚举";
static NSString * xmName        = @"项目枚举";

@implementation SCUser











@end
