//
//  JXTempMainViewCell.h
//  JXWWNOP
//
//  Created by kingste on 2017/7/13.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface JXTempMainViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *label0;
@property (weak, nonatomic) IBOutlet UILabel *label1;
@property (weak, nonatomic) IBOutlet UIImageView *imgView;
@property (weak, nonatomic) IBOutlet UILabel *detailLb;
@property (weak, nonatomic) IBOutlet UILabel *bottomlb;


@end
