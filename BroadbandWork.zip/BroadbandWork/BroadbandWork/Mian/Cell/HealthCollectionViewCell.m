//
//  HealthCollectionViewCell.m
//  Health
//
//  Created by Mac on 2019/5/22.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "HealthCollectionViewCell.h"

@implementation HealthCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
