//
//  JXEomsCompleteViewController.h
//  JXWWNOP
//
//  Created by wangjian on 2018/4/8.
//  Copyright © 2018年 cn.mastercom. All rights reserved.
//

#import "MTBaseViewController.h"
#import "JXEomsReplyViewController.h"


@interface JXEomsReplyViewController : MTBaseViewController<UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate>

@property (nonatomic ,strong) UITableView  *orderTableView;

@property (nonatomic ,strong) NSDictionary  *leftAllDataDic; //工单详情全部的内容

@property (nonatomic ,strong) NSMutableDictionary  *allDataDic; //工单列表的信息+工单详情全部的内容

@property (nonatomic ,copy)   NSString *taskId;

@property (nonatomic ,copy)   NSString *sheetId;

@property (nonatomic ,copy)   NSString *mainId;//

@property (nonatomic ,strong) NSString *operateType;//获取提交信息用，92:驳回调度台;93:转派代维人员;23:代维接单;25:代维回单;56:质检失败;55:质检成功

@property (nonatomic ,strong) NSString  *orderOperation;  //工单操作(转派、驳回，..)

@property (nonatomic ,strong) NSString  *orderType; //功能类型 (装机工单、投诉工单、拆机工单,..)

@property (nonatomic ,strong) NSDictionary *showParam; //需要呈现的数据

@property (nonatomic ,copy)   NSString  * navTitle;

@property (nonatomic,strong)  NSDictionary *judgedict;            //swicth判断

@property (nonatomic,strong) NSString *ordersection;//工单环节

@property (nonatomic,strong) NSString *COMPLAINTTYPEDICT;

@property (nonatomic,strong)NSArray *datas;
@end
