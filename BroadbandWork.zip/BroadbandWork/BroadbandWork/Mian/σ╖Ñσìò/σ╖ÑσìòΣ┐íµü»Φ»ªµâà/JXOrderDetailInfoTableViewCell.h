//
//  JXOrderDetailInfoTableViewCell.h
//  JXWWNOP
//
//  Created by hqf on 2017/6/26.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, JXOrderDetailInfoCellType) {
    JXOrderDetailInfoCellTypeNormal,
    JXOrderDetailInfoCellTypePhone,
    JXOrderDetailInfoCellTypeShortText,
    JXOrderDetailInfoCellTypeLongText,
    JXOrderDetailInfoCellTypePhoto,
    JXOrderDetailInfoCellTypeJumpFiber//路由跳转信息
    
};

@protocol DetailBtnEditDelegate<NSObject>

- (void)editbtn;

@end

@interface JXOrderDetailInfoTableViewCell : UITableViewCell

@property (nonatomic, weak)id <DetailBtnEditDelegate>delegate;
@property (weak, nonatomic) IBOutlet UIButton *Editbtn;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *TextlbLeading;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *BtnWidths;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *BtnHeight;
@property (nonatomic,strong)NSMutableArray *jumpFiberInfo;//特殊，路由信息
@property (strong, nonatomic) NSString *orderType;   //工单类型

- (void)refreshUI:(NSString *)title content:(NSString *)content status:(JXOrderDetailInfoCellType)status;

@end
