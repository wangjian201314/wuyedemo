//
//  JXOrderDetailViewController.h
//  JXWWNOP
//
//  Created by hqf on 2017/6/22.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//

#import "MTBaseViewController.h"

@interface JXEOMSDetailViewController : MTBaseViewController<UIAlertViewDelegate>


@property (weak, nonatomic) IBOutlet NSLayoutConstraint *scrollContentViewConstraints;

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UILabel *orderInfoLabel;
@property (weak, nonatomic) IBOutlet UILabel *orderCirculationLabel;


@property (weak, nonatomic) IBOutlet UITableView *leftOrderTableView;
@property (weak, nonatomic) IBOutlet UITableView *rightTableView;


@property (weak, nonatomic) IBOutlet UIView *topViewLine; //顶部视图的下划线
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topViewLineWidthConstraints;
@property (weak, nonatomic) IBOutlet UIView *bottomView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomViewHeightConstraints;



@property (strong, nonatomic) NSString *orderType;   //工单类型
@property (strong, nonatomic) NSString *orderSection;   //工单环节

//@property (strong, nonatomic) NSString *operaType;
@property (copy, nonatomic) NSMutableDictionary *dataDic;

@property (copy, nonatomic) NSString *taskId;//_TKI: 以这个字符开头的任务id
@property (copy, nonatomic) NSString *sheetId;//_TKI:
@property (copy, nonatomic) NSString *mainId;
@property (nonatomic,assign)Boolean isShowToolBtn;




@property (nonatomic ,strong) NSString  *funcType;
@property (nonatomic,strong)NSArray *leftdata;
@property (nonatomic,strong)NSDictionary *dict;

@end
