//
//  JXToolBtnView.h
//  JXWWNOP
//
//  Created by hqf on 2017/6/23.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol JXOrderToolBtnDelegate <NSObject>

- (void)didSelectedOrderToolbtn:(NSString *)title;

@end

@interface JXToolBtnView : UIView<UIAlertViewDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *imgView;
@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet UIView *touchView;

@property (nonatomic ,strong) NSArray  *model;
@property (nonatomic ,strong) NSString  *orderType;//工单类型
@property (nonatomic ,strong) NSString  *orderSction;//工单环节
@property (nonatomic ,strong) NSString  *funcType;
@property (nonatomic ,strong) NSArray  *contents;
@property (nonatomic ,strong) NSDictionary  *leftAllDataDic;
@property (nonatomic ,strong) NSArray  *rightAllDataDic;
@property (nonatomic ,strong) NSMutableDictionary  *allDataDic;
@property (nonatomic ,strong) NSDictionary  *backInfoDic; //驳回的工单回填的全部信息，质检（装机/拆机/投诉）驳回时，信息要回弹

@property (nonatomic ,strong) NSString *backInfoType;//驳回单的类型

@property (nonatomic, strong) NSString *COMPLAINTTYPEDICT;
@property (nonatomic, strong) NSString *COMPLAINTTYPEDICT4;//投诉分类四级

@property (nonatomic ,copy) NSString  *taskId;//工单类型

@property (nonatomic ,copy) NSString  *sheetId;//工单流水号

@property (nonatomic ,copy) NSString  *mainId;//工单

@property (nonatomic, copy)NSString  * mainPbossOrderType;//定单类型

@property (nonatomic,strong) NSDictionary *judgedict;//swwitch判断

@property (copy, nonatomic) NSDictionary *dataDic;

@property (nonatomic,strong)NSArray *datas;

+ (JXToolBtnView *)initViewWithXib ;

@property (nonatomic, assign)id<JXOrderToolBtnDelegate>delegate;
@end
