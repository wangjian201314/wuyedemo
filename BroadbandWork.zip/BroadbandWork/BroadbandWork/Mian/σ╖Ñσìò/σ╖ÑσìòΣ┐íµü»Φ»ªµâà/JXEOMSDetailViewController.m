//
//  JXOrderDetailViewController.m
//  JXWWNOP
//
//  Created by hqf on 2017/6/22.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//
#import "HBTitleView.h"
#import "JXEOMSDetailViewController.h"
#import "JXOrderDetailInfoTableViewCell.h"
#import "JXEomsDetailCirculationTableViewCell.h"
#import "UIToastView.h"
#import "JXToolBtnView.h"

#define kViewCount 2
#define isnull(key,dict) dict[key] == nil || [dict[key] isKindOfClass:[NSNull class]] ? @"" : dict[key]

@interface JXEOMSDetailViewController ()<UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate,JXOrderToolBtnDelegate> {
    NSMutableArray *_leftColumnSource;
    NSMutableArray *_leftDataSource;
    NSMutableArray *_rightColumns;
    NSMutableArray *_rightDataSource;
    
    NSMutableDictionary *_leftAllDataDic;
    NSMutableDictionary *_allDataDic;
     NSArray *_operateTypeList;//底部按钮显示标识
    
    NSArray *_sectionSource;
    NSMutableArray *_showRowSource;//显示用
    NSMutableArray *_rowSource;
    NSMutableDictionary *_judgedict;            //swicth判断
    
    NSMutableArray *_routeInfoArr;//路由信息
    
    int curentPage;
    NSString *phoneNumber;
    
    
    NSMutableDictionary *_finalUploadDict;//最终提交的数据
    
    NSDictionary *_sheetMainDict;
    NSDictionary *_sheetLinkDict;
    NSDictionary *_preLinkDict;
    NSDictionary *_backInfoDict;//驳回单的信息
    NSString *_backInfoType;//驳回单的类型
    NSDictionary *_taskDict;
    NSString *_operateType;
    
    
    NSDictionary *_dealMainDict; //工单受理后查询到的概要信息；
    NSDictionary *_dealDetailDict;//工单受理后查询到的信息信息；

    NSString *_opType;//工单详情opType类型
    NSString *_opTypeHistory;//历史流转optype
    NSString *_COMPLAINTTYPEDICT;//投诉分类三级分类
    NSString *_COMPLAINTTYPEDICT4;//投诉分类四级分类
    JXToolBtnView *_btnView;
}

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *leftTableviewWidth;
@property (strong, nonatomic) HBTitleView *hbTitleView;//top
@property (weak, nonatomic) IBOutlet UIView *topView;


@end

@implementation JXEOMSDetailViewController

- (instancetype) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        _dataDic = [[NSMutableDictionary alloc] init];
        
        _leftDataSource = [[NSMutableArray alloc] init];
        _rightDataSource = [[NSMutableArray alloc] init];
        _leftColumnSource = [[NSMutableArray alloc] init];
        _rightColumns = [[NSMutableArray alloc] init];
        
        _leftAllDataDic = [[NSMutableDictionary alloc] init];
        
        _finalUploadDict = [[NSMutableDictionary alloc]init];
        _sheetMainDict = [[NSDictionary alloc]init];
        _sheetLinkDict = [[NSDictionary alloc]init];
        
        _dealDetailDict = [[NSDictionary alloc]init];
        _dealMainDict = [[NSDictionary alloc]init];
        _judgedict=[[NSMutableDictionary alloc]init];
        curentPage = 0;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setNaviTitle:@"工单详情" leftButtonShow:YES rightButtom:nil];
    [SVProgressHUD showWithStatus:@"正在加载..."];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        [self formData];
        [self createUI];
        [self initToolBtnView];
    });
    
   
}


- (void)addItem:(NSMutableArray *) sourceArr showArr:(NSMutableArray *)showArr withShowStr:(NSString *)showStr withKey:(NSString *)key withArrIndex:(NSInteger )index {
    if ([sourceArr count]<=index) {
        NSMutableArray *tempArr = [[NSMutableArray alloc]init];
        [sourceArr addObject:tempArr];
    }
    if ([showArr count]<=index) {
        NSMutableArray *tempArr = [[NSMutableArray alloc]init];
        [showArr addObject:tempArr];
    }
    
    [sourceArr[index] addObject:key];
    [showArr[index] addObject:showStr];
}

- (void)initToolBtnView {
    
    NSMutableArray *buttonInfo = [[NSMutableArray alloc] init];
    NSString *ordertype= isnull(@"step", _dict);
    [buttonInfo addObject:@[ordertype,@"ic_datainit_normal.png"]];

    [self createButtonWithInfo:buttonInfo];
    
}
- (void)createButtonWithInfo:(NSArray *)buttonInfo {
    
    //如果有则新移除_btnView
    NSArray *subViewArr = [self.view subviews];
    for(NSInteger i =0;i<subViewArr.count;i++) {
        UIView *subview = subViewArr[i];
        if ([subview isKindOfClass:[JXToolBtnView class]]) {
            [subview removeFromSuperview];
        }
    }
    
    
    if(buttonInfo == nil || [buttonInfo count] ==0 )  {
        _bottomViewHeightConstraints.constant = 0;
        return;
    }
    
    NSMutableArray *contents = [NSMutableArray new];
    
    
    NSInteger btnCount = [buttonInfo count];
    float btnWidth = kScreenW / (btnCount*1.f) - 2;
    
    
    
    _bottomViewHeightConstraints.constant = 45+(MTIPhoneX?20:0);
    for (int i = 0 ; i < [buttonInfo count]; i ++) {
        NSArray *oneBtnInfo = [buttonInfo objectAtIndex:i];
        _btnView = [JXToolBtnView initViewWithXib];
        _btnView.delegate = self;
        _btnView.frame = CGRectMake(i * (btnWidth+1), 1, btnWidth, 44+(MTIPhoneX?20:0));
        _btnView.model = oneBtnInfo;
        _btnView.orderType = _orderType;
        _btnView.orderSction = _orderSection;
        //            btnView.FTTX = _FTTX;
        _btnView.contents = contents;
        _btnView.funcType = _funcType;
        _btnView.leftAllDataDic = _leftAllDataDic;
        _btnView.allDataDic = _allDataDic;
        _btnView.backInfoDic = _backInfoDict;
        _btnView.backInfoType = _backInfoType;
        _btnView.taskId = _taskId;
        _btnView.sheetId=_sheetId;
        _btnView.mainId=_mainId;
        _btnView.judgedict=_judgedict;
        _btnView.dataDic=_dataDic;
        _btnView.datas=_leftdata;
        _btnView.COMPLAINTTYPEDICT=_COMPLAINTTYPEDICT;
        _btnView.COMPLAINTTYPEDICT4=_COMPLAINTTYPEDICT4;
        [_bottomView addSubview:_btnView];
    }
    
}

- (void)formData {
    //工单类型  PnrFamilyBackOut 拆机,PnrFamilyBroadband 装机,PnrFamilyBespeak,预约,PnrFamilyComplaint 投诉
    _rowSource = [[NSMutableArray alloc] init];
    _showRowSource = [[NSMutableArray alloc] init];
    //装机
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"标题" withKey:@"TITLE" withArrIndex:0];
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"工单流水号" withKey:@"SHEETID" withArrIndex:0];
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"工单状态" withKey:@"STATUS" withArrIndex:0];
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"操作人" withKey:@"SENDUSERNAME" withArrIndex:0];
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"操作时间" withKey:@"SENDTIME" withArrIndex:0];
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"操作部门" withKey:@"SENDDEPTNAME" withArrIndex:0];
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"操作人所属角色" withKey:@"SENDROLENAME" withArrIndex:0];
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"操作人联系方式" withKey:@"SENDCONTACT" withArrIndex:0];
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"派发联系人" withKey:@"BTYPE1" withArrIndex:0];
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"派发联系人电话" withKey:@"BDEPTCONTACT" withArrIndex:0];
    
    if([_orderType isEqualToString:@"装机工单"]){
        [_rightDataSource addObjectsFromArray:@[@{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"李工",
                                                  @"OPERATETIME":@"2019-05-30",
                                                  @"ACTIVETASKNAME":@"",
                                                  },
                                                @{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"维修人员",
                                                  @"OPERATEDEPTID":@"张师傅",
                                                  @"OPERATETIME":@"2019-05-31",
                                                  @"ACTIVETASKNAME":@"",
                                                  },
                                                @{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"肖师傅",
                                                  @"OPERATETIME":@"2019-06-01",
                                                  @"ACTIVETASKNAME":@"cc",
                                                  }]];
    }
   else if([_orderType isEqualToString:@"投诉工单"]) {
        _opType=@"jx_op105";
        _opTypeHistory=@"jx_op106";
        
       
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"投诉时间" withKey:@"COMPLAINTTIME" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障时间" withKey:@"FAULTTIME" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"受理时限" withKey:@"SHEETACCEPTLIMIT" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"处理时限" withKey:@"SHEETCOMPLETELIMIT" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"紧急程度" withKey:@"URGENTDEGREE" withArrIndex:0];
        [_rightDataSource addObjectsFromArray:@[@{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"装机人员",
                                                  @"OPERATEDEPTID":@"李工",
                                                  @"OPERATETIME":@"2019-05-12",
                                                  @"ACTIVETASKNAME":@"DraftHumTask",
                                                  },
                                                @{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"杨工",
                                                  @"OPERATETIME":@"2019-05-15",
                                                  @"ACTIVETASKNAME":@"FirstExcuteHumTask",
                                                  },
                                                @{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"周工",
                                                  @"OPERATETIME":@"2019-05-30",
                                                  @"ACTIVETASKNAME":@"HoldHumTask",
                                                  }]];
        

        
    }
    //拆机
    else if([_orderType isEqualToString:@"故障工单"]) {
        
        _opType=@"jx_op206";
        _opTypeHistory=@"jx_op207";

        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障区县" withKey:@"MAINFAULTGENERANTCITYSUBCODE" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"设备厂家" withKey:@"mainLinkmanNumbers2" withArrIndex:0];//
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障设备厂家" withKey:@"MAINEQUIPMENTFACTORY" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障设备型号" withKey:@"MAINEQUIPMENTMODEL" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障发现方式" withKey:@"MAINFAULTDISCOVERABLEMODE" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"告警唯一标识" withKey:@"ALARMID" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"工单处理优先级计算详情" withKey:@"mainOLTIP" withArrIndex:0];
        [_rightDataSource addObjectsFromArray:@[@{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"王工",
                                                  @"OPERATETIME":@"2019-05-17",
                                                  @"ACTIVETASKNAME":@"DraftHumTask",
                                                  },
                                                @{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"李工",
                                                  @"OPERATETIME":@"2019-05-20",
                                                  @"ACTIVETASKNAME":@"SecondExcuteHumTask",
                                                  },
                                                @{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"李工",
                                                  @"OPERATETIME":@"2019-05-22",
                                                  @"ACTIVETASKNAME":@"HoldHumTask",
                                                  }]];
    
        
    }else if ([_orderType isEqualToString:@"拆机工单"]){
        
        _opType=@"jx_op305";
        _opTypeHistory=@"jx_op304";

        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"任务描述" withKey:@"MAINTASKDESCRIPTION" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"任务类型" withKey:@"MAINTASKTYPEF" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"受理时限" withKey:@"NODEACCEPTLIMIT" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"处理时限" withKey:@"NODECOMPLETELIMIT" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"备注" withKey:@"MAINREMARK" withArrIndex:0];
        [_rightDataSource addObjectsFromArray:@[@{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"李工",
                                                  @"OPERATETIME":@"2019-05-20",
                                                  @"ACTIVETASKNAME":@"",
                                                  },
                                                @{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"李工",
                                                  @"OPERATETIME":@"2019-05-30",
                                                  @"ACTIVETASKNAME":@"",
                                                  },
                                                @{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"李工",
                                                  @"OPERATETIME":@"2019-05-31",
                                                  @"ACTIVETASKNAME":@"cc",
                                                  }]];
        
    }else if ([_orderType isEqualToString:@"预约工单"]){
        
        _opType=@"jx_op403";
        _opTypeHistory=@"jx_op305";
        
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障区县" withKey:@"MAINFAULTGENERANTCITYSUBCODE" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障设备厂家" withKey:@"MAINEQUIPMENTFACTORYF" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障设备型号" withKey:@"MAINEQUIPMENTMODEL" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障发现方式" withKey:@"MAINFAULTDISCOVERABLEMODEF" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障发生时间" withKey:@"MAINFAULTGENERANTTIME" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"是否影响业务" withKey:@"MAINIFAFFECTOPERATIONF" withArrIndex:0];
        [_rightDataSource addObjectsFromArray:@[@{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"小工",
                                                  @"OPERATETIME":@"2019-05-20",
                                                  @"ACTIVETASKNAME":@"",
                                                  },
                                                @{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"李工",
                                                  @"OPERATETIME":@"2019-05-26",
                                                  @"ACTIVETASKNAME":@"",
                                                  },
                                                @{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"李工",
                                                  @"OPERATETIME":@"2019-05-29",
                                                  @"ACTIVETASKNAME":@"reply",
                                                  }]];
        
    }else if ([_orderType isEqualToString:@"跳纤工单"]){
        
        _opType=@"jx_op403";
        _opTypeHistory=@"jx_op305";
        
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障区县" withKey:@"MAINFAULTGENERANTCITYSUBCODE" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障设备厂家" withKey:@"MAINEQUIPMENTFACTORYF" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障设备型号" withKey:@"MAINEQUIPMENTMODEL" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障发现方式" withKey:@"MAINFAULTDISCOVERABLEMODEF" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障发生时间" withKey:@"MAINFAULTGENERANTTIME" withArrIndex:0];
        [self addItem:_rowSource showArr:_showRowSource withShowStr:@"是否影响业务" withKey:@"MAINIFAFFECTOPERATIONF" withArrIndex:0];
        [_rightDataSource addObjectsFromArray:@[@{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"李工",
                                                  @"OPERATETIME":@"2019-05-22",
                                                  @"ACTIVETASKNAME":@"",
                                                  },
                                                @{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"李工",
                                                  @"OPERATETIME":@"2019-05-24",
                                                  @"ACTIVETASKNAME":@"",
                                                  },
                                                @{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"李工",
                                                  @"OPERATETIME":@"2019-05-28",
                                                  @"ACTIVETASKNAME":@"cc",
                                                  }]];
        
    }else if ([_orderType isEqualToString:@"勘察工单"] || [_orderType isEqualToString:@"宽带配置工单"]){
    
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"工单处理时限" withKey:@"NODECOMPLETELIMIT" withArrIndex:0];
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"T1处理时限" withKey:@"MAINCOMPLETELIMITT1" withArrIndex:0];
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"T2处理时限" withKey:@"MAINCOMPLETELIMITT2" withArrIndex:0];
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"T3处理时限" withKey:@"MAINCOMPLETELIMITT3" withArrIndex:0];
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"网元名称" withKey:@"MAINNETNAME" withArrIndex:0];
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障省份" withKey:@"MAINAFFECTAREA" withArrIndex:0];
    [self addItem:_rowSource showArr:_showRowSource withShowStr:@"故障地市" withKey:@"TODEPTID" withArrIndex:0];
        
        [_rightDataSource addObjectsFromArray:@[@{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"zhang",
                                                  @"OPERATETIME":@"2019-05-30",
                                                  @"ACTIVETASKNAME":@"",
                                                  },
                                                @{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"西工",
                                                  @"OPERATETIME":@"2019-05-30",
                                                  @"ACTIVETASKNAME":@"",
                                                  },
                                                @{@"OPERATETYPE":@"小区住户303",
                                                  @"OPERATEUSERID":@"代维人员",
                                                  @"OPERATEDEPTID":@"五工",
                                                  @"OPERATETIME":@"2019-05-30",
                                                  @"ACTIVETASKNAME":@"",
                                                  }]];
    }
}

- (HBTitleView *)hbTitleView
{
    if (_hbTitleView == nil)
    {
        CGRect titleViewBounds = _topView.bounds;
        titleViewBounds.size.width = kScWidth;
        
        _hbTitleView = [[HBTitleView alloc]initWithFrame:titleViewBounds andTitles:@[@"工单信息"]];
        [_topView addSubview:_hbTitleView];
        
        [_hbTitleView updataIndexLabelUIWithNum:0];
    }
    return _hbTitleView;
}

- (void)createUI {
    _topViewLineWidthConstraints.constant = kScWidth / 3.f;
    
    _scrollContentViewConstraints.constant = kScWidth *2;
    
    //告诉scrollView知道内部内容的大小
    _scrollView.delegate = self;
    _scrollView.contentSize=CGSizeMake(kViewCount*_scrollView.bounds.size.width, 0);
    
    //tableView
    self.leftOrderTableView.delegate = self;
    self.leftOrderTableView.dataSource = self;
    
    self.rightTableView.delegate = self;
    self.rightTableView.dataSource = self;
    self.rightTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    _leftOrderTableView.rowHeight = UITableViewAutomaticDimension;
    _leftOrderTableView.estimatedRowHeight = 40;
    _rightTableView.rowHeight = UITableViewAutomaticDimension;
    _rightTableView.estimatedRowHeight = 40;
    
    //分割线填满
    if ([self.leftOrderTableView respondsToSelector:@selector(setSeparatorInset:)]) {
        [self.leftOrderTableView setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([self.leftOrderTableView respondsToSelector:@selector(setLayoutMargins:)]) {
        [self.leftOrderTableView setLayoutMargins:UIEdgeInsetsZero];
    }
    
    //注册
    [self.leftOrderTableView registerNib:[UINib nibWithNibName:@"JXOrderDetailInfoTableViewCell" bundle:nil] forCellReuseIdentifier:@"leftcell"];
    [self.rightTableView registerNib:[UINib nibWithNibName:@"JXEomsDetailCirculationTableViewCell" bundle:nil] forCellReuseIdentifier:@"rightcell"];
    
    
    
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapViewAction:)];
    [_orderInfoLabel addGestureRecognizer:tap1];
    _orderInfoLabel.tag = 101;
    
    UITapGestureRecognizer *tap2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapViewAction:)];
    [_orderCirculationLabel addGestureRecognizer:tap2];
    _orderCirculationLabel.tag = 102;
}


- (void)tapViewAction:(UITapGestureRecognizer *)tap {
    
    if(101 == tap.view.tag) {
        curentPage = 0;
    }else if(102 == tap.view.tag) {
        curentPage = 1;
    }
    
    //获取当前页数乘以scrollView的宽度，从而设置scrollView的X偏移量
    CGFloat x = curentPage * self.scrollView.bounds.size.width;
    [self.scrollView setContentOffset:CGPointMake(x, 0) animated:NO];
    [self scrollViewDidEndDecelerating:_scrollView];
}




#pragma mark - JXOrderToolBtnDelegate

#pragma mark--switch判断请求




//请求通用任务工单详情



//请求工单详情


//请求流转信息详情

//获取路由信息

//checkData,检查是否有驳回，有则需要将保留回填信息


#pragma mark - UITableView
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    if(tableView == _leftOrderTableView) {
        return [_showRowSource count];
    }else {
        return 1;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 0.1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return nil;
}

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(tableView == _leftOrderTableView) {
        return [[_showRowSource objectAtIndex:section] count];
    }else {
        return [_rightDataSource count];
    }
    
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if(tableView == _leftOrderTableView && indexPath.section == 4) {
//最后一个cell需计算高度
        //return _routeInfoArr.count*303+(_routeInfoArr.count-1)*10+50;
        return UITableViewAutomaticDimension;
    }else  {
        return UITableViewAutomaticDimension;
    }

}

-(UITableViewCell*) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if(tableView == _leftOrderTableView) {
        
        
        JXOrderDetailInfoTableViewCell *cell = (JXOrderDetailInfoTableViewCell *)[tableView dequeueReusableCellWithIdentifier:[NSString stringWithFormat:@"cell%ld",indexPath.row]];
        if (!cell) {
            cell = [[[NSBundle mainBundle] loadNibNamed:NSStringFromClass([JXOrderDetailInfoTableViewCell class]) owner:self options:nil] objectAtIndex:0];
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        NSString *key = _rowSource[indexPath.section][indexPath.row];
        NSString *showKey = _showRowSource[indexPath.section][indexPath.row];
        JXOrderDetailInfoCellType status = JXOrderDetailInfoCellTypeShortText;
        cell.jumpFiberInfo = _routeInfoArr;
        cell.orderType=_orderType;
        cell.delegate=self;
        //特殊值处理
        NSString *content = _leftdata[indexPath.row];//[self dealSpeacilValue:key showKey:showKey];
        
        //脱敏处理--临时-------begin
        
        
        //脱敏处理--临时-------end
        
        
        if([key isEqualToString:@"Password"]) {
            content = [_leftAllDataDic objectForKey:@"LOGICID"];
        }
        NSString *showTitle = _showRowSource[indexPath.section][indexPath.row];
        if([self.orderType isEqualToString:@"PnrJumpFiber"] && [showKey isEqualToString:@"路由信息"]) {
            status = JXOrderDetailInfoCellTypeJumpFiber;
        }
        [cell refreshUI:showTitle content:content status:status];
        
        return cell;
        
    }else {
        
        JXEomsDetailCirculationTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"rightcell"];
        NSDictionary *dataDic = [_rightDataSource objectAtIndex:indexPath.row];
        
        
        
        //判断是否画虚线
        NSDictionary *nextCellDataDic = [_rightDataSource objectAtIndex:indexPath.row];
        BOOL isdrawLine = YES;
        NSString *activeTemplateStr = [NSString stringWithFormat:@"%@", isnull(@"activeTemplateIdId", dataDic)];
        
        NSString *nextActiveTemplateStr = [NSString stringWithFormat:@"%@", isnull(@"activeTemplateIdId", nextCellDataDic)];
        
        if(![activeTemplateStr isEqualToString:nextActiveTemplateStr] || activeTemplateStr.length == 0){
            isdrawLine = NO;
        }
        
        
         cell.orderType = _orderType;
        [cell refreshUI:dataDic isLast:indexPath.row == _rightDataSource.count - 1 isDrawLine:isdrawLine];
       
//        [cell setNeedsLayout];
//        [cell layoutIfNeeded];
        return cell;
    }
    
}


-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(tableView == _leftOrderTableView) {
        
        
        
    }else {
        
        JXEomsDetailCirculationTableViewCell *cell=(JXEomsDetailCirculationTableViewCell *)[_rightTableView cellForRowAtIndexPath:indexPath];
//        JXEomsCirculationInfoViewController *vc = [[JXEomsCirculationInfoViewController alloc] init];
//        NSDictionary *dataDic = [_rightDataSource objectAtIndex:indexPath.row];
//        vc.orderType = _orderType;
//        vc.dataDic = dataDic;
//        vc.operateType=[self string:cell.titleNameLabel.text ];
//        vc.ACTIVETASKNAME=cell.activeTemplateLabel.text;
//        vc.sheetId = isnull(@"sheetId", _dataDic);
//
//        [self.navigationController pushViewController:vc animated:YES];
    }
    
    
}

- (NSString *)string:(NSString *)str {
    
    if(str.length<=0 || [str isKindOfClass:[NSNull class]]){
        return str ;
    }
    NSRange startRange = [str rangeOfString:@"【"];
    NSRange endRange = [str rangeOfString:@"】"];
    NSRange range = NSMakeRange(startRange.location + startRange.length, endRange.location - startRange.location - startRange.length);
    NSString *result = [str substringWithRange:range];
    
    return result;
}
//允许 Menu菜单
- (BOOL)tableView:(UITableView *)tableView shouldShowMenuForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

//每个cell都会点击出现Menu菜单
- (BOOL)tableView:(UITableView *)tableView canPerformAction:(SEL)action forRowAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender
{
    if(action == @selector(copy:)){
        return YES;
    }
    else{
        return NO;
    }
}

- (void)tableView:(UITableView *)tableView performAction:(SEL)action forRowAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender
{
    if (action == @selector(copy:)) {
        NSString *key = _rowSource[indexPath.section][indexPath.row];
        NSString *showKey = _showRowSource[indexPath.section][indexPath.row];
        JXOrderDetailInfoCellType status = JXOrderDetailInfoCellTypeShortText;
        
        //特殊值处理
        NSString *content = [self dealSpeacilValue:key showKey:showKey];
        
        [UIPasteboard generalPasteboard].string = content;
    }
    
    
}

//特殊值处理
- (NSString *)dealSpeacilValue:(NSString *)key showKey:(NSString *)showKey {
    NSString *retrunValue = [NSString stringWithFormat:@"%@", [_leftAllDataDic[key] isKindOfClass:[NSNull class]] ||  _leftAllDataDic[key] == nil ?@"":_leftAllDataDic[key]];
    
        if([showKey containsString:@"工单状态"]){
            if ([retrunValue isEqualToString:@"0"]) {
                retrunValue = @"运行中";
            }else if([retrunValue isEqualToString:@"1"]){
                retrunValue = @"已归档";
            }else if([retrunValue isEqualToString:@"-12"]) {
                retrunValue = @"作废";
            }else if([retrunValue isEqualToString:@"-14"]) {
                retrunValue = @"强制作废";
            }
        }
        
    
    return retrunValue;
}

- (BOOL)isPureNumandCharacters:(NSString *)string
{
    
    string = [string stringByTrimmingCharactersInSet:[NSCharacterSet decimalDigitCharacterSet]];
    if(string.length > 0)
    {
        return NO;
    }
    return YES;
}

#pragma mark - mark--获取告警清除时间

#pragma  mark - scrollView
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    
    //计算页面，用scrollView的偏移位置除以scrollView的大小
    int page=self.scrollView.contentOffset.x/self.scrollView.bounds.size.width;
    curentPage = page;
    
    [UIView animateWithDuration:.25f animations:^{
        CGRect rect = _topViewLine.frame;
        if(0 == curentPage) {
            
            rect.origin.x = kScWidth / 12.f;
            _topViewLine.frame = rect;
            
        }else if(1 == curentPage) {
            
            rect.origin.x = kScWidth * 7 / 12.f;
            _topViewLine.frame = rect;
        }
        [self.view layoutIfNeeded];
    }];
    
    if(0 == curentPage) {
        
        if(!_leftDataSource || [_leftDataSource count] < 1 ){
            
          
        }
    }else if(1 == curentPage) {
        if(!_rightDataSource || [_rightDataSource count] < 1 ){
            
           
        }
    }
}






//工单受理后重新请求数据





- (NSString *)convertSection :(NSString *)typeStr {
    if ([typeStr isEqualToString:@"new"]) {
        return @"新增工单";
    } else if ([typeStr isEqualToString:@"DispatchTask"]) {
        return @"工单调度";
    } else if ([typeStr isEqualToString:@"AcceptTask"]) {
        if ([_orderType isEqualToString: @"PnrFamilyBackOut"] || [_orderType isEqualToString: @"PnrFamilyBespeak"]) {
            return @"代维接单";
        } else if ([_orderType isEqualToString: @"PnrFamilyBroadband"]) {
            return @"工单受理";
        } else if ([_orderType isEqualToString: @"PnrFamilyComplaint"]) {
            return @"外线排查";
        }
    } else if ([typeStr isEqualToString:@"ReplyTask"]) {
        return @"代维回单";
    } else if ([typeStr isEqualToString:@"QualTestTask"]) {
        return @"质检";
    } else if ([typeStr isEqualToString:@"HoldTask"]) {
        return @"自动归档";
    } else if ([typeStr isEqualToString:@"AppointInstallTask"]) {
        return @"预约安装";
    } else if ([typeStr isEqualToString:@"InstallTask"]) {
        return @"上门安装";
    } else if ([typeStr isEqualToString:@"AppointDealTask"]) {
        return @"预约排障";
    } else if ([typeStr isEqualToString:@"DealTask"]) {
        if ([_orderType isEqualToString: @"PnrFamilyComplaint"]) {
            return @"上门处理";
        } else if ([_orderType isEqualToString: @"PnrFamilyBespeak"]) {
            return @"资源确认";
        }
        
    }
    return @"";
    
}

//是否
- (NSString *)tranToStrResultIsOrNot:(NSString *)typeStr {
    if([typeStr isEqualToString:@"1"])
    {
        return @"是";
    }else if([typeStr isEqualToString:@"0"])
    {
        return @"否";
    }else {
        return @"";
    }
}

//成功失败
- (NSString *)tranToStrResultSuccessOrFail:(NSString *)typeStr {
    if([typeStr isEqualToString:@"1"])
    {
        return @"成功";
    }else if([typeStr isEqualToString:@"0"])
    {
        return @"失败";
    }else {
        return @"";
    }
}

//装机状态
- (NSString *)tranToStrResultStatus:(NSString *)typeStr {
    if([typeStr isEqualToString:@"1"])
    {
        return @"预约环节工单挂起";
    }else if([typeStr isEqualToString:@"2"])
    {
        return @"上门安装环节工单挂起";
    }else if([typeStr isEqualToString:@"81"]){
        return @"上门安装环节工单挂起";
    }else if([typeStr isEqualToString:@"85"]){
        return @"预约环节异常回单";
    }else if([typeStr isEqualToString:@"86"]){
        return @"上门安装环节异常回单";
    }else {
        return @"";
    }
    
}

- (NSString *)tranToStr:(NSString* )typeStr {
    if ([typeStr isEqualToString:@"1"]) {
        return @"续费用户";
    }
    else if ([typeStr isEqualToString:@"2"]) {
        return @"当月已安装过";
    }
    else if ([typeStr isEqualToString:@"3"]) {
        return @"被前台做了拆机并再次生成装机";
    }
    else if ([typeStr isEqualToString:@"4"]) {
        return @"校园场景";
    }
    else if ([typeStr isEqualToString:@"5"]) {
        return @"WBS场景";
    }else {
        return @"";
    }
    
}

- (NSString *)getOprateTypeStr:(NSString* )typeStr {
    if ([typeStr isEqualToString:@"0"]) {
        return @"新建派发";
    }
    else if ([typeStr isEqualToString:@"22"]) {
        return @"派发代维";
    }
    else if ([typeStr isEqualToString:@"23"]) {
        if ([_orderType isEqualToString: @"PnrFamilyBackOut"]) {
            return @"代维接单";
        } else if ([_orderType isEqualToString: @"PnrFamilyBroadband"]) {
            return @"资源确认成功";
        }
        else return @"";
    }
    else if ([typeStr isEqualToString:@"24"]) {
        return @"资源确认没有";
    }
    else if ([typeStr isEqualToString:@"25"]) {
        return @"代维回单";
    }
    else if ([typeStr isEqualToString:@"55"]) {
        return @"质检成功";
    }
    else if ([typeStr isEqualToString:@"56"]) {
        return @"质检失败";
    }
    else if ([typeStr isEqualToString:@"70"]) {
        return @"资源确认失败";
    }
    else if ([typeStr isEqualToString:@"80"]) {
        return @"预约成功";
    }
    else if ([typeStr isEqualToString:@"81"]) {
        return @"安装完成";
    }
    else if ([typeStr isEqualToString:@"82"]) {
        if ([_orderType isEqualToString: @"PnrFamilyComplaint"]) {
            return @"外线排查";
        } else if ([_orderType isEqualToString: @"PnrFamilyBespeak"]) {
            return @"代维回单";
        }
        return @"外线排查";
    }
    
    else if ([typeStr isEqualToString:@"83"]) {
        return @"预约排障";
    }
    else if ([typeStr isEqualToString:@"84"]) {
        return @"上门处理";
    }
    else if ([typeStr isEqualToString:@"85"]) {
        if ([_orderType isEqualToString: @"PnrFamilyComplaint"]) {
            return @"代维回单";
        } else if ([_orderType isEqualToString: @"PnrFamilyBroadband"]) {
            return @"预约失败";
        }
        else return @"";
    }
    
    else if ([typeStr isEqualToString:@"86"]) {
        return @"上门失败";
    }
    else if ([typeStr isEqualToString:@"92"]) {
        return @"移交到调度台";
    }
    else if ([typeStr isEqualToString:@"93"]) {
        return @"移交代维";
    }
    else if ([typeStr isEqualToString:@"94"]) {
        return @"直派代维";
    }
    else if ([typeStr isEqualToString:@"94"]) {
        return @"工单受理";
    }
    
    else {
        return @"";
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
