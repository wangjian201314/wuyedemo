//
//  JXEomsCompleteViewController.m
//  JXWWNOP
//
//  Created by wangjian on 2018/4/8.
//  Copyright © 2018年 cn.mastercom. All rights reserved.
//


#import "JXEomsReplyViewController.h"
#import "JXOrderEditCell.h"
#import "MTEditPopView.h"
#import "UIToastView.h"

#define isnull(key,dict) dict[key] == nil || [dict[key] isKindOfClass:[NSNull class]] ? @"" : dict[key]

@interface JXEomsReplyViewController ()<UIDocumentPickerDelegate>

@end

@implementation JXEomsReplyViewController {
    /** 控件 */
    UITableView     * _tableView;
    UIAlertView     * _comfirmUploadAlertView;
    NSMutableArray      *_iCloudfilearray;//读取icloud文件上传
    
    /** 数据源 */
    NSDictionary        * _UIdict;              //plist文件数据
    NSDictionary        * _StageReturnDict;     //阶段回复
    NSDictionary        * _ReplyDict;          //回复
    NSDictionary        *_ReplyCheckDict;       //回复送审
    NSDictionary        *_AssiginDict;          //分派
    NSDictionary        *_changeGroupDict;
    NSDictionary        *_PassDict;             //审批通过
    NSDictionary        *_FailPassDict;         //审批不通过
    NSDictionary        *_AlReadDict;           //已阅
    NSDictionary        *_ReplayPassDict;       //回复通过
    
    
    NSMutableArray      * _cells;
    NSMutableDictionary * _uploadDict;
    NSMutableArray      *_ReasonSubsectionArray;//故障原因细分
    NSMutableArray      *_DealResultArray;//故障处理结果
    NSMutableDictionary *_ProblemNetworkDict;//问题网络类型
    NSMutableDictionary *_ProblemReasonDict;//问题原因分类
    NSMutableDictionary *_SolutoionDict;//解决方案分类
    NSMutableDictionary *_ProgressDict;//处理进度
    NSMutableDictionary *_CustomerDict;//客户投诉类型
    
    /** 临时变量 */
    JXOrderEditCell * _currentCell;
    NSInteger HITVCount ;//HITV数量
    
    NSMutableArray *_firstReasonArray;
    NSMutableArray *_secondReasonArray;
    NSString * _selectTranReasonId;
    NSString * _selectTranReasonStr;
    NSString * _firstselect;
    
    NSMutableArray *_tranReasonArray;
    
    NSDictionary *_trangroupDict;//转派时存储的通用集合
    NSDictionary *_RejectDict;//驳回
    
    NSDictionary *_sheetLinkDic;//获取提交数据中的sheetLink
    NSString *_operator;//操作人
    NSString *_operatorTelephone;//操作人联系电话
    NSString *_operateTime;//操作时间
    NSString *_DEPTNAME;//操作人部门

    
    NSMutableDictionary *_finalUploadDict;//最终提交的数据
    NSString *_parentdictid;//故障原因类别对应ID
    
   
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _cells = [[NSMutableArray alloc]init];
   _iCloudfilearray=[NSMutableArray array];
    _uploadDict = [[NSMutableDictionary alloc]init];
    _finalUploadDict = [[NSMutableDictionary alloc]init];
    _sheetLinkDic = [[NSDictionary alloc]init];
    UIBarButtonItem* rightItem = [[UIBarButtonItem alloc]initWithTitle:@"提交" style:(UIBarButtonItemStylePlain) target:self action:@selector(doneAction)];
    [self setNaviTitle:_orderOperation?_orderOperation:@"确认" leftButtonShow:YES rightButtom:rightItem];
    
    //tableView
    [self setupTableView];
    
     
    //获取本地存储的数据
    [self getLocalData];
    
    //plistName
   
    
    [self getdata];
    //setupUIwithPlist
   
    
  
    
   // [self getNetreason];
    
    
    // 监听键盘的弹出和消失
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
}

- (void)getdata{
    
    [_uploadDict setObject:_datas[3] forKey:@"操作人"];
    [_uploadDict setObject:_datas[5] forKey:@"操作人部门"];
    [_uploadDict setObject:_datas[7] forKey:@"操作人联系电话"];
    [_uploadDict setObject:_datas[4] forKey:@"操作时间"];
    [SVProgressHUD showWithStatus:@"正在加载..."];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
         NSString * plistName = [NSString stringWithFormat:@"%@_%@.plist", @"Eoms",@"通用任务"];
         [self setupDataWithPlist:plistName];
    });
}
- (void)setupTableView {
    _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableView.dataSource = self;
    _tableView.delegate   = self;
    _tableView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [self.view addSubview:_tableView];
    _operator = @"";
    _operatorTelephone = @"";
    _operateTime = @"";
    
    _tableView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[_tableView]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_tableView)]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[_tableView]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_tableView)]];
}

- (void)setupDataWithPlist:(NSString *)plistName {
    _UIdict = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:plistName ofType:nil]];
    _RejectDict=_UIdict[@"RejectDict"];
    _StageReturnDict    = _UIdict[@"StageReturnDict"];
    _ReplyDict=_UIdict[@"ReplyDict"];
    _ReplyCheckDict=_UIdict[@"ReplyCheckDict"];
    _AssiginDict=_UIdict[@"AssiginDict"];
    _trangroupDict = _UIdict[@"_trangroupDict"];//转派时用到的通用集合
    _AlReadDict=_UIdict[@"AlReadDict"];
    _ReplayPassDict=_UIdict[@"ReplayPassDict"];
    _PassDict=_UIdict[@"PassDict"];
    _FailPassDict=_UIdict[@"FailPassDict"];
   
    if([_orderOperation isEqualToString:@"转派"]){
        
         [self reloadDataWithDict:_UIdict];
        
    }else if([_orderOperation isEqualToString:@"预约接单"]){
        
        [self reloadDataWithDict:_RejectDict];
        
    }else if([_orderOperation isEqualToString:@"外线排查"]){
        
        [self reloadDataWithDict:_StageReturnDict];
        
    }else if([_orderOperation isEqualToString:@"上门安装"]){
        
        [self reloadDataWithDict:_ReplyDict];
        
    }else if([_orderOperation isEqualToString:@"回复送审"]){
        
        [self reloadDataWithDict:_ReplyCheckDict];
        
    }else if([_orderOperation isEqualToString:@"分派"]){
        
        [self reloadDataWithDict:_AssiginDict];
        
    }else if([_orderOperation isEqualToString:@"审批通过"]){
        
        [self reloadDataWithDict:_PassDict];
        
    }else if([_orderOperation isEqualToString:@"审批不通过"]){
        
        [self reloadDataWithDict:_FailPassDict];
        
    }else if([_orderOperation isEqualToString:@"已阅"]){
        
        [self reloadDataWithDict:_AlReadDict];
        
    }else if([_orderOperation isEqualToString:@"回复通过"] || [_orderOperation isEqualToString:@"回复不通过"]){
        
        [self reloadDataWithDict:_ReplayPassDict];
        
    }else{
        [self reloadDataWithDict:_UIdict];
    }
    
}

- (void)reloadDataWithDict:(NSDictionary *)dict {
    
    
    NSMutableDictionary *mutableDict = [dict mutableCopy];
    [_cells removeAllObjects];
    
    NSArray      * group = mutableDict[@"group"];
    NSMutableDictionary * list  = [mutableDict[@"list"] mutableCopy];
    
    //段
    for (NSInteger i = 0; i < group.count; i ++) {
        NSString * groupItem = group[i];
        NSMutableArray  * order = [list[@"order"][groupItem] mutableCopy];
        NSMutableDictionary *groupItemDic =[list[@"detail"] mutableCopy];
        NSMutableDictionary * detail = [list[@"detail"][groupItem] mutableCopy];
        NSMutableArray * cells = [NSMutableArray new];
        if(_iCloudfilearray.count>0 && [groupItem isEqualToString:@"附件上传"]){
            
            for(int i=0;i<_iCloudfilearray.count;i++){
                
                [order addObject:[NSString stringWithFormat:@"%@:(%@)",_iCloudfilearray[i][@"fileName"],_iCloudfilearray[i][@"size"]]];
                NSMutableDictionary *dict=[[NSMutableDictionary alloc]init];
                [dict setObject:@(NO) forKey:@"isneed"];
                [dict setObject:@(8) forKey:@"type"];
                [dict setObject:@"icon_delete.png" forKey:@"value"];
                [detail setObject:dict forKey:[NSString stringWithFormat:@"%@:(%@)",_iCloudfilearray[i][@"fileName"],_iCloudfilearray[i][@"size"]] ];
            }
        }
        for (NSInteger i = 0; i < order.count; i ++) {
            NSString * item = order[i];
            NSMutableDictionary * itemDict = [detail[item] mutableCopy];
            
            if([_uploadDict valueForKey:item]) {
                [itemDict setObject:[_uploadDict valueForKey:item] forKey:@"value"];
            }
            
            JXOrderEditCell * cell = [self creatCellWithColumn:item withDict:itemDict];
            
            if([item isEqualToString:@"工单操作"] &&([_orderOperation isEqualToString:@"转派"] || [_orderOperation isEqualToString:@"驳回调度台"] )) {
                cell.value = _orderOperation;
            }
            
            [cells addObject:cell];
            [detail setObject:itemDict forKey:item];
        }
        if(detail) {
            [groupItemDic setObject:detail forKey:groupItem];
            [list setObject:groupItemDic forKey:@"detail"];
        }
        [_cells addObject:cells];
    }
    [_tableView reloadData];
    [mutableDict setObject:list forKey:@"list"];
    //保存当前UI的字典到本地
    //[self saveLocalData:_uploadDict value:mutableDict key:@"UIDict"];
}

- (JXOrderEditCell *)creatCellWithColumn:(NSString*)item withDict:(NSDictionary*)itemDict {
    
    NSNumber * type = itemDict[@"type"];
    
    NSString * cValue = itemDict[@"value"];//值
    
    NSString * cPlaceholder = itemDict[@"placeholder"];
    
    NSDictionary *imageDict = itemDict[@"images"];
    
    NSInteger maxImageCount = 1;
    if (itemDict[@"maxImageCount"]) {
        maxImageCount = [itemDict[@"maxImageCount"] integerValue];
    }
    
    BOOL  cIsNeed = [itemDict[@"isneed"] boolValue];
    
    if (cIsNeed) {
        item = [NSString stringWithFormat:@"*%@",item];
    }
    
    NSInteger type_EM = [type integerValue];
    
    JXOrderEditCell * cell;
    if (type_EM == JXOrderEditCellDate) {
        cell = [[JXOrderEditCell alloc]initWithType:JXOrderEditCellDate delegate:self];
        cell.column = item;
    }else if (type_EM == JXOrderEditCellText) {
        cell = [[JXOrderEditCell alloc]initWithType:JXOrderEditCellText delegate:self];
        cell.column = item;
        cell.placeholder = cPlaceholder;
        if(cValue) {
            cell.value = cValue;
        }
    }else if (type_EM == JXOrderEditCellLongText) {
        cell = [[JXOrderEditCell alloc]initWithType:JXOrderEditCellLongText delegate:self];
        cell.column = item;
    }else if (type_EM == JXOrderEditCellSwitch) {
        cell = [[JXOrderEditCell alloc]initWithType:JXOrderEditCellSwitch delegate:self];
        cell.column = item;
        cell.value = cValue;
        [cell setSwitchOn:cValue];
        //NSString *dictId=[_judgedict valueForKey:cell.value?cell.value:@"否"];
        [self saveLocalData:_uploadDict value:cell.value?cell.value:@"否" key:cell.column];
        
    }else if (type_EM == JXOrderEditCellButton) {
        cell = [[JXOrderEditCell alloc]initWithType:JXOrderEditCellButton delegate:self];
        
        [cell setbuttonImage:cValue];
        cell.column = item;
    }else if (type_EM == JXOrderEditCellLabel  ) {
        cell = [[JXOrderEditCell alloc]initWithType:JXOrderEditCellLabel delegate:self];
        cell.column = item;
        cell.value = cValue;
    }else if (type_EM == JXOrderEditCellImage) {
        cell = [[JXOrderEditCell alloc]initWithType:JXOrderEditCellImage delegate:self];
        cell.column = item;
        cell.maxImageCount = maxImageCount;
        if (imageDict) {
            cell.selectedPhotos = [[imageDict valueForKey:@"images"] mutableCopy];
            cell.selectedNames = [[imageDict valueForKey:@"imageNames"] mutableCopy];
        }
        
    }else if (type_EM == JXOrderEditCellScan) {
        cell = [[JXOrderEditCell alloc]initWithType:JXOrderEditCellScan delegate:self];
        cell.column = item;
    }else if (type_EM == JXOrderEditCellSingle) {
        cell = [[JXOrderEditCell alloc]initWithType:JXOrderEditCellSingle delegate:self];
        cell.column = item;
        cell.items = itemDict[@"items"];
        //改变结构
        BOOL changegroup    = itemDict[@"changegroup"];
        if (changegroup) {
            cell.changegroup = YES;
        }
        //层次等级
        NSNumber * ceng     = itemDict[@"ceng"];
        if (ceng) {
            cell.ceng = [ceng integerValue];
        }
        
    }else if (type_EM == JXOrderEditCellMutiple) {
        cell = [[JXOrderEditCell alloc]initWithType:JXOrderEditCellMutiple delegate:self];
        cell.column = item;
        cell.items = itemDict[@"items"];
    }
    
    NSString * column = cell.column;
    NSString * edvalue = [_uploadDict objectForKey:column];
    if (cell.cellType == JXOrderEditCellSingle&&edvalue) {
        if ([cell.items containsObject:edvalue]) {
            cell.value = edvalue;
        }
    }else if (edvalue) {
        cell.value = edvalue;
    }
    
    
    if ((cell.cellType == JXOrderEditCellSingle || cell.cellType == JXOrderEditCellLabel )&&cValue) {
        cell.value = cValue;
        [_uploadDict setValue:cell.value forKey:cell.column];
        [self saveLocalData:_uploadDict value:cell.value key:cell.column];
    }
    
    
    return cell;
}


#pragma mark - UITableViewDelegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return _cells.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSArray * cells = _cells[section];
    return cells.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSArray * cells = _cells[indexPath.section];
    JXOrderEditCell * cell = cells[indexPath.row];
    return cell.height;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 10;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    return nil;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    return nil;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSArray * cells = _cells[indexPath.section];
    JXOrderEditCell * cell = cells[indexPath.row];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - JXOrderEditCellDelegate
- (void)didSelectedOrderEditCell:(JXOrderEditCell *)taskEditCell {
    [self.view endEditing:YES];
    _currentCell = taskEditCell;
    if (taskEditCell.cellType == JXOrderEditCellDate) {
        MTEditPopView * popView = [[MTEditPopView alloc]initWithType:MTEditPopViewDate delegate:self];
        if (_currentCell.value) {
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            NSDate *resultDate = [dateFormatter dateFromString:_currentCell.value];
            popView.iniDate = resultDate;
        }
        [popView show];
    }else if (taskEditCell.cellType == JXOrderEditCellSingle) {
        
        MTEditPopView * popView = [[MTEditPopView alloc]initWithType:MTEditPopViewSingle delegate:self];
     
        
    }else if (taskEditCell.cellType == JXOrderEditCellMutiple) {
        MTEditPopView * popView = [[MTEditPopView alloc]initWithType:MTEditPopViewMultiple delegate:self];
        popView.titles = taskEditCell.items;
        [popView show];
    }else if (taskEditCell.cellType == JXOrderEditCellText) {
        MTEditPopView * popView = [[MTEditPopView alloc]initWithType:MTEditPopViewText delegate:self];
        popView.textViewStr = taskEditCell.value;
        [popView show];
    }else if (taskEditCell.cellType == JXOrderEditCellLongText) {
        MTEditPopView * popView = [[MTEditPopView alloc]initWithType:MTEditPopViewText delegate:self];
        popView.textViewStr = taskEditCell.value;
        [popView show];
    }else if (taskEditCell.cellType == JXOrderEditCellButton) {
        if([taskEditCell.column isEqualToString:@"附件上传"]){
            [self presentDocumentPicker];
        }else {
            for(int i=0;i<_iCloudfilearray.count;i++){
                if([[NSString stringWithFormat:@"%@:(%@)",_iCloudfilearray[i][@"fileName"],_iCloudfilearray[i][@"size"]] isEqualToString:taskEditCell.column]){
                    [_iCloudfilearray removeObjectAtIndex:i];
                }
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                if([_orderOperation isEqualToString:@"回复"]){
                    
                    [self reloadDataWithDict:_ReplyDict];
                    
                }else if([_orderOperation isEqualToString:@"分派"]){
                    
                    [self reloadDataWithDict:_AssiginDict];
                    
                }
            });
            
        }
    }
    
    
    else if (taskEditCell.cellType == JXOrderEditCellLabel) {
        
       
    }
    
}

- (void)presentDocumentPicker {
    NSArray *documentTypes = @[@"public.content", @"public.text", @"public.source-code ", @"public.image", @"public.audiovisual-content", @"com.adobe.pdf", @"com.apple.keynote.key", @"com.microsoft.word.doc", @"com.microsoft.excel.xls", @"com.microsoft.powerpoint.ppt"];
    
    UIDocumentPickerViewController *documentPickerViewController = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:documentTypes
                                                                                                                          inMode:UIDocumentPickerModeOpen];
    documentPickerViewController.delegate = self;
    [self presentViewController:documentPickerViewController animated:YES completion:nil];
}

#pragma mark - UIDocumentPickerDelegate

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentAtURL:(NSURL *)url {
    
    NSArray *array = [[url absoluteString] componentsSeparatedByString:@"/"];
    NSString *fileName = [array lastObject];
    if(fileName==nil ||[fileName isEqualToString:@""]){
        fileName=[array objectAtIndex:array.count-2];
    }
    fileName = [fileName stringByRemovingPercentEncoding];
    
}

//整理icloud文件上传信息,和上传图片类似
- (NSArray *)paserFile:(NSString *)path withImgName:(NSData *)imageData imageType:(NSString *)name {
    
    NSString *fileSize=[self changeSize:imageData.length];
    NSArray  *files =@[@{@"data":imageData,
                         @"name":@"jpg",
                         @"fileName":name,
                         @"mimeType":@"image/jpeg",
                         @"size":fileSize
                         }];
    
    return files;
}

- (NSString *)changeSize:(int )size{
    
    NSString *sizeText;
    if (size >= pow(10, 9)) { // size >= 1GB
        sizeText = [NSString stringWithFormat:@"%.2fGB", size / pow(10, 9)];
    } else if (size >= pow(10, 6)) { // 1GB > size >= 1MB
        sizeText = [NSString stringWithFormat:@"%.2fMB", size / pow(10, 6)];
    } else if (size >= pow(10, 3)) { // 1MB > size >= 1KB
        sizeText = [NSString stringWithFormat:@"%.2fKB", size / pow(10, 3)];
    } else { // 1KB > size
        sizeText = [NSString stringWithFormat:@"%dB", size];
    }
    
    return sizeText;
}

- (void)didEditedCell:(JXOrderEditCell *)orderEditCell text:(NSString *)string {
    //    _currentCell = orderEditCell;
    [_uploadDict setValue:string forKey:orderEditCell.column];
    orderEditCell.value = string;
    [self saveLocalData:_uploadDict value:string key:orderEditCell.column];
}

- (void)didChangeSwitch:(JXOrderEditCell *)taskEditCell isSwitchOn:(BOOL) isSwitchOn{
    _currentCell = taskEditCell;
    NSString *swValue = @"否";
    if (isSwitchOn) {
        swValue = @"是";
    }else {
        swValue = @"否";
    }
   // NSString *dictId=[_judgedict valueForKey:swValue];
    [self saveLocalData:_uploadDict value:swValue key:taskEditCell.column];
    
    for (NSInteger i=0; i<_cells.count; i++) {
        NSArray *tempcell = _cells[i];
        for (NSInteger j=0; j<tempcell.count; j++) {
            JXOrderEditCell *cell = tempcell[j];
            if ([cell.column isEqualToString:_currentCell.column]) {
                cell.value = isSwitchOn?@"是":@"否";
            }
        }
    }
    [_tableView reloadData];
    
    
    
}


#pragma mark - MTEditPopViewDelegate-"选择后"
- (void)MTEditPopView:(MTEditPopView *)popView resultStr:(NSString *)result {
    JXOrderEditCell * cell = _currentCell;
    if ([cell.value isEqualToString:result]) {
        return;
    }
    
    if (popView.popViewType == MTEditPopViewText) {
        cell.value = result;
        [_uploadDict setValue:cell.value forKey:cell.column];
        
        [self saveLocalData:_uploadDict value:cell.value key:cell.column];
    }
    else if(popView.popViewType == MTEditPopViewDate) {
        if ([cell.column isEqualToString:@"预约时间"] || [cell.column isEqualToString:@"改约时间"]) {
            NSDate *currentDate = [NSDate date];
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd hh:mm:ss"];
            NSDate *resultDate = [dateFormatter dateFromString:result];
            if([resultDate compare:currentDate] == NSOrderedAscending){
                [SVProgressHUD showErrorWithStatus:@"预约时间必须大于当前时间"];
                return;
            }
        }
        cell.value = result;
        [_uploadDict setValue:cell.value forKey:cell.column];
        
        [self saveLocalData:_uploadDict value:cell.value key:cell.column];
        
    }
    else if (popView.popViewType == MTEditPopViewSingle||popView.popViewType == MTEditPopViewMultiple) {
        //"单选"和"多选"没选时需要重置
        if([cell.column containsString:@"故障原因类别"]){
            
            _firstselect=result;
        }
        if (result.length > 0) {
            cell.value = result;
            [_uploadDict setValue:cell.value forKey:cell.column];
            [self saveLocalData:_uploadDict value:cell.value key:cell.column];
        }else{
            cell.value = nil;
            if ([[_uploadDict allKeys] containsObject:cell.column]) {
                [_uploadDict removeObjectForKey:cell.column];
            }
        }
    }
    
    
    
    if ([cell.value isEqualToString:@"转派"] || [cell.value isEqualToString:@"转派代维人员"] ||[cell.value isEqualToString:@"驳回调度台"]) {
        _orderOperation = cell.value ;
    }
    
    
    if ([cell.column containsString:@"转派原因"] || [cell.column containsString:@"驳回原因"]) {
        //        _selectFirstReasonId =
        for (NSInteger i = 0; i<_tranReasonArray.count; i++) {
            NSMutableDictionary *tempDic = _tranReasonArray[i];
            if ([[tempDic valueForKey:@"dictName"] isEqualToString:result]) {
                _selectTranReasonId = [tempDic valueForKey:@"dictId"];
                _selectTranReasonStr = result;
                //保存到本地
                [self saveLocalData:_uploadDict value:_selectTranReasonId key:@"selectTranReasonId"];
                [self saveLocalData:_uploadDict value:_selectTranReasonStr key:@"selectTranReasonStr"];
                //改变结构
                NSDictionary * dict = _trangroupDict[_orderOperation];;
                if (dict) {
                    [self reloadDataWithDict:dict];
                    return;
                }
                
                break;
            }
        }
    }
    
    if (cell.changegroup&&cell.value.length>0) {
        
        //改变结构前先清除比当前项层次深的已选数据
        if (cell.ceng>=1) {
            for (NSInteger i = 0; i < _cells.count; i ++) {
                NSArray * cells = _cells[i];
                for (NSInteger j = 0; j < cells.count ; j ++) {
                    JXOrderEditCell * otherCell = cells[j];
                    if (otherCell.ceng>cell.ceng) {
                        otherCell.value = nil;
                        if ([[_uploadDict allKeys] containsObject:otherCell.column]) {
                            [_uploadDict removeObjectForKey:otherCell.column];
                        }
                    }
                }
            }
        }
        
        //改变结构
        NSDictionary * dicts = _changeGroupDict[cell.column];
        if (dicts) {
            NSDictionary * dict = dicts[cell.value];
            if (dict) {
                [self reloadDataWithDict:dict];
            }
        }
        
    }
    
    
}


//整理提交信息
- (void)SortFromItem:(NSString *)operateStr selectedStr:(NSString *)selStr {
    NSString * plistName = @"OrderOperation.plist";
    NSDictionary *OperateCommonDic = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:plistName ofType:nil]];
    _operateType = OperateCommonDic[_orderType][_orderOperation][selStr];
}


#pragma mark - 提交
- (void)doneAction {
    
    [self.view endEditing:YES];
    [_uploadDict setValue:_taskId forKey:@"taskId"];
    [_uploadDict setValue:_sheetId forKey:@"sheetId"];
     [_uploadDict setValue:_mainId forKey:@"mainId"];
    
    //确定必填项
    for (NSInteger i=0; i<_cells.count; i++) {
        NSArray *tempcell = _cells[i];
        for (NSInteger j=0; j<tempcell.count; j++) {
            JXOrderEditCell *cell = tempcell[j];
            if (cell.necessary) {
                if ([cell.column containsString:@"不去现场原因"] || [cell.column containsString:@"附件上传"]) {
                    continue;
                }
                if ([@[@"请输入",@"请选择"] containsObject:cell.value]||
                    [_uploadDict valueForKey:cell.column] == nil
                    )
                    
                {
                    [SVProgressHUD showErrorWithStatus:[NSString stringWithFormat:@"请完善:%@",cell.column]];
                    return;
                }
            }
        }
    }
    
    if (_comfirmUploadAlertView == nil) {
        _comfirmUploadAlertView = [[UIAlertView alloc]initWithTitle:nil message:@"确认提交信息准确并提交?" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
        _comfirmUploadAlertView.tag = 1002;
    }
    [_comfirmUploadAlertView show];
    
}



- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
   
    if (alertView.tag == 1002) {
        if(buttonIndex == 1) {
            //            [self deleteFile];
            [self upload];
        }
    }
    
}

- (void)upload {
    
//    dispatch_async(dispatch_get_main_queue(), ^{
         [SVProgressHUD showWithStatus:@"正在提交。。。"];
//    });
   
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
         [SVProgressHUD showSuccessWithStatus:@"提交成功"];
        //发送提交成功的广播
        [[NSNotificationCenter defaultCenter] postNotificationName:@"OrderRefresh" object:nil];
        
        int index = (int)[[self.navigationController viewControllers]indexOfObject:self];
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:(index -2)] animated:YES];
    });
    
           
    
            
    
    
}

//填写内容本地存储
- (void)saveLocalData: (NSMutableDictionary *) dict value:(id) value key:(id)key {
    [dict setObject:value forKey:key];
    //    NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    //    NSString *filePath = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_%@_orderTest.plist",_taskId,_orderOperation]];
    //    [dict writeToFile:filePath atomically:YES];
    //
    //    //准备存储数据的对象
    //    NSMutableData *data = [NSMutableData data];
    //    //创建归档对象
    //    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
    //    //开始归档
    //    [archiver encodeObject:dict forKey:@"uploadDict"];
    //    //完成归档
    //    [archiver finishEncoding];
    //    //写入文件当中
    //    BOOL result = [data writeToFile:filePath atomically:YES];
    //    if (result) {
    //        NSLog(@"归档成功:%@",path);
    //    }else
    //    {
    //        NSLog(@"归档不成功!!!");
    //    }
    
    
    
}


//获取本地存储内容
- (void)getLocalData {
    //    NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    //
    //    NSString *filePath =  [path stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_%@_orderTest.plist",_taskId,_orderOperation]];
    //    NSData *myData = [NSData dataWithContentsOfFile:filePath];
    //    //创建反归档对象
    //    NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:myData];
    //    //反归档
    //    NSMutableDictionary *dic = (NSMutableDictionary *)[unarchiver decodeObjectForKey:@"uploadDict"];
    //    //完成反归档
    //    [unarchiver finishDecoding];
    //    if(dic)
    //    {
    //        _uploadDict = dic;
    //        //获取本地数据后，将里面的操作时间改为当前时间
    //        NSString *newOperateTime=[NSDate stringFromDate:[NSDate date] dateFormat:@"yyyy-MM-dd HH:mm:ss"];
    //        [_uploadDict setObject:newOperateTime forKey:@"操作时间"];
    //    }
    //    _selectTranReasonId = isnull(@"selectTranReasonId", _uploadDict);
    //    _selectTranReasonStr = isnull(@"selectTranReasonStr", _uploadDict);
    //    _tranReasonArray = [_uploadDict objectForKey:@"tranReasonArray"];
    //    _firstReasonArray = [_uploadDict objectForKey:@"tranReasonArray"];
    //    _secondReasonArray = [_uploadDict objectForKey:@"secondReasonArray"];
    if (_firstReasonArray == nil) {
        _firstReasonArray = [[NSMutableArray alloc]init];
    }
    if (_secondReasonArray == nil) {
        _secondReasonArray = [[NSMutableArray alloc]init];
    }
    if (_tranReasonArray == nil) {
        _tranReasonArray = [[NSMutableArray alloc]init];
    }
    if(_ReasonSubsectionArray==nil){
        
        _ReasonSubsectionArray=[[NSMutableArray alloc]init];
    }
    if(_DealResultArray==nil){
        
        _DealResultArray=[[NSMutableArray alloc]init];
    }
    
    if(_ProblemNetworkDict==nil){
        
        _ProblemNetworkDict=[[NSMutableDictionary alloc]init];
        
    }
    
    if(_ProblemReasonDict==nil){
        
        _ProblemReasonDict=[[NSMutableDictionary alloc]init];
        
    }
    if(_ProgressDict==nil){
        
        _ProgressDict=[[NSMutableDictionary alloc]init];
    }
    
    if(_SolutoionDict==nil){
        
        _SolutoionDict=[[NSMutableDictionary alloc]init];
        
    }
    
    if(_CustomerDict==nil){
        
        _CustomerDict=[[NSMutableDictionary alloc]init];
        
    }
}
//获取本地UIDict
- (id)getLocalDictWithKey:(NSString *)key {
    //    NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    //
    //    NSString *filePath =  [path stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_%@_orderTest.plist",_taskId,_orderOperation]];
    //    NSData *myData = [NSData dataWithContentsOfFile:filePath];
    //    //创建反归档对象
    //    NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:myData];
    //    //反归档
    //    NSMutableDictionary *dic = (NSMutableDictionary *)[unarchiver decodeObjectForKey:@"uploadDict"];
    //    id currentObject = [dic objectForKey:key];
    //    return currentObject;
    return nil;
}

// 删除文件夹
- (void)deleteFile
{
    // 获取要删除的路径
    NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    
    NSString *filePath =  [path stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_%@_orderTest.plist",_taskId,_orderOperation]];
    // 创建文件管理对象
    NSFileManager *manager = [NSFileManager defaultManager];
    // 删除
    BOOL isDelete = [manager removeItemAtPath:filePath error:nil];
    NSLog(@"归档删除%@", isDelete==1?@"成功":@"失败");
}




#pragma mark - KeyBoardHidden
- (void) keyboardShow:(NSNotification*)notification{
    
    NSDictionary* info = [notification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height, 0.0);
    _tableView.scrollEnabled = YES;
    _tableView.contentInset = contentInsets;
    _tableView.scrollIndicatorInsets = contentInsets;
    NSLog(@"keyboardWasShown");
    
}

- (void) keyboardHide:(NSNotification*)notification{
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    _tableView.contentInset = contentInsets;
    _tableView.scrollIndicatorInsets = contentInsets;
}




#pragma mark -懒加载




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}



@end
