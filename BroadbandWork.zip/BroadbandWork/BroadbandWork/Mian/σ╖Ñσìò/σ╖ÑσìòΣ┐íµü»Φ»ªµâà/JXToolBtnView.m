//
//  JXToolBtnView.m
//  JXWWNOP
//
//  Created by hqf on 2017/6/23.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//
#import "JXEomsReplyViewController.h"
#import "JXToolBtnView.h"


@implementation JXToolBtnView {
   
}

+ (JXToolBtnView *)initViewWithXib {
    JXToolBtnView *view=[[[NSBundle mainBundle] loadNibNamed:@"JXToolBtnView" owner:self options:nil] lastObject];
    
    
    return view;
}

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (UIViewController*) viewController {
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController*)nextResponder;
        }
    }
    return nil;
}

- (void)setModel:(NSArray *)model{
    _model = model;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchViewAction:)];
    
    [_touchView addGestureRecognizer:tap];
    
    _imgView.image = [UIImage imageNamed:_model[1]];
    _label.text = _model[0];
    
}

- (void)touchViewAction:(UITapGestureRecognizer *)tap {
   
    
    if ([_label.text isEqualToString:@"工单受理"]) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"工单受理？" delegate:self cancelButtonTitle:@"是" otherButtonTitles:@"否", nil];
        [alertView show];
    }
    else{
        JXEomsReplyViewController *vc=[JXEomsReplyViewController new];
        vc.orderOperation=_label.text;
        vc.datas=_datas;
        [[self viewController].navigationController pushViewController:vc animated:YES];

    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if(buttonIndex == 0) {
        if (self.delegate&&[self.delegate respondsToSelector:@selector(didSelectedOrderToolbtn:)]) {
            [self.delegate didSelectedOrderToolbtn :_label.text];
        }
    }
}



@end

