//
//  JXOrderDetailInfoTableViewCell.m
//  JXWWNOP
//
//  Created by hqf on 2017/6/26.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//

#import "JXOrderDetailInfoTableViewCell.h"

#define kCollectionCellCount 4

@interface JXOrderDetailInfoTableViewCell()<UICollectionViewDataSource,UICollectionViewDelegate>

@property (weak, nonatomic) IBOutlet UILabel *titleNameLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *titleNameLabelWidthLine;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contentLabelWidthLine;
@property (weak, nonatomic) IBOutlet UIButton *phoneBtn;

@property (weak, nonatomic) IBOutlet UIView *groupView;

@property (nonatomic, strong) UICollectionView *collectionView;

- (IBAction)btnAction:(UIButton *)sender;
@end

@implementation JXOrderDetailInfoTableViewCell {
    
    NSMutableArray *_selectedImgName;
    NSMutableArray *_selectedPhotos;
    NSMutableArray *_selectedAssets;
    
    CGFloat _itemWH;
    CGFloat _margin;
   
}

- (void)awakeFromNib {
    [super awakeFromNib];
    
    
    self.groupView.hidden = YES;
    self.Editbtn.hidden=YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

- (IBAction)editbtn:(UIButton *)sender {
    
    if(self.delegate &&[self.delegate respondsToSelector:@selector(editbtn)]){
        [self.delegate editbtn];
    }
}

- (void)refreshUI:(NSString *)title content:(NSString *)content status:(JXOrderDetailInfoCellType)status {
    self.titleNameLabel.text = [NSString stringWithFormat:@"%@:",title];
    self.contentLabel.text = content;
    if([_orderType isEqualToString:@"故障工单"] || [_orderType isEqualToString:@"告警通知单"] || [_orderType isEqualToString:@"投诉工单"] || [_orderType isEqualToString:@"通用任务"]){
       // [self distinguishPhoneNumLabel:self.contentLabel labelStr:content];
    }
    if( [_orderType isEqualToString:@"故障工单"]){
        if([title containsString:@"告警清除时间"] ){
            self.Editbtn.hidden=NO;
            [self.Editbtn setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
            [self.Editbtn setTitle:@"获取时间" forState:UIControlStateNormal];
            self.BtnWidths.constant=80;
            self.BtnHeight.constant=30;
            self.Editbtn.backgroundColor = [UIColor colorWithHexString:@"0X2496F8"];
            [self.Editbtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            self.Editbtn.titleLabel.font = [UIFont systemFontOfSize:12.0f];
            self.TextlbLeading.constant=80;
        }else{
            self.Editbtn.hidden=YES;
            self.TextlbLeading.constant=10;
        }
    }else{
        if([title containsString:@"我的备注"] && ![self.orderType isEqualToString:@"BroadbandConfiguration"]){
            
            self.Editbtn.hidden=NO;
            self.TextlbLeading.constant=80;
        }else{
            self.Editbtn.hidden=YES;
            self.TextlbLeading.constant=10;
        }
    }

    NSDictionary *attrs = @{NSFontAttributeName : [UIFont boldSystemFontOfSize:15]};
    CGSize size=[self.titleNameLabel.text sizeWithAttributes:attrs];
    self.titleNameLabelWidthLine.constant = size.width + 1;
    switch (status) {
        case JXOrderDetailInfoCellTypeNormal:
        {
            self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            self.phoneBtn.hidden = YES;
            self.groupView.hidden = YES;
        }
            break;
        case JXOrderDetailInfoCellTypePhone:
        {
            self.accessoryType = UITableViewCellAccessoryNone;
            self.phoneBtn.hidden = NO;
            self.groupView.hidden = YES;
            self.contentLabelWidthLine.constant = kScreenH - size.width - 31 - 35;
            self.contentLabel.textAlignment = NSTextAlignmentRight;
        }
            break;
        case JXOrderDetailInfoCellTypeShortText:
        {
            self.accessoryType = UITableViewCellAccessoryNone;
            self.phoneBtn.hidden = YES;
            self.groupView.hidden = YES;
            self.contentLabel.hidden = NO;
            self.contentLabelWidthLine.constant = kScreenW - size.width - 31;
            //self.contentLabel.textAlignment = NSTextAlignmentRight;
        }
            break;
        case JXOrderDetailInfoCellTypeLongText:
        {
            self.accessoryType = UITableViewCellAccessoryNone;
            self.phoneBtn.hidden = YES;
            self.groupView.hidden = YES;
            self.contentLabelWidthLine.constant = kScreenW - size.width - 31;
            self.contentLabel.textAlignment = NSTextAlignmentLeft;
        }
            break;
        
       
        default:
            break;
    }
}

-(void)distinguishPhoneNumLabel:(UILabel *)label labelStr:(NSString *)labelStr{
    
    if (![self checkPhoneNumber:self.contentLabel.text]) {
        return;
    }
    //获取字符串中的电话号码
    NSString *regulaStr = @"\\d{3,4}[- ]?\\d{7,8}";
    NSRange stringRange = NSMakeRange(0, labelStr.length);
    //正则匹配
    NSError *error;
    
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc]initWithString:labelStr];
    
    NSRegularExpression *regexps = [NSRegularExpression regularExpressionWithPattern:regulaStr options:0 error:&error];
    if (!error && regexps != nil) {
        [regexps enumerateMatchesInString:labelStr options:0 range:stringRange usingBlock:^(NSTextCheckingResult * _Nullable result, NSMatchingFlags flags, BOOL * _Nonnull stop) {
            
            NSRange phoneRange = result.range;
            //定义一个NSAttributedstring接受电话号码字符串
           // phoneNumber = [str attributedSubstringFromRange:phoneRange];
            //添加下划线
            NSDictionary *attribtDic = @{NSUnderlineStyleAttributeName: [NSNumber numberWithInteger:NSUnderlineStyleSingle]};
            [str addAttributes:attribtDic range:phoneRange];
            //设置文本中的电话号码显示为黄色
            [str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"FF8200"] range:phoneRange];
            
            label.attributedText = str;
            label.userInteractionEnabled = YES;
            
            //添加手势，可以点击号码拨打电话
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapGesture:)];
            
            [label addGestureRecognizer:tap];
            
        }];
    }
    
}

//实现拨打电话的方法
-(void)tapGesture:(UITapGestureRecognizer *)sender{
    
    NSString *deviceType = [UIDevice currentDevice].model;
    if([deviceType  isEqualToString:@"iPod touch"]||[deviceType  isEqualToString:@"iPad"]||[deviceType  isEqualToString:@"iPhone Simulator"]){
        
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"提示" message:@"您的设备不能打电话" delegate:nil cancelButtonTitle:@"好的,知道了" otherButtonTitles:nil,nil];
        
        [alert show];
        
    }else{
        
         if ([self checkPhoneNumber:self.contentLabel.text]) {
        //NSAttributedstring转换为NSString
       // NSString *stringNum = [phoneNumber string];
       
             NSMutableString *str=[[NSMutableString alloc] initWithFormat:@"telprompt://%@",self.contentLabel.text];
             [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
             
           
         }else{
              [SVProgressHUD showErrorWithStatus:@"非正常电话格式"];
         }
    }
    
}


#pragma mark -拨打电话
- (IBAction)btnAction:(UIButton *)sender {
    if ([self checkPhoneNumber:self.contentLabel.text]) {
        NSMutableString *str=[[NSMutableString alloc] initWithFormat:@"telprompt://%@",self.contentLabel.text];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
    }
    else {
        [SVProgressHUD showErrorWithStatus:@"非正常电话格式"];
    }
}

- (UIViewController*)viewController {
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController*)nextResponder;
        }
    }
    return nil;
}

- (BOOL)checkPhoneNumber:(NSString *)phoneNumber {
    if(phoneNumber != nil) {
        if(phoneNumber.length >= 11) {
            NSString *number = @"";
            if([phoneNumber hasPrefix:@"+86"]) {
                number = [phoneNumber substringFromIndex:3];
            } else if([phoneNumber hasPrefix:@"86"]) {
                number = [phoneNumber substringFromIndex:2];
            } else {
                number = phoneNumber;
            }
            return [self isMobileNO:number];
        } else {
            return NO;
        }
    } else {
        return NO;
    }
}

- (BOOL)isMobileNO:(NSString *)phoneNumber {
    NSString *MOBILE = @"^1(3[0-9]|4[57]|5[0-35-9]|8[0-9]|7[06-8])\\d{8}$";
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", MOBILE];
    return [regextestmobile evaluateWithObject:phoneNumber];
}



#pragma mark -UICollectionView协议相关

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return [_selectedPhotos count];
}



- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    
    //查看图片
//    TZImagePickerController *imagePickerVc = [[TZImagePickerController alloc] initWithSelectedAssets:_selectedAssets selectedPhotos:_selectedPhotos index:indexPath.row];
//    imagePickerVc.allowPickingOriginalPhoto = NO;
//    imagePickerVc.isSelectOriginalPhoto = NO;
//    imagePickerVc.showSelectButton = NO;
//    [[self viewController] presentViewController:imagePickerVc animated:YES completion:nil];
    UIImage *image = _selectedPhotos[indexPath.row];
    [self showImage:image];

}

static CGRect oldframe;
- (void)showImage:(UIImage *)avatarImage{
    UIImage *image=avatarImage;
    UIWindow *window=[UIApplication sharedApplication].keyWindow;
    UIView *backgroundView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    oldframe=[self.contentView convertRect:self.contentView.bounds toView:window];
    backgroundView.backgroundColor=[UIColor blackColor];
    backgroundView.alpha=0;
    UIImageView *imageView=[[UIImageView alloc]initWithFrame:oldframe];
    imageView.image=image;
    imageView.tag=1;
    [backgroundView addSubview:imageView];
    [window addSubview:backgroundView];
    
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hideImage:)];
    [backgroundView addGestureRecognizer: tap];
    
    [UIView animateWithDuration:0.3 animations:^{
        imageView.frame=CGRectMake(0,([UIScreen mainScreen].bounds.size.height-image.size.height*[UIScreen mainScreen].bounds.size.width/image.size.width)/2, [UIScreen mainScreen].bounds.size.width, image.size.height*[UIScreen mainScreen].bounds.size.width/image.size.width);
        backgroundView.alpha=1;
    } completion:^(BOOL finished) {
        
    }];
}
-(void)hideImage:(UITapGestureRecognizer*)tap{
    UIView *backgroundView=tap.view;
    UIImageView *imageView=(UIImageView*)[tap.view viewWithTag:1];
    [UIView animateWithDuration:0.3 animations:^{
        imageView.frame=oldframe;
        backgroundView.alpha=0;
    } completion:^(BOOL finished) {
        [backgroundView removeFromSuperview];
    }];
}









@end
