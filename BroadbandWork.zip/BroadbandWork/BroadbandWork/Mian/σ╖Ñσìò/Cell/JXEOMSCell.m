//
//  JXWillDoOrderCell.m
//  JXWWNOP
//
//  Created by hqf on 2017/6/20.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//

#import "JXEOMSCell.h"

#define isnull(key,dict) dict[key] == nil || [dict[key] isKindOfClass:[NSNull class]] ? @"" : dict[key]


@implementation JXEOMSCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    _SecondTimeHeight.constant=16;
    _ThirdTimeHegiht.constant=16;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self.contentView setNeedsLayout];
    [self.contentView layoutIfNeeded];
    
  
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

#pragma mark - init cell

+ (instancetype)initCellWithTableView:(UITableView *)tableView
{
    
    static NSString *cellID=@"JXEOMSCell";
    JXEOMSCell *cell=[tableView dequeueReusableCellWithIdentifier:cellID];
    if(cell==nil)
    {
        // 从.xib中加载视图
        cell=[[[NSBundle mainBundle] loadNibNamed:@"JXEOMSCell" owner:nil options:nil] lastObject];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
    }
    return cell;
}


- (void)setModel:(NSDictionary *)model {
    
    //注意:这个字段mainAccessNumber在工单查询时接口返回的是mainAccessNum
    
    _model = model;
    _tittle.text    = isnull(@"title", _model);
    _sheetId.text   = isnull(@"id", _model);
    _Sendtime.text  =isnull(@"date1", _model);
     _sheetcomplte.text    = isnull(@"date2", _model);
    _taskdisplayname.text  = isnull(@"step", _model);
    _status.text= isnull(@"status", _model);
    NSString *taskStauts = [NSString stringWithFormat:@"%@",isnull(@"TASKSTATUS",_model)];
    if([_orderType isEqualToString:@"装机工单"]){
        
        _alramsolve.text = isnull(@"MAINALARMSOLVEDATE", _model);
         _img.image = [UIImage imageNamed:@"chaiji_icon"];
    }else  if([_orderType isEqualToString:@"拆机工单"]){
        
        _sheetcomplte.text =isnull(@"SHEETACCEPTLIMIT", _model);
        _alramsolve.text = isnull(@"SHEETCOMPLETELIMIT", _model);
        _firsttimelb.text=@"派单时间:";
        _secondtimelb.text=@"受理时限:";
        _thirdtimelb.text=@"完成时限:";
         _img.image = [UIImage imageNamed:@"kancha_icon"];
    }else  if([_orderType isEqualToString:@"预约工单"]){
        
        _sheetcomplte.text = isnull(@"SHEETCOMPLETELIMIT", _model);
        _BottomHeight.constant=0;
        _firsttimelb.text=@"派单时间:";
        _secondtimelb.text=@"完成时限:";
         _img.image = [UIImage imageNamed:@"kancha"];
    }else if([_orderType isEqualToString:@"投诉工单"]){
        
        _SecondTimeHeight.constant=0;
        _ThirdTimeHegiht.constant=0;
        _firstTimeHeight.constant=0;
        _secondtimelb.hidden=YES;
        _thirdtimelb.hidden=YES;
        _firsttimelb.hidden=YES;
        _firsttimelb.text=@"派单时间:";
        taskStauts = [NSString stringWithFormat:@"%@",isnull(@"STATUS",_model)];
        _img.image = [UIImage imageNamed:@"kanchazi"];
    }else if([_orderType isEqualToString:@"跳纤工单"]){
         _img.image = [UIImage imageNamed:@"tiaoxian_icon"];
    }else if([_orderType isEqualToString:@"勘察工单"]){
        _img.image = [UIImage imageNamed:@"tousu_icon"];
    }else if([_orderType isEqualToString:@"宽带配置工单"]){
        _img.image = [UIImage imageNamed:@"yuyue_icon"];
    }
    if ([taskStauts isEqualToString:@"8"]) {
        _status.text = @"已接单未处理";
        
    }
    else if([taskStauts isEqualToString:@"2"]){
        _status.text = @"未接单";
        
    }
    else if([taskStauts isEqualToString:@"5"]){
        _status.text = @"已处理";
       
    }
    
    NSString *tempOrderType = [NSString stringWithFormat:@"%@",isnull(@"orderType",_model)];
    NSString *hasReadFlag = [NSString stringWithFormat:@"%@",isnull(@"hasReadFlag",_model)];
    
    if ([tempOrderType isEqualToString:@""]) {
        tempOrderType = _orderType;
    }
    
}

- (BOOL)isPureNumandCharacters:(NSString *)string
{
    
    string = [string stringByTrimmingCharactersInSet:[NSCharacterSet decimalDigitCharacterSet]];
    if(string.length > 0)
    {
        return NO;
    }
    return YES;
}

@end
