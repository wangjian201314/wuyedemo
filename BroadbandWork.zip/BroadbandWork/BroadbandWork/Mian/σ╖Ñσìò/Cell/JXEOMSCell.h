//
//  JXWillDoOrderCell.h
//  JXWWNOP
//
//  Created by hqf on 2017/6/20.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JXEOMSCell : UITableViewCell

@property (strong, nonatomic)NSString *orderType;

@property (weak, nonatomic) IBOutlet UILabel *tittle;

@property (weak, nonatomic) IBOutlet UILabel *sheetId;
@property (weak, nonatomic) IBOutlet UILabel *Sendtime;
@property (weak, nonatomic) IBOutlet UILabel *sheetcomplte;
@property (weak, nonatomic) IBOutlet UILabel *alramsolve;
@property (weak, nonatomic) IBOutlet UILabel *status;
@property (weak, nonatomic) IBOutlet UILabel *taskdisplayname;

@property (weak, nonatomic) IBOutlet UIImageView *img;
@property (weak, nonatomic) IBOutlet UILabel *firsttimelb;
@property (weak, nonatomic) IBOutlet UILabel *secondtimelb;
@property (weak, nonatomic) IBOutlet UILabel *thirdtimelb;
+ (instancetype)initCellWithTableView:(UITableView *)tableView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *SecondTimeHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *ThirdTimeHegiht;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *BottomHeight;
@property(nonatomic,strong)NSDictionary *model;
@property (weak, nonatomic) IBOutlet UILabel *OderSectionText;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *firstTimeHeight;



@end
