//
//  JXEOMSMainCollectionViewCell.m
//  JXWWNOP
//
//  Created by wangjian on 2018/4/13.
//  Copyright © 2018年 cn.mastercom. All rights reserved.
//

#import "JXEOMSMainCollectionViewCell.h"

@implementation JXEOMSMainCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
