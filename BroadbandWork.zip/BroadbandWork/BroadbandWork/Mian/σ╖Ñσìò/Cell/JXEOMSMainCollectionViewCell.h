//
//  JXEOMSMainCollectionViewCell.h
//  JXWWNOP
//
//  Created by wangjian on 2018/4/13.
//  Copyright © 2018年 cn.mastercom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JXEOMSMainCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgview;
@property (weak, nonatomic) IBOutlet UILabel *textlb;

@end
