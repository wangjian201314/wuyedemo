//
//  JXOrderDetailCirculationTableViewCell.h
//  JXWWNOP
//
//  Created by hqf on 2017/6/27.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JXEomsDetailCirculationTableViewCell : UITableViewCell

- (void)refreshUI:(NSDictionary *)dataDic isLast:(BOOL)isLast isDrawLine:(BOOL)isDrawLine;
@property (weak, nonatomic) IBOutlet UILabel *titleNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *activeTemplateLabel;

@property (strong, nonatomic) NSString *orderType;   //工单类型
@end
