//
//  JXOrderEditCell.m
//  JXWWNOP
//
//  Created by hqf on 2017/6/30.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//
#import "JXOrderEditCell.h"
#import "Masonry.h"
#import "LxGridViewFlowLayout.h"
#import "TZTestImageCell.h"
#define CELLHMINEIGHT 44
#define CELLHTEXTEIGHT 80

#define kCollectionCellCount 4
#define isnull(key,dict) dict[key] == nil || [dict[key] isKindOfClass:[NSNull class]] ? @"" : dict[key]
@interface JXOrderEditCell() <UICollectionViewDataSource,UICollectionViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate,UIScrollViewDelegate>{
    /** 控件 */
    UILabel *_label1;
    UILabel *_label2;
    UILabel *_label3;
    UILabel *_label4;
    UILabel *_label5;//JXOrderEditCellButton
    UIButton *_button;
    UIButton *_button2;
    UIButton *_jumpAddbtn;
    UIImageView *_scanImageView;//扫一扫
    UIImageView *_SignatureImg;
    UIImage *_scanImage;
    UISwitch *_switch;
    UITextField *_textfield;
    //路由信息的view
    UIView *_mainJumpFiberView;
    //图片的collectionView
    UICollectionView *_collectionView;
    NSMutableArray *_btnarray;
    LxGridViewFlowLayout *_layout;
    
}

@end

@implementation JXOrderEditCell {
    
    CGFloat _itemWH;
    CGFloat _margin;
    NSIndexPath * _curSelectedIndexPath;//当前选择图片索引
    /** locationManager */

    NSString *_curLat;
    NSString *_curLng;
    NSString *_curAddress;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

#pragma mark - locationManagerDelegate


/**
 *  定位成功
 */


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}

- (instancetype)initWithType:(JXOrderEditCellType)cellType delegate:(id)delegate {
    if (self = [super init]) {
        self.delegate = delegate;
        self.cellType = cellType;
        self.ceng = 0;
        _btnarray=[NSMutableArray array];
        //grayLine
        UIView *grayLine = [[UIView alloc]init];
        grayLine.backgroundColor = [UIColor lightGrayColor];
        [self addSubview:grayLine];
        
        grayLine.translatesAutoresizingMaskIntoConstraints = NO;
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[grayLine]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(grayLine)]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[grayLine(0.5)]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(grayLine)]];
        
        self.height = CELLHMINEIGHT;
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        CGFloat label1w = (width-15)/3;
        
        //label1,label2
        _label1 = [[UILabel alloc]init];
        _label1.font = [UIFont systemFontOfSize:14];
        _label1.numberOfLines = 0;
        _label1.textColor = [UIColor blackColor];
        
        [self.contentView addSubview:_label1];
        _label2 = [[UILabel alloc]init];
        _label2.font = [UIFont systemFontOfSize:14];
        _label2.numberOfLines = 0;
        _label2.textColor = [UIColor lightGrayColor];
        _label2.userInteractionEnabled = YES;
        _label2.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:_label2];
        
       
        _textfield = [[UITextField alloc]init];
        _label1.translatesAutoresizingMaskIntoConstraints = NO;
        _label2.translatesAutoresizingMaskIntoConstraints = NO;
        if (cellType != JXOrderEditCellImage || cellType != JXOrderEditCellSwitch || cellType != JXOrderEditCellText ) {
            float rightEdge = 15;
            if(cellType == JXOrderEditCellScan) {
                rightEdge = 24;
            }
            if(cellType == JXOrderEditCellSwitch) {
                rightEdge = 96;
            }
            NSString *Hconst = [NSString stringWithFormat:@"H:|-5-[_label1(%f)]-5-[_label2]-(%f)-|",label1w,rightEdge];
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:Hconst options:0 metrics:nil views:NSDictionaryOfVariableBindings(_label1,_label2)]];
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-5-[_label2]-5-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_label2)]];
            [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:_label1 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
            [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:_label1 attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
        }
        
        if (cellType == JXOrderEditCellDate) {
            _label2.text = @"请选择时间";
            _label2.textColor = [UIColor lightGrayColor];
            
            //ic_calendar
            UIImageView *imagView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"ic_calendar"]];
            [_label2 addSubview:imagView];
            imagView.translatesAutoresizingMaskIntoConstraints = NO;
            [_label2 addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[imagView(20)]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(imagView)]];
            [_label2 addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[imagView(20)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(imagView)]];
            [_label2 addConstraint:[NSLayoutConstraint constraintWithItem:imagView attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:_label2 attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
            
        }
        else if (cellType == JXOrderEditCellLabel) {
            _label2.text = @"";
            _label2.textColor = [UIColor lightGrayColor];
            
   
            
        }
        else if (cellType == JXOrderEditCellLongText) {
            _label2.text = @"";
            _label2.textColor = [UIColor lightGrayColor];
            self.height = 82;
        }else if (cellType == JXOrderEditCellSingle || cellType == JXOrderEditCellMutiple) {
            _label2.text = @"请选择";
            _label2.textColor = [UIColor lightGrayColor];
            
            UIImageView *imagView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"bg_spinner"]];
            [self.contentView addSubview:imagView];
            imagView.translatesAutoresizingMaskIntoConstraints = NO;
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[imagView(15)]-8-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(imagView)]];
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[imagView(15)]-8-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(imagView)]];
            self.spinnerImgView = imagView;
        
        }else if (cellType == JXOrderEditCellScan) { //扫描
            //移除_label2
            NSArray *subViewArrs = [self.contentView subviews];
            for (UIView *view in subViewArrs) {
                if ([view isKindOfClass:[UILabel class]] && view ==_label2) {
                    [view removeFromSuperview];
                    break;
                }
            }
            
            _scanImageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"ic_scan"]];
            _scanImageView.userInteractionEnabled = YES;
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(buttonClick)];
            [_scanImageView addGestureRecognizer:tap];
            
            
            [self.contentView addSubview:_scanImageView];
            
            _scanImageView.translatesAutoresizingMaskIntoConstraints = NO;
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[_scanImageView(24)]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_scanImageView)]];
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[_scanImageView]-10-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_scanImageView)]];
            
            [self.contentView addSubview:_textfield];
            _textfield.font = [UIFont systemFontOfSize:14];
            _textfield.userInteractionEnabled = YES;
            _textfield.translatesAutoresizingMaskIntoConstraints = NO;
            _textfield.delegate = self;
            [_textfield addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
            NSString *Hconst = [NSString stringWithFormat:@"H:|-5-[_label1(%f)]-5-[_textfield]-72-|",label1w];
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:Hconst options:0 metrics:nil views:NSDictionaryOfVariableBindings(_label1,_textfield)]];
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-5-[_textfield]-5-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_textfield)]];
            [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:_label1 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
            [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:_label1 attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
            
        }else if (cellType == JXOrderEditCellImage) { //多图片
            self.height = 120;
            //移除_label2
            NSArray *subViewArrs = [self.contentView subviews];
            for (UIView *view in subViewArrs) {
                if ([view isKindOfClass:[UILabel class]] && view ==_label2) {
                    [view removeFromSuperview];
                    break;
                }
            }
            //加_collectionView
            _layout = [[LxGridViewFlowLayout alloc] init];
            _margin = 8;
            _itemWH = ([UIScreen mainScreen].bounds.size.width - 5*_margin - 50) / kCollectionCellCount;
            _layout.itemSize = CGSizeMake(_itemWH, _itemWH);
            _layout.minimumLineSpacing = _margin;
            _layout.minimumInteritemSpacing = _margin;
            _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:_layout];
//            _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero];
            _collectionView.backgroundColor = [UIColor whiteColor];
            _collectionView.contentInset = UIEdgeInsetsMake(10, 0, 15, 0);
            _collectionView.dataSource = self;
            _collectionView.delegate = self;
            _collectionView.scrollEnabled = NO;
            [self.contentView addSubview:_collectionView];
            [_collectionView registerClass:[TZTestImageCell class] forCellWithReuseIdentifier:@"TZTestImageCell"];
            _collectionView.translatesAutoresizingMaskIntoConstraints=NO;
            
            
            NSString *Hconst = [NSString stringWithFormat:@"H:|-5-[_label1(%f)]-5-[_collectionView]-5-|",label1w];
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:Hconst options:0 metrics:nil views:NSDictionaryOfVariableBindings(_label1,_collectionView)]];
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-5-[_collectionView]-5-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_collectionView)]];
            [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:_label1 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
            [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:_label1 attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
            
        }
        else if(cellType == JXOrderEditCellSwitch) {
            //移除_label2
//            NSArray *subViewArrs = [self.contentView subviews];
//            for (UIView *view in subViewArrs) {
//                if ([view isKindOfClass:[UILabel class]] && view ==_label2) {
//                    [view removeFromSuperview];
//                    break;
//                }
//            }
            _switch = [[UISwitch alloc]init];
            _switch.translatesAutoresizingMaskIntoConstraints = NO;
            [self.contentView addSubview:_switch];
            [_switch addTarget:self action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];
            
            NSString *Hconst = [NSString stringWithFormat:@"H:[_switch(%f)]-8-|",60.0];
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:Hconst options:0 metrics:nil views:NSDictionaryOfVariableBindings(_switch)]];
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-5-[_switch]-5-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_switch)]];
            [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:_label1 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
            [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:_label1 attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
            
        }
        else if(cellType == JXOrderEditCellButton) {//按钮
            //移除_label2
            NSArray *subViewArrs = [self.contentView subviews];
            for (UIView *view in subViewArrs) {
                if ([view isKindOfClass:[UILabel class]] && view ==_label2) {
                    [view removeFromSuperview];
                    break;
                }
            }
            
            _label5 = [[UILabel alloc]init];
            _label5.font = [UIFont systemFontOfSize:14];
            _label5.numberOfLines = 0;
            _label5.textColor = self.mainColor?self.mainColor:[UIColor colorWithHexString:@"#0B8CD3"];
            _label5.userInteractionEnabled = YES;
            _label5.textAlignment = NSTextAlignmentRight;
            [self.contentView addSubview:_label5];
            _button = [UIButton buttonWithType:UIButtonTypeCustom];
            _button.enabled = YES;
            [_button addTarget:self action:@selector(buttonClick) forControlEvents:UIControlEventTouchUpInside];
//            UIImage * normalImage = [UIImage imageNamed:@"icon_getlightcat"];
//            [_button setImage:normalImage forState:UIControlStateNormal];
            [self.contentView addSubview:_button];
//            [_button setAdjustsImageWhenHighlighted:NO];
            _button.translatesAutoresizingMaskIntoConstraints = NO;
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[_button(75)]-16-|"  options:0 metrics:nil views:NSDictionaryOfVariableBindings(_button)]];
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-6-[_button]-6-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_button)]];
            [_label5 mas_makeConstraints:^(MASConstraintMaker *make) {
                make.bottom.equalTo(self).offset(0);
                make.left.equalTo(self).offset(80);
                make.right.equalTo(self).offset(-100);
                make.top.equalTo(@0);
            }];
        }
        
        else if(cellType == JXOrderEditCellbtn) {//按钮
            
            _label1.hidden=YES;
            _label2.hidden=YES;
            _button2 = [UIButton buttonWithType:UIButtonTypeCustom];
            _button2.frame=self.frame;
            NSLog(@"_button2=========%.1f,%.1f",[UIScreen mainScreen].bounds.size.width,self.frame.size.height);
            //_button2.backgroundColor=[UIColor redColor];
            [_button2 setTitle:@"重置" forState:UIControlStateNormal];
            _button2.titleLabel.textAlignment=NSTextAlignmentCenter;
            [_button2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            _button2.titleLabel.font=[UIFont systemFontOfSize:16];
            //_button2.backgroundColor=[UIColor whiteColor];
            _button2.enabled = YES;
            [_button2 addTarget:self action:@selector(buttonClick) forControlEvents:UIControlEventTouchUpInside];
            
            [self.contentView addSubview:_button2];
            _button2.translatesAutoresizingMaskIntoConstraints = NO;
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[_button2]-0-|"  options:0 metrics:nil views:NSDictionaryOfVariableBindings(_button2)]];
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[_button2]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_button2)]];
            
        }else if (cellType ==JXOrderEditCellselectbtn){
            
            _label1.hidden=YES;
            _label2.hidden=YES;
            _label3 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 30)];
            _label3.font = [UIFont systemFontOfSize:14];
            _label3.numberOfLines = 0;
            _label3.userInteractionEnabled = YES;
            _label3.textAlignment = NSTextAlignmentLeft;
            [self.contentView addSubview:_label3];
            
            _label4 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 30, 20)];
            _label4.font = [UIFont systemFontOfSize:14];
            _label4.numberOfLines = 0;
            _label4.hidden=YES;
            _label4.text=@"品牌:";
            _label4.userInteractionEnabled = YES;
            _label4.textAlignment = NSTextAlignmentLeft;
            [self.contentView addSubview:_label4];
           
            _textfield = [[UITextField alloc]init];
            _textfield.hidden=YES;
            [self.contentView addSubview:_textfield];
            _textfield.font = [UIFont systemFontOfSize:14];
            _textfield.userInteractionEnabled = YES;
            _textfield.delegate = self;
            
            self.height = 65;
        }else if(cellType==JXOrderEditCellSignature){
            
            _label2.hidden=YES;
            _SignatureImg=[[UIImageView alloc]initWithFrame:CGRectMake(80, 10, 100, 100)];
           // _SignatureImg.backgroundColor=[UIColor grayColor];
            [self.contentView addSubview:_SignatureImg];
            _button3 = [UIButton buttonWithType:UIButtonTypeCustom];
            _button3.backgroundColor = [UIColor colorWithHexString:@"0X2496F8"];
            _button3.titleLabel.textColor = [UIColor whiteColor];
             [_button3 setTitle:@"开始签名" forState:UIControlStateNormal];
            _button3.titleLabel.font = [UIFont systemFontOfSize:11.0f];
            _button3.layer.cornerRadius = 8.0f;
            _button3.frame=CGRectMake([UIScreen mainScreen].bounds.size.width-80, 45, 70, 30);
            _button3.enabled = YES;
            [_button3 addTarget:self action:@selector(buttonClick) forControlEvents:UIControlEventTouchUpInside];
            [self.contentView addSubview:_button3];
            
         
            self.height=120;
        }else if(cellType==JXOrderEditCellTextfiled){
            
            _label2.hidden=YES;
            _textfield.frame=CGRectMake([UIScreen mainScreen].bounds.size.width-250, 0, 230, 44);
            _textfield.textAlignment=NSTextAlignmentRight;
            _textfield.textColor=[UIColor colorWithHexString:@"#0B8CD3"];
            _textfield.font = [UIFont systemFontOfSize:14];
            _textfield.userInteractionEnabled = YES;
            _textfield.delegate = self;
             [self.contentView addSubview:_textfield];
            self.height=44;
            
            
        }
        else if(cellType == JXOrderEditCellText) { //输入
            //移除_label2
            NSArray *subViewArrs = [self.contentView subviews];
            for (UIView *view in subViewArrs) {
                if ([view isKindOfClass:[UILabel class]] && view ==_label2) {
                    [view removeFromSuperview];
                    break;
                }
            }
            
            _textfield = [[UITextField alloc]init];
            [self.contentView addSubview:_textfield];
            _textfield.font = [UIFont systemFontOfSize:14];
            _textfield.userInteractionEnabled = YES;
            _textfield.translatesAutoresizingMaskIntoConstraints = NO;
            _textfield.delegate = self;
            NSString *Hconst = [NSString stringWithFormat:@"H:|-5-[_label1(%f)]-5-[_textfield]-55-|",label1w];
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:Hconst options:0 metrics:nil views:NSDictionaryOfVariableBindings(_label1,_textfield)]];
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-5-[_textfield]-5-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_textfield)]];
            [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:_label1 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
            [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:_label1 attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
            
        }
        else if(cellType == JXOrderEditCellPaybtn) { //输入
            //移除_label2
            NSArray *subViewArrs = [self.contentView subviews];
            for (UIView *view in subViewArrs) {
              [view removeFromSuperview];
            }
            NSArray *arr=@[@"线上支付",@"线下支付",@"支付结果查询"];
            UIButton *btn1=[[UIButton alloc]initWithFrame:CGRectMake(10,7, 80, 30)];
            btn1.layer.cornerRadius=8.0f;
            btn1.titleLabel.font = [UIFont systemFontOfSize:12.0f];
            btn1.backgroundColor = [UIColor colorWithHexString:@"#9ACD32"];
            [btn1 setTitle:arr[0] forState:UIControlStateNormal];
            [btn1 addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
            [self.contentView addSubview:btn1];
            
            UIButton *btn2=[[UIButton alloc]initWithFrame:CGRectMake((kScWidth-100)/2,7, 100, 30)];
            btn2.layer.cornerRadius=8.0f;
            btn2.hidden=YES;
            btn2.titleLabel.font = [UIFont systemFontOfSize:12.0f];
            btn2.backgroundColor = [UIColor colorWithHexString:@"#9ACD32"];
            [btn2 setTitle:arr[1] forState:UIControlStateNormal];
            [btn2 addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
            [self.contentView addSubview:btn2];
            
            UIButton *btn3=[[UIButton alloc]initWithFrame:CGRectMake(kScWidth-100,7, 90, 30)];
            btn3.layer.cornerRadius=8.0f;
            btn3.titleLabel.font = [UIFont systemFontOfSize:12.0f];
            btn3.backgroundColor = [UIColor colorWithHexString:@"#9ACD32"];
            [btn3 setTitle:arr[2] forState:UIControlStateNormal];
            [btn3 addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
            [self.contentView addSubview:btn3];
            
        }
        //跳纤工单里面的路由信息
        else if(cellType == JXOrderEditCellJumpFiber) {
            //移除_label2,_label1
            NSArray *subViewArrs = [self.contentView subviews];
            for (UIView *view in subViewArrs) {
                if ([view isKindOfClass:[UILabel class]] && (view ==_label1 || view ==_label2 )) {
                    [view removeFromSuperview];
                    break;
                }
            }
            
        }
        
        else {
            _label2.text = @"请输入";
            _label2.textColor = [UIColor lightGrayColor];
        }
        
        if (!(  cellType == JXOrderEditCellSwitch || cellType == JXOrderEditCellImage  || cellType == JXOrderEditCellButton ||  cellType == JXOrderEditCellJumpFiber )) {
            _button = [UIButton buttonWithType:UIButtonTypeCustom];
            _button.backgroundColor = [UIColor clearColor];
            [_button addTarget:self action:@selector(buttonClick) forControlEvents:UIControlEventTouchUpInside];
//            [_button setAdjustsImageWhenHighlighted:NO];
            [_label2 addSubview:_button];
            _button.translatesAutoresizingMaskIntoConstraints = NO;
            [_label2 addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[_button]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_button)]];
            [_label2 addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[_button]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_button)]];
        }
       

    }
    return self;

}

#pragma mark - buttonClick
- (void)buttonClick {
    
    if (self.delegate&&[self.delegate respondsToSelector:@selector(didSelectedOrderEditCell:)]) {
        [self.delegate didSelectedOrderEditCell:self];
    }
}

#pragma mark--多个按钮只选中一个
- (void)btnClick:(UIButton *)btn{
    
    //btn.selected=!btn.selected;
    
    if (btn!= self.selectedBtn) {
        self.selectedBtn.selected = NO;
        btn.selected = YES;
        self.selectedBtn = btn;
    }else{
        self.selectedBtn.selected = YES;
    }
    
    if (self.delegate&&[self.delegate respondsToSelector:@selector(didSelectedOrderEditCell:)]) {
        [self.delegate didSelectedOrderEditCell:self];
    }
}

#pragma mark - switchAction
- (void)switchAction:(id)sender {
    BOOL isSwitchOn = [_switch isOn];
    if (self.delegate&&[self.delegate respondsToSelector:@selector(didChangeSwitch:isSwitchOn:)]) {
        [self.delegate didChangeSwitch:self isSwitchOn:isSwitchOn];
    }
}


#pragma mark - Setter

- (void)setColumn:(NSString *)column {
    if (column == nil) {
        return;
    }
    
    if ([column hasPrefix:@"*"]) {
        _showColumn = column;
        NSString *cleanStr = [[column componentsSeparatedByString:@"*"] lastObject];
        _column = cleanStr;
        
        NSString *redPart = @"*";
        NSString *text = [NSString stringWithFormat:@"%@:",column];
        
            if(_isSiglejumper==NO){
                
                if([column containsString:@"OLT名称"]){
                    text=@"*设备名称:";
                }else if([column containsString:@"OLT相片"]){
                    text=@"*设备相片:";
                }
            }
        if([column containsString:@"用户设备是否IHGU光猫换机"]){
            text=@"用户设备是否IHGU";
        }
        if([column containsString:@"HITV进销存验证是否通过"]){
            text=@"*进销存验证是否通过";
        }
        NSMutableAttributedString *newStr = [[NSMutableAttributedString alloc] initWithString:text];
        NSRange redRange = NSMakeRange([[newStr string] rangeOfString:redPart].location, [[newStr string] rangeOfString:redPart].length);
        [newStr addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:redRange];
        [_label1 setAttributedText:newStr];
        _necessary = YES;
        
    }else{
        _showColumn = column;
        _column     = column;
        _label1.text= [NSString stringWithFormat:@"%@:",column];
        if([_column isEqualToString:@"宽带上网账号:"]){
            
            _label1.text= column;
        }
        if([_column isEqualToString:@"其他图片"]){
            
            _label1.text= @"其他:";
        }
        _necessary = NO;
        
      
            if([_column isEqualToString:@"标签打印"]){
                
                _label1.hidden=YES;
            }
        
        if(_cellType==JXOrderEditCellbtn){
            
           [_button2 setTitle:column forState:UIControlStateNormal];
        }
    }
    
    if(_cellType==JXOrderEditCellselectbtn){
        
        NSString *redPart = @"*";
        NSMutableAttributedString *newStr = [[NSMutableAttributedString alloc] initWithString:column];
        NSRange redRange = NSMakeRange([[newStr string] rangeOfString:redPart].location, [[newStr string] rangeOfString:redPart].length);
        [newStr addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:redRange];
        [_label3 setAttributedText:newStr];
        CGSize theStringSize = [column sizeWithFont:[UIFont systemFontOfSize:15]constrainedToSize:CGSizeMake([UIScreen mainScreen].bounds.size.width, 60)
                                      lineBreakMode:0];
        _label3.frame=CGRectMake(_label3.frame.origin.x, _label3.frame.origin.y, [UIScreen mainScreen].bounds.size.width, theStringSize.height);
        if([column containsString:@"使用路由器"]){
            
            _label4.hidden=NO;
            _textfield.hidden=NO;
            _label4.frame=CGRectMake(20, CGRectGetMaxY(_label3.frame)+50, 40, 20);
            _textfield.placeholder=@"请输入品牌";
            _textfield.frame=CGRectMake(CGRectGetMaxX(_label4.frame), CGRectGetMaxY(_label3.frame)+50, [UIScreen mainScreen].bounds.size.width-_label4.frame.size.width-30, 20);
            self.height=100;
        }
    }else if (_cellType==JXOrderEditCellButton){
        
        _label1.font  = [UIFont fontWithName:nil size:14];
        CGFloat height = [_label1.text boundingRectWithSize:CGSizeMake((kScWidth-15)/3 , MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14]} context:nil].size.height;
        self.height=height<44?44:height;
    }
  
}

- (void)setArray:(NSArray *)array{
    
    NSArray *arr=array;
    for(int i=0;i<arr.count;i++){
        
        UIButton *btn=[[UIButton alloc]initWithFrame:CGRectMake(20+100*i, CGRectGetMaxY(_label3.frame)+10, 20, 20)];
        [btn setImage:[UIImage imageNamed:@"check1"] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@"check2"] forState:UIControlStateSelected];
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        UILabel *lb=[[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(btn.frame)+5, CGRectGetMaxY(_label3.frame)+10, 85, 20)];
        lb.text=arr[i];
        lb.textAlignment=NSTextAlignmentLeft;
        lb.font = [UIFont systemFontOfSize:13];
        [self.contentView addSubview:btn];
        [self.contentView addSubview:lb];
    }
}

- (void)setShowimg:(UIImage *)showimg{
    
    _SignatureImg.image=showimg;
}

- (void)setValue:(NSString *)value {
    _value = value;
    if (value == nil) {
        _label2.textColor = [UIColor lightGrayColor];
        if (self.cellType == JXOrderEditCellDate) {
            _label2.text = @"请选择时间";
        }else if (self.cellType == JXOrderEditCellLongText) {
            _label2.text = @"请输入";
        }else if (self.cellType == JXOrderEditCellSingle||self.cellType == JXOrderEditCellMutiple) {
            _label2.text = @"请选择";
        }else if (self.cellType == JXOrderEditCellScan) {
            _label2.text = @"扫一扫";
        }else if (self.cellType == JXOrderEditCellLabel) {
            _label2.text = _value;
        }else if (self.cellType == JXOrderEditCellImage) {
            _label2.text = @"";
        }else if (self.cellType == JXOrderEditCellText) {
            _textfield.text = value;
        }else if (self.cellType == JXOrderEditCellTextfiled) {
            _textfield.text = value;
        }else if (self.cellType == JXOrderEditCellButton) {
            _label2.text = @"";
        }
    }else{
        if([_column isEqualToString:@"应收金额"] || [_column isEqualToString:@"支付结果"]){
            _label2.textColor=[UIColor redColor];
            _textfield.textColor=[UIColor redColor];
        }else{
            _label2.textColor = self.mainColor?self.mainColor:[UIColor colorWithHexString:@"#0B8CD3"];
        }
        if ([value isKindOfClass:[NSString class]]) {
            if([value isEqualToString:@"空"]) {
                _label2.text = @"";
            }else{
                _label2.text = value;
                _textfield.text = value;
                _label5.text=value;
            }
        }
        CGSize titleSize = [_label2.text sizeWithFont:[UIFont systemFontOfSize:14] constrainedToSize:CGSizeMake(kScWidth-200, MAXFLOAT) lineBreakMode:0];
        CGSize titleSize5 = [_label5.text sizeWithFont:[UIFont systemFontOfSize:14] constrainedToSize:CGSizeMake(kScWidth-180, MAXFLOAT) lineBreakMode:0];
        
        if (self.cellType == JXOrderEditCellText || self.cellType == JXOrderEditCellLabel ) {
           
            self.height=titleSize.height<44?44:titleSize.height;
        }
        if( self.cellType==JXOrderEditCellButton){
            self.height=titleSize5.height<44?44:titleSize5.height;
        }
        if (self.cellType == JXOrderEditCellImage) {
            
            self.height=120;
        }
        
        
    }
}

- (void)setPlaceholder:(NSString *)placeholder {
    _placeholder = placeholder;
    if (placeholder != nil) {
        
            _textfield.placeholder = placeholder;
            if(_isSiglejumper==NO){
                
                if([placeholder containsString:@"OLT名称"]){
                    _textfield.placeholder = @"请填写设备名称";
                    
                }
            }
        if(self.cellType==JXOrderEditCellLongText){
            
             _label2.text = placeholder;
        }
        
    }
}

- (void)setSwitchOn:(NSString *)isSwithcOn {
    if([isSwithcOn isEqualToString:@"是"]){
        _switch.on = YES;
        
    }
    else {
        _switch.on = NO;

    }
}

- (void)setUnClick:(BOOL)unClick {
    _unClick = unClick;
    if(_unClick)
    {
        if([_column isEqualToString:@"支付结果"]){
            _label1.textColor = [UIColor blackColor];
        }else{
           // _label1.textColor = [UIColor lightGrayColor];
        }
        _label2.enabled = NO;
        _button.enabled = NO;
        _textfield.enabled=NO;
    }
}

- (void)setbuttonImage:(NSString *)imageName {
    if (_button) {
        
        //如果图片名带后缀，则使用该图片，否则使用按钮
        if (![imageName containsString:@"."]) {
            _button.backgroundColor = [UIColor colorWithHexString:@"0X2496F8"];
            _button.titleLabel.textColor = [UIColor whiteColor];
//            _button.titleLabel.text = imageName;
            [_button setTitle:imageName forState:UIControlStateNormal];
            _button.titleLabel.font = [UIFont systemFontOfSize:11.0f];
            _button.layer.cornerRadius = 8.0f;
        }
        else {
            UIImage * normalImage = [UIImage imageNamed:imageName];
            
            for (UIView *itemView in self.contentView.subviews) {
                if (itemView == _button) {
                    [_button removeFromSuperview];
                }
            }
            CGSize imageSize = normalImage.size;
            float btnwidth = (imageSize.width/imageSize.height)*(self.height - 12);
            [self.contentView addSubview:_button];
            //            [_button setAdjustsImageWhenHighlighted:NO];
            _button.translatesAutoresizingMaskIntoConstraints = NO;
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"H:[_button(%f)]-16-|",btnwidth-15]  options:0 metrics:nil views:NSDictionaryOfVariableBindings(_button)]];
            [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-6-[_button(35)]-6-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_button)]];
            //垂直居中
            [self addConstraint:[NSLayoutConstraint constraintWithItem:_button
                                                                  attribute:NSLayoutAttributeCenterY
                                                                  relatedBy:NSLayoutRelationEqual
                                                                     toItem:self
                                                                  attribute:NSLayoutAttributeCenterY
                                                                 multiplier:1
                                                                   constant:0]];
            if([imageName isEqualToString:@"ic_yjfz.png"] || [imageName isEqualToString:@"ic_yjhq.png"]){
                [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-6-[_button(25)]-6-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_button)]];
            }
            if([imageName isEqualToString:@"icon_delete.png"]){
                [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"H:[_button(30)]-16-|"]  options:0 metrics:nil views:NSDictionaryOfVariableBindings(_button)]];
                [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[_button(20)]-10-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_button)]];
            }
            _button.imageView.hidden = NO;
            [_button setBackgroundImage:normalImage forState:UIControlStateNormal];
        }
    }
}

- (void)setMaxImageCount:(NSInteger)maxImageCount {
    _maxImageCount = maxImageCount;
    
}



#pragma mark - UICollectionView协议相关

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    [_collectionView.collectionViewLayout invalidateLayout];
    
    if(self.selectedPhotos.count<_maxImageCount)
    {
        return [self.selectedPhotos count]+1;
    }
    else{
        return [self.selectedPhotos count];
    }
    
    
}




- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    TZTestImageCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"TZTestImageCell" forIndexPath:indexPath];
    NSInteger allCount = self.selectedPhotos.count + 1;
    if (indexPath.row == allCount-1) {
        //添加按钮
        cell.imageView.image = [UIImage imageNamed:@"AlbumAddBtn1.png"];
        cell.deleteBtn.hidden = YES;
        cell.bottomLabel.text = @"添加图片";
    } else {
        //正常图片
        cell.imageView.image = self.selectedPhotos[indexPath.row];
        cell.deleteBtn.hidden = NO;
        cell.bottomLabel.text = @"";
    }
    cell.deleteBtn.tag = indexPath.row+250;
    [cell.deleteBtn addTarget:self action:@selector(deleteBtnClik:) forControlEvents:UIControlEventTouchUpInside];
    
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    _curSelectedIndexPath = indexPath;
    
}

- (NSData *)compressQualityWithMaxLength:(NSInteger)maxLength showimg:(UIImage *)img {
    CGFloat compression = 1;
    NSData *data = UIImageJPEGRepresentation(img, compression);
    while (data.length > maxLength && compression > 0) {
        compression -= 0.02;
        data = UIImageJPEGRepresentation(img, compression); // When compression less than a value, this code dose not work
    }
    return data;
}



UIScrollView *scroll;
UIImageView *  imagev;



- (void)hideimg:(UITapGestureRecognizer *)tap{
    
    [scroll removeFromSuperview];
    scroll=nil;
    [imagev removeFromSuperview];
    imagev=nil;
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    
    return imagev;
}

- (void)scrollViewDidZoom:(UIScrollView *)scrollView {
    
    CGRect frame = imagev.frame;
    
    frame.origin.y = (scroll.frame.size.height - imagev.frame.size.height) > 0 ? (scroll.frame.size.height - imagev.frame.size.height) * 0.5 : 0;
    frame.origin.x = (scroll.frame.size.width - imagev.frame.size.width) > 0 ? (scroll.frame.size.width - imagev.frame.size.width) * 0.5 : 0;
    imagev.frame = frame;
    
    scroll.contentSize = CGSizeMake(imagev.frame.size.width + 30, imagev.frame.size.height + 30);
}


//缩放图片加水印
-(UIImage *)cropImage:(UIImage *)image scale:(CGFloat)scale
{
    NSString *userName ;//= [MTGlobalInfo sharedInstance].userName;
    NSString *currentTime ;///=[NSDate stringFromDate:[NSDate date] dateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    CGSize newSize = CGSizeMake(image.size.width*scale, image.size.height*scale);
    UIGraphicsBeginImageContext(newSize);
    [image drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
    image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
 
    NSString *mark = [NSString stringWithFormat:@"拍摄人:%@\n时间:%@\n经度:%@  纬度:%@\n%@" ,userName,currentTime,_curLng,_curLat,_curAddress];

    
    int w = image.size.width;
    int h = image.size.height;
    UIGraphicsBeginImageContext(image.size);
    [[UIColor redColor] set];
    [image drawInRect:CGRectMake(0, 0, w, h)];
    UIFont *markFont = [UIFont systemFontOfSize:20];
    //图片太小时，水印字体变小
    if (w < 150 || h < 150) {
        markFont = [UIFont systemFontOfSize:12];
    }
    [mark drawInRect:CGRectMake(10, 10, w, 182) withAttributes:@{NSFontAttributeName: markFont,NSForegroundColorAttributeName:[UIColor redColor]}];

    UIImage *aimg = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return aimg;
}



static CGRect oldframe;
- (void)showImage:(UIImage *)avatarImage{
    UIImage *image=avatarImage;
    UIWindow *window=[UIApplication sharedApplication].keyWindow;
    UIView *backgroundView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    oldframe=[self.contentView convertRect:self.contentView.bounds toView:window];
    backgroundView.backgroundColor=[UIColor blackColor];
    backgroundView.alpha=0;
    UIImageView *imageView=[[UIImageView alloc]initWithFrame:oldframe];
    imageView.image=image;
    imageView.tag=1;
    [backgroundView addSubview:imageView];
    [window addSubview:backgroundView];
    
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hideImage:)];
    [backgroundView addGestureRecognizer: tap];
    
    [UIView animateWithDuration:0.3 animations:^{
        imageView.frame=CGRectMake(0,([UIScreen mainScreen].bounds.size.height-image.size.height*[UIScreen mainScreen].bounds.size.width/image.size.width)/2, [UIScreen mainScreen].bounds.size.width, image.size.height*[UIScreen mainScreen].bounds.size.width/image.size.width);
        //imageView.frame=CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
        backgroundView.alpha=1;
    } completion:^(BOOL finished) {
        
    }];
}
-(void)hideImage:(UITapGestureRecognizer*)tap{
    UIView *backgroundView=tap.view;
    UIImageView *imageView=(UIImageView*)[tap.view viewWithTag:1];
    [UIView animateWithDuration:0.3 animations:^{
        imageView.frame=oldframe;
        backgroundView.alpha=0;
    } completion:^(BOOL finished) {
        [backgroundView removeFromSuperview];
    }];
}



- (void)saveRouteInfo {
    

    if (self.delegate&&[self.delegate respondsToSelector:@selector(saveJumpFiberInfo:)]) {
        [self.delegate saveJumpFiberInfo:_jumpFiberInfo];
    }
}

- (void)addfirstjump{
    
    if (self.delegate&&[self.delegate respondsToSelector:@selector(addFirstJumpFiberInfo)]) {
        [self.delegate addFirstJumpFiberInfo];
    }
    if(_jumpFiberInfo==nil || _jumpFiberInfo.count==0){
           
    }
    
   
}
#pragma mark - 添加图片

- (void)pushImagePickerControllerWithMaxCount:(NSInteger)maxCount {

    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.sourceType = sourceType;
        [[self viewController] presentViewController:picker animated:YES completion:nil];
    }else
    {
        NSLog(@"模拟其中无法打开照相机,请在真机中使用");
    }
}


//当选择一张图片后进入这里
//-(void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
//{
//    NSString *type = [info objectForKey:UIImagePickerControllerMediaType];
//    //当选择的类型是图片
//    if ([type isEqualToString:@"public.image"])
//    {
//        UIImage* image = [info objectForKey:UIImagePickerControllerOriginalImage];
//
//        UIImage *  tempImg= [ImageUtil scaleSizeImage:image Size:CGSizeMake(800, 800)] ;
//        if (_selectedPhotos == nil) {
//            _selectedPhotos = [[NSMutableArray alloc]init];
//        }
//        if (_selectedNames == nil) {
//            _selectedNames = [[NSMutableArray alloc]init];
//        }
//        _selectedPhotos =[_selectedPhotos mutableCopy] ;
//        _selectedNames =[_selectedNames mutableCopy] ;
//        [_selectedPhotos  addObject:tempImg];
//        [_selectedNames addObject:[NSString stringWithFormat:@"%ld.jpg",(long)[[NSDate date]timeIntervalSince1970]]];
//
//        //关闭相册界面
//        [picker dismissViewControllerAnimated:YES completion:nil];
//    }
//    _layout.itemCount = _selectedPhotos.count;
//
//    [_collectionView reloadData];
//
//    if (self.delegate&&[self.delegate respondsToSelector:@selector(didEditedCellImage:editType:)]) {
//        [self.delegate didEditedCellImage:self editType:0];
//    }
//
//}

//删除图片
- (void)deleteBtnClik:(UIButton *)sender  {
    [_selectedPhotos removeObjectAtIndex:sender.tag -250];
    [_selectedNames removeObjectAtIndex:sender.tag -250];
    _layout.itemCount = _selectedPhotos.count;
    
    [_collectionView reloadData];
    if (self.delegate&&[self.delegate respondsToSelector:@selector(didEditedCellImage:editType:)]) {
        [self.delegate didEditedCellImage:self editType:1];
    }

}


#pragma mark -UITextField协议相关
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField {
    if ([self.column containsString:@"接线子(个)"]||[self.column containsString:@"皮线光缆(米)"]
        ||[self.column containsString:@"冷接子(个)"] ||[self.column containsString:@"热熔尾纤(根)"]
        ||[self.column containsString:@"隐形光缆(米)"] ||[self.column containsString:@"扁平网线(米)"]
        ||[self.column containsString:@"光猫(个)"] ||[self.column containsString:@"网线(米)"]
        ||[self.column containsString:@"水晶头(个)"] ||[self.column containsString:@"机顶盒(台)"]
        ) {
        _textfield.keyboardType = UIKeyboardTypeNumberPad;
    }
}

-(void)textFieldDidEndEditing:(UITextField *)textField {
    if (self.delegate&&[self.delegate respondsToSelector:@selector(didEditedCell:text:)]) {
        [self.delegate didEditedCell:self text:textField.text];
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    BOOL res = YES;
    if ([self.column containsString:@"接线子(个)"]||[self.column containsString:@"皮线光缆(米)"]
        ||[self.column containsString:@"冷接子(个)"] ||[self.column containsString:@"热熔尾纤(根)"]
        ||[self.column containsString:@"隐形光缆(米)"] ||[self.column containsString:@"扁平网线(米)"]
        ||[self.column containsString:@"光猫(个)"] ||[self.column containsString:@"网线(米)"]
        ||[self.column containsString:@"水晶头(个)"] ||[self.column containsString:@"机顶盒(台)"]
        ) {
        NSCharacterSet* tmpSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
        int i = 0;
        while (i < string.length) {
            NSString * tempstring = [string substringWithRange:NSMakeRange(i, 1)];
            NSRange range = [tempstring rangeOfCharacterFromSet:tmpSet];
            if (range.length == 0) {
                res = NO;
                break;
            }
            i++;
        }
        
    }else if ([self.column containsString:@"光猫"] || [self.column containsString:@"MAC"] || [self.column containsString:@"HITV(SN)"]){
        
        NSString *tem = [[string componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]componentsJoinedByString:@""];
        if (![string isEqualToString:tem]) {
            return NO;//限制空格
        }
        if (range.length == 1 && string.length == 0) {
            return YES;
        }
        if(textField.text.length>=12 && [self.column containsString:@"MAC"]){
            textField.text = [textField.text substringToIndex:12];
            return NO;
        }
        char lowercaseChar = [string characterAtIndex:0];
        
        if (lowercaseChar > 96 && lowercaseChar < 123) {
            
            NSString * uppercaseString = string.uppercaseString;
            NSString * frontStr = [textField.text substringToIndex:range.location];
            NSString * backStr = [textField.text substringFromIndex:range.location];
            textField.text = [NSString stringWithFormat:@"%@%@%@",frontStr,uppercaseString,backStr];
            
            NSRange ranges=range;
            ranges.location=ranges.location+1;
//            [textField setSelectedRange:ranges];//改变光标的位置
           
            return NO;
        }
        
    }
    
    
    return res;
}

- (void)textFieldDidChange:(UITextField *)sender{
    if(sender.text.length>12 && [self.column containsString:@"MAC"]){
        sender.text = [sender.text substringToIndex:12];
    }
}

#pragma mark - selfVC

- (UIViewController*) viewController {
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController*)nextResponder;
        }
    }
    return nil;
}

- (float)getCollectViewHeight {
    int row = ceil([_selectedPhotos count] /3.f); //向上取整
    row <= @(0)?1:row;
    return row * (_itemWH + 80 + _margin);
}

-(NSMutableArray *)selectedNames {
    if (nil == _selectedNames) {
        _selectedNames = [NSMutableArray new];
    }
    return _selectedNames;
}

-(NSMutableArray *)selectedPhotos {
    if (nil == _selectedPhotos) {
        _selectedPhotos = [NSMutableArray new];
    }
    return _selectedPhotos;
}


@end
