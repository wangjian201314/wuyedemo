//
//  JXOrderEditCell.h
//  JXWWNOP
//
//  Created by hqf on 2017/6/30.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSInteger,JXOrderEditCellType) {
    JXOrderEditCellText = 0,
    JXOrderEditCellLongText,
    JXOrderEditCellSingle,
    JXOrderEditCellDate,
    JXOrderEditCellMutiple,
    JXOrderEditCellScan,
    JXOrderEditCellImage,
    JXOrderEditCellSwitch,
    JXOrderEditCellButton,
    JXOrderEditCellLabel,
    JXOrderEditCellJumpFiber,
    JXOrderEditCellbtn,
    JXOrderEditCellselectbtn,
    JXOrderEditCellSignature,
    JXOrderEditCellTextfiled,
    JXOrderEditCellPaybtn,
//    JXOrderEditCell
};
@class JXOrderEditCell;

@protocol JXOrderEditCellDelegate <NSObject>

- (void)didSelectedOrderEditCell:(JXOrderEditCell *)orderEditCell;

- (void)didEditedCell:(JXOrderEditCell *)orderEditCell text:(NSString *)string;

//editType:0新增，1删除
- (void)didEditedCellImage:(JXOrderEditCell *)orderEditCell editType:(NSInteger)editType;

- (void)didChangeSwitch:(JXOrderEditCell *)orderEditCell isSwitchOn:(BOOL) isSwitchOn;

- (void)didAddJumpFiber;
- (void)didDeleteJumpFiber:(NSMutableArray *)models;
- (void)saveJumpFiberInfo:(NSMutableArray *)jumpFiberInfo;

- (void)addFirstJumpFiberInfo;

@end

@interface JXOrderEditCell : UITableViewCell
@property (nonatomic) JXOrderEditCellType cellType;

@property (nonatomic, strong)UIColor *mainColor;

@property (nonatomic, copy)NSString *showColumn;//readonly
@property (nonatomic, copy)NSString *column;
@property (nonatomic, copy)NSString *value;
@property (nonatomic, copy)NSString *placeholder;
@property (nonatomic, strong)UIImage *showimg;

@property (nonatomic, strong)NSMutableArray *selectedPhotos;
@property (nonatomic, strong)NSMutableArray *selectedNames;
@property (nonatomic, strong) UIButton *button3;
@property (nonatomic, assign)NSInteger maxImageCount;//最多图片
@property (nonatomic)BOOL unClick;
@property (nonatomic)BOOL isSiglejumper;//单纤或者双纤
@property (nonatomic)BOOL isDemolition;//是否拆除工单
@property (nonatomic, copy)NSString *Currentlat;
@property (nonatomic, copy)NSString *Currentlng;

@property (nonatomic ,strong) NSMutableDictionary  *allDataDic;
@property (nonatomic ,strong) NSDictionary  *backdict;
@property (nonatomic ,strong) NSString  *telephone;//

@property (nonatomic)CGFloat height;
@property (nonatomic)BOOL necessary;


//JXOrderEditCellLongText
@property (nonatomic, copy)NSString *defaultValue;

//JXOrderEditCellSingle
@property (nonatomic, strong)NSArray *items;

//JXOrderEditCellselectbtn
@property (nonatomic, strong)NSArray *array;
@property (nonatomic,strong) UIButton *selectedBtn;

/** 特殊处理 ================================*/
@property (nonatomic)BOOL changeNeighbor;
@property (nonatomic)BOOL changegroup;
@property (nonatomic)BOOL changeselfgroup;
@property (nonatomic)NSInteger  ceng;
@property (nonatomic)BOOL adding;
@property (nonatomic ,copy)NSString *changeselfgroupwith;


@property (nonatomic,assign)NSInteger HITVcount;//特殊，记录机顶盒数量
@property (nonatomic,strong)NSMutableArray *jumpFiberInfo;//特殊，路由信息
/** ====================================== */

// 右下角角标
@property (nonatomic,strong)UIImageView * spinnerImgView;


- (float)getCollectViewHeight;

@property (nonatomic, assign)id<JXOrderEditCellDelegate>delegate;
- (instancetype)initWithType:(JXOrderEditCellType)cellType delegate:(id)delegate;
- (void)setSwitchOn:(NSString *)isSwithcOn;
- (void)setbuttonImage:(NSString *)imageName;

@end
