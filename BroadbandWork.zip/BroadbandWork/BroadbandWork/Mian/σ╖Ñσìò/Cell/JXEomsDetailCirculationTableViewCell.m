//
//  JXOrderDetailCirculationTableViewCell.m
//  JXWWNOP
//
//  Created by hqf on 2017/6/27.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//

#import "JXEomsDetailCirculationTableViewCell.h"
#define isnull(key,dict) dict[key] == nil || [dict[key] isKindOfClass:[NSNull class]] ? @"" : dict[key]

@interface JXEomsDetailCirculationTableViewCell()

@property (weak, nonatomic) IBOutlet UIView *lastLineView;

@property (weak, nonatomic) IBOutlet UILabel *personLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;



@end
@implementation JXEomsDetailCirculationTableViewCell


- (void)refreshUI:(NSDictionary *)dataDic isLast:(BOOL)isLast isDrawLine:(BOOL)isDrawLine{
    NSString *titleStr = dataDic[@"OPERATETYPE"];//[NSString stringWithFormat:@"%@", isnull(@"OPERATETYPE", dataDic)];
    NSString *personStr = [NSString stringWithFormat:@"操作人:%@-%@", isnull(@"OPERATEUSERID", dataDic),isnull(@"OPERATEDEPTID", dataDic)];
    NSString *timeStr = [NSString stringWithFormat:@"操作时间:%@", isnull(@"OPERATETIME", dataDic)];
    NSString *activeTemplateStr = [NSString stringWithFormat:@"%@", isnull(@"ACTIVETASKNAME", dataDic)];
    
    activeTemplateStr = [self convertSection:activeTemplateStr];
    titleStr=[self converttitleStr:titleStr];
    self.lastLineView.hidden = isLast;
    _titleNameLabel.text = titleStr;
    self.personLabel.text = personStr;
    self.timeLabel.text = timeStr;
   _activeTemplateLabel.text = activeTemplateStr;
    isDrawLine=YES;
    //画虚线
    if (isDrawLine) {
        CAShapeLayer *shapeLayer = [CAShapeLayer layer];
        [shapeLayer setBounds:self.bounds];
        [shapeLayer setPosition:self.center];
        [shapeLayer setFillColor:[[UIColor clearColor] CGColor]];
        // 设置虚线颜色blackColor
        [shapeLayer setStrokeColor:[[UIColor blackColor] CGColor]];
        [shapeLayer setStrokeColor:[[UIColor colorWithRed:223/255.0 green:223/255.0 blue:223/255.0 alpha:1.0f] CGColor]];
        // 3.0f设置虚线的宽度
        [shapeLayer setLineWidth:1.0f];
        [shapeLayer setLineJoin:kCALineJoinRound];
        // 3=线的宽度 1=每条线的间距
        [shapeLayer setLineDashPattern:
         [NSArray arrayWithObjects:[NSNumber numberWithInt:3],[NSNumber numberWithInt:1],nil]];
        // Setup the path
        CGMutablePathRef path = CGPathCreateMutable(); // 0,10代表初始坐标的x，y
        // 320,10代表初始坐标的x，y
        CGPathMoveToPoint(path, NULL, -10, 1);
        CGPathAddLineToPoint(path, NULL, [UIScreen mainScreen].bounds.size.width,1);
        
        [shapeLayer setPath:path];
        CGPathRelease(path);
        [self.contentView.layer addSublayer:shapeLayer];
    }
    
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self.contentView setNeedsLayout];
    [self.contentView layoutIfNeeded];
   
    //self.personLabel.preferredMaxLayoutWidth = kScreenWidth - 70;
  //  self.timeLabel.preferredMaxLayoutWidth = kScreenWidth - 70;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self) {
    }
    
    return self;
}

- (NSString *)converttitleStr :(NSString *)operateTypeStr {
    
  
        
    if([_orderType isEqualToString:@"投诉工单"]){
        
        if ([operateTypeStr isEqualToString:@"1"]) {
            
            return [NSString stringWithFormat:@"【%@】",@"移交T2处理"];
        }
        else if ([operateTypeStr isEqualToString:@"46"]) {
            return [NSString stringWithFormat:@"【%@】",@"处理完成"];
        }
        else if ([operateTypeStr isEqualToString:@"54"]) {
            return [NSString stringWithFormat:@"【%@】",@"质检不合格"];
        }
        else if ([operateTypeStr isEqualToString:@"17"]) {
            return [NSString stringWithFormat:@"【%@】",@"退回"];
        }
        
    }
    else if([_orderType isEqualToString:@"故障工单"]){
        
        if ([operateTypeStr isEqualToString:@"1"]) {
            
            return [NSString stringWithFormat:@"【%@】",@"移交T2处理"];
        }
        else if ([operateTypeStr isEqualToString:@"2"]) {
            return [NSString stringWithFormat:@"【%@】",@"移交T3处理"];
        }
        else if ([operateTypeStr isEqualToString:@"19"]) {
            return [NSString stringWithFormat:@"【%@】",@"启动紧急故障"];
        }
        else if ([operateTypeStr isEqualToString:@"43"]) {
            return [NSString stringWithFormat:@"【%@】",@"质检"];
        }
        else if ([operateTypeStr isEqualToString:@"432"]) {
            return [NSString stringWithFormat:@"【%@】",@"质检不通过/驳回"];
        }
        else if ([operateTypeStr isEqualToString:@"431"]) {
            return [NSString stringWithFormat:@"【%@】",@"质检通过"];
        }
        
    }
        
    if ([operateTypeStr isEqualToString:@"0"]) {
        return  [NSString stringWithFormat:@"【%@】",@"提交申请"];
    }
    else if ([operateTypeStr isEqualToString:@"22"]) {
        return [NSString stringWithFormat:@"【%@】",@"保存草稿"];
    }
    else if ([operateTypeStr isEqualToString:@"3"]) {
        return [NSString stringWithFormat:@"【%@】",@"草稿派发"];
    }
    else if ([operateTypeStr isEqualToString:@"6"]) {
        return [NSString stringWithFormat:@"【%@】",@"处理回复通过"];
    }
    else if ([operateTypeStr isEqualToString:@"7"]) {
        return [NSString stringWithFormat:@"【%@】",@"处理回复不通过"];
    }
    else if ([operateTypeStr isEqualToString:@"4"]) {
        return [NSString stringWithFormat:@"【%@】",@"驳回"];
    }
    else if ([operateTypeStr isEqualToString:@"53"]) {
        return [NSString stringWithFormat:@"【%@】",@"重新派发"];
    }
    else if ([operateTypeStr isEqualToString:@"8"]) {
        return [NSString stringWithFormat:@"【%@】",@"移交"];
    }
    else if ([operateTypeStr isEqualToString:@"55"]) {
        return [NSString stringWithFormat:@"【%@】",@"会审回复"];
    }
    else if ([operateTypeStr isEqualToString:@"88"]) {
        return [NSString stringWithFormat:@"【%@】",@"转审"];
    }
    else if ([operateTypeStr isEqualToString:@"30"]) {
        return [NSString stringWithFormat:@"【%@】",@"会审"];
    }
    else if ([operateTypeStr isEqualToString:@"-13"]) {
        return [NSString stringWithFormat:@"【%@】",@"强制归档"];
    }
    else if ([operateTypeStr isEqualToString:@"-14"]) {
        return [NSString stringWithFormat:@"【%@】",@"强制作废"];
    }
    else if ([operateTypeStr isEqualToString:@"-12"]) {
        return [NSString stringWithFormat:@"【%@】",@"作废"];
    }
    else if ([operateTypeStr isEqualToString:@"-10"]) {
        return [NSString stringWithFormat:@"【%@】",@"抄送"];
    }
    else if ([operateTypeStr isEqualToString:@"-15"]) {
        return [NSString stringWithFormat:@"【%@】",@"抄送确认"];
    }
    else if ([operateTypeStr isEqualToString:@"9"]) {
        return [NSString stringWithFormat:@"【%@】",@"阶段回复"];
    }
    else if ([operateTypeStr isEqualToString:@"-11"]) {
        return [NSString stringWithFormat:@"【%@】",@"阶段通知"];
    }
    else if ([operateTypeStr isEqualToString:@"10"]) {
        return [NSString stringWithFormat:@"【%@】",@"分派"];
    }
    else if ([operateTypeStr isEqualToString:@"11"]) {
        return [NSString stringWithFormat:@"【%@】",@"分派回复"];
    }
    else if ([operateTypeStr isEqualToString:@"61"]) {
        return [NSString stringWithFormat:@"【%@】",@"确认受理"];
    }
    else if ([operateTypeStr isEqualToString:@"5"]) {
        return [NSString stringWithFormat:@"【%@】",@"申请延期"];
    }
    else if ([operateTypeStr isEqualToString:@"66"]) {
        return [NSString stringWithFormat:@"【%@】",@"延期审批通过"];
    }
    else if ([operateTypeStr isEqualToString:@"56"]) {
        return [NSString stringWithFormat:@"【%@】",@"质检合格"];
    }
    else if ([operateTypeStr isEqualToString:@"64"]) {
        return [NSString stringWithFormat:@"【%@】",@"延期审批不合格"];
    }
    else if ([operateTypeStr isEqualToString:@"205"]) {
        return [NSString stringWithFormat:@"【%@】",@"回复"];
    }
    else if ([operateTypeStr isEqualToString:@"206"]) {
        return [NSString stringWithFormat:@"【%@】",@"回复送审"];
    }
    else if ([operateTypeStr isEqualToString:@"201"]) {
        return [NSString stringWithFormat:@"【%@】",@"派发审批通过"];
    }
    else if ([operateTypeStr isEqualToString:@"202"]) {
        return [NSString stringWithFormat:@"【%@】",@"派发审批不通过"];
    }
    else if ([operateTypeStr isEqualToString:@"208"]) {
        return [NSString stringWithFormat:@"【%@】",@"完成审批通过"];
    }
    else if ([operateTypeStr isEqualToString:@"209"]) {
        return [NSString stringWithFormat:@"【%@】",@"完成审批不通过"];
    }
    else if ([operateTypeStr isEqualToString:@"199"]) {
        return [NSString stringWithFormat:@"【%@】",@"提交审核"];
    }
    else if ([operateTypeStr isEqualToString:@"211"]) {
        return [NSString stringWithFormat:@"【%@】",@"回复通过"];
    }
    
    return @"";
        
    
}

- (NSString *)convertSection :(NSString *)typeStr {
    if ([typeStr isEqualToString:@""]) {
        return @"新增工单";
    } else if ([typeStr isEqualToString:@"cc"]) {
        return @"抄送";
    }  else if ([typeStr isEqualToString:@"reply"]) {
        return @"阶段回复";
    } else if ([typeStr isEqualToString:@"advice"]) {
        return @"阶段通知";
    }
    if([_orderType isEqualToString:@"投诉工单"]){
        
        if ([typeStr isEqualToString:@"DeferExamineHumTask"]) {
            return @"延期审批";
        }else if ([typeStr isEqualToString:@"DraftHumTask"]) {
            return @"草稿";
        }else if ([typeStr isEqualToString:@"ByRejectHumTask"]) {
            return @"驳回";
        }else if ([typeStr isEqualToString:@"FirstExcuteHumTask"]) {
            return @"一级处理";
        }else if ([typeStr isEqualToString:@"SecondExcuteHumTask"]) {
            return @"二级处理";
        }else if ([typeStr isEqualToString:@"CheckingHumTask"]) {
            return @"质检";
        }else if ([typeStr isEqualToString:@"HoldHumTask"]) {
            return @"归档";
        }
        
    }
    if([_orderType isEqualToString:@"故障工单"]){
        
         if ([typeStr isEqualToString:@"DraftHumTask"]) {
            return @"草稿";
        }else if ([typeStr isEqualToString:@"BackHumTask"]) {
            return @"驳回";
        }else if ([typeStr isEqualToString:@"FirstExcuteHumTask"]) {
            return @"T1处理";
        }else if ([typeStr isEqualToString:@"SecondExcuteHumTask"]) {
            return @"T2处理";
        }else if ([typeStr isEqualToString:@"ThirdExcuteHumTask"]) {
            return @"T3处理";
        }else if ([typeStr isEqualToString:@"ExamineHumTask"]) {
            return @"延期审批";
        }else if ([typeStr isEqualToString:@"HoldHumTask"]) {
            return @"待归档";
        }else if ([typeStr isEqualToString:@"CheckHumTask"]) {
            return @"质检";
        }
        
    }
    return @"";
    
}



- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}

@end
