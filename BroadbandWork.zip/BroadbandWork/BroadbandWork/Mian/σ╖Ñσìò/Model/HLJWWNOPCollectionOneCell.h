//
//  HLJWWNOPCollectionOneCell.h
//  HLJWWNOP
//
//  Created by 陈灿锋 on 17/5/3.
//  Copyright © 2017年 Mastercom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HLJWWNOPCollectionOneCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UIButton *deleteBtn;
@property (weak, nonatomic) IBOutlet UILabel *flagL;
@property (weak, nonatomic) IBOutlet UILabel *titleL;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *flagWidth;

@property (nonatomic, assign) NSInteger row;

- (UIView *)snapshotView;

//+ (instancetype)initCellWithCollectionView:(UICollectionView *)collectionView forIndexPath:(NSIndexPath *)indexPath;

@end
