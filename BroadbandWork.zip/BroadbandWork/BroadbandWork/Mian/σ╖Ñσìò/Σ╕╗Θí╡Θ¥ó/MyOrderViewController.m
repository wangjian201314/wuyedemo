//
//  JXMyOrderViewController.m
//  JXWWNOP
//
//  Created by hqf on 2017/6/20.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//
#import "HBTitleView.h"
#import "MyOrderViewController.h"
#import "JXEOMSCell.h"
#import "MTEditPopView.h"
#import "JXEOMSDetailViewController.h"
#define isnull(key,dict) dict[key] == nil || [dict[key] isKindOfClass:[NSNull class]] ? @"" : dict[key]

@interface MyOrderViewController ()<MTEditPopViewDelegate>{
    
}

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomViewHeight;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *scrollContentViewConstraints;

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UILabel *willDoOrderLabel;
@property (weak, nonatomic) IBOutlet UILabel *haveDoOrderLabel;
@property (weak, nonatomic) IBOutlet UILabel *bottomLabel;

@property (weak, nonatomic) IBOutlet UITableView *leftOrderTableView;
@property (weak, nonatomic) IBOutlet UITableView *rightTableView;

@property (weak, nonatomic) IBOutlet UITableView *ThirdTableview;
@property (weak, nonatomic) IBOutlet UITableView *FourthTableview;


@property (weak, nonatomic) IBOutlet UIView *topView;  //顶部标题视图
@property (weak, nonatomic) IBOutlet UIView *topViewLine; //顶部视图的下划线
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topViewLineWidthConstraints;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *scollerViewTopH; //scrollerView的Y高度

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *TopHieght;

@property (strong, nonatomic) HBTitleView *hbTitleView;//top

@end

@implementation MyOrderViewController {
    NSMutableArray *_leftDataSource;
    NSMutableArray *_rightDataSource;
    NSMutableArray *_thirdDataSource;
    NSMutableArray *_FourDataSource;
    NSMutableArray *_tempDataSource;
    
    NSString *_operaType;  //操作类型  showListsendundo：待办，showHoldedList：B角待办,
    int curentPage;
    NSString *opType;
    
    
    NSNumber *_leftTotal;
    NSNumber *_rightTotal;
    NSNumber *_thirdTotal;
    NSNumber *_fourTotal;
    
    int leftPageIndex;
    int rightPageIndex;
    int thirdPageIndex;
    int fourPageIndex;
    
    NSString *bottomLabelTextL;
    NSString *bottomLabelTextR;
    NSString *bottomLableTextthird;
    NSString *bottomLableTextFourth;
    
     UIButton *_leftbtn;
    UILabel *_Toplb;
    NSString *_SortType;
}

- (instancetype) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        _leftDataSource = [[NSMutableArray alloc] init];
        _rightDataSource = [[NSMutableArray alloc] init];
        _thirdDataSource=[NSMutableArray array];
        _FourDataSource=[NSMutableArray array];
        _tempDataSource=[NSMutableArray array];
        curentPage = 0;
        _leftTotal = @0;
        _rightTotal = @0;
        leftPageIndex = 0;
        rightPageIndex = 0;
        thirdPageIndex=0;
        fourPageIndex=0;
    }
    return self;
}

#pragma mark--增加的代码
- (void)viewWillLayoutSubviews{
    
    self.willDoOrderLabel.hidden=YES;
    self.haveDoOrderLabel.hidden=YES;
    self.topViewLine.hidden=YES;
    self.bottomViewHeight.constant=30+(MTIPhoneX?20:0);
}




- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
    if([key isEqualToString:@"id"]){
        
        
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
   
    [self setNaviTitle:@"我的工单" leftButtonShow:NO rightButtom:nil];
    [self createUI];
    [SVProgressHUD showWithStatus:@"正在加载..."];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
        if([namestr isEqualToString:@"15976070261"]){
            [self setData];
        }else{
            [SVProgressHUD showErrorWithStatus:@"暂无工单数据!"];
        }
    });
    
}
- (void)setData{
    
    
    
    if([_orderType isEqualToString:@"装机工单"]){
    [_leftDataSource addObjectsFromArray:@[@{@"id":@"JX-060-060-180410-1223956494",
                                             @"ordertype":@"装机工单",
                                             @"title":@"花园小区一栋101安装宽带",
                                             @"date1":@"2019-05-10 09:06:30",
                                             @"date2":@"2019-05-10 09:06:30",
                                             @"date3":@"2019-05-13 09:06:30",
                                             @"stauts":@"已接单",
                                             @"step":@"上门安装",
                                             @"data":@[@"花园小区一栋101安装宽带",@"JX-060-060-180410-1223956494",
                                                       @"已接单",
                                                       @"张师傅",
                                                       @"2019-05-10 09:06:30",
                                                       @"施工部",
                                                       @"省公司",
                                                       @"15526738485",
                                                       @"李工",
                                                       @"186526374856",
                                                       @"上门安装宽带服务",
                                                       @"上门安装",
                                                       @"2019-05-13 09:06:30",
                                                       @"2019-05-10 09:06:30",
                                                       @"2019-05-10 09:06:30",
                                                       @"2019-05-10 09:06:30",],
                                             },
                                           @{@"id":@"JX-060-060-180410-1223956494",
                                             @"ordertype":@"装机工单",
                                             @"title":@"龙城小区一栋201安装宽带",
                                             @"date1":@"2019-05-10 09:06:30",
                                             @"date2":@"2019-05-10 09:06:30",
                                             @"date3":@"2019-05-10 09:06:30",
                                             @"stauts":@"已接单",
                                             @"step":@"上门安装",
                                             @"data":@[@"龙城小区一栋201安装宽带",@"JX-060-060-180410-1223956494",
                                                       @"已接单",
                                                       @"张师傅",
                                                       @"2019-05-10 09:06:30",
                                                       @"施工部",
                                                       @"省公司",
                                                       @"15526738485",
                                                       @"李工",
                                                       @"186526374856",
                                                       @"上门安装宽带服务",
                                                       @"上门安装",
                                                       @"2019-05-13 09:06:30",
                                                       @"2019-05-10 09:06:30",
                                                       @"2019-05-10 09:06:30",
                                                       @"2019-05-10 09:06:30",],
                                             },
                                           @{@"id":@"JX-060-060-180410-1223956494",
                                             @"ordertype":@"装机工单",
                                             @"title":@"雨花小区一栋601安装宽带",
                                             @"date1":@"2019-05-10 09:06:30",
                                             @"date2":@"2019-05-10 09:06:30",
                                             @"date3":@"2019-05-10 09:06:30",
                                             @"stauts":@"已接单",
                                             @"step":@"上门安装",
                                             @"data":@[@"雨花小区一栋601安装宽带",@"JX-060-060-180410-1223956494",
                                                       @"已接单",
                                                       @"张师傅",
                                                       @"2019-05-10 09:06:30",
                                                       @"施工部",
                                                       @"省公司",
                                                       @"15526738485",
                                                       @"李工",
                                                       @"186526374856",
                                                       @"上门安装宽带服务",
                                                       @"上门安装",
                                                       @"2019-05-13 09:06:30",
                                                       @"2019-05-10 09:06:30",
                                                       @"2019-05-10 09:06:30",
                                                       @"2019-05-10 09:06:30",],
                                             }]];
    [_leftOrderTableView reloadData];
    }else if([_orderType isEqualToString:@"拆机工单"]){
        [_leftDataSource addObjectsFromArray:@[@{@"id":@"JX-060-060-180410-1223956494",
                                                 @"title":@"外出线上施工",
                                                 @"ordertype":@"拆机工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-10 09:06:30",
                                                 @"stauts":@"未接单",
                                                 @"step":@"上门安装",
                                                 @"data":@[@"外出线上施工",@"JX-060-060-180410-1223956494",
                                                           @"已接单",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"外线施工方案",
                                                           @"外线施工",
                                                           @"2019-05-13 09:06:30",
                                                           @"2019-05-10 09:06:30",
                                                           @"2019-05-10 09:06:30",
                                                           @"2019-05-10 09:06:30",],
                                                 },
                                               @{@"id":@"JX-060-060-180410-1223956494",
                                                 @"title":@"光猫盒子问题",
                                                 @"ordertype":@"拆机工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-10 09:06:30",
                                                 @"stauts":@"已接单",
                                                 @"step":@"外线施工",
                                                 @"data":@[@"光猫盒子问题",@"JX-060-060-180410-1223956494",
                                                           @"已接单",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"外线施工方案",
                                                           @"外线施工",
                                                           @"2019-05-13 09:06:30",
                                                           @"2019-05-10 09:06:30",
                                                           @"2019-05-10 09:06:30",
                                                           @"2019-05-10 09:06:30",],
                                                 
                                                 },
                                               ]];
        [_leftOrderTableView reloadData];
    }else if([_orderType isEqualToString:@"预约工单"]){
        [_leftDataSource addObjectsFromArray:@[@{@"id":@"JX-060-060-180410-1223956494",
                                                 @"title":@"接入光猫号",
                                                 @"ordertype":@"预约工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-13 09:06:30",
                                                 @"stauts":@"已接单",
                                                 @"step":@"上门安装",
                                                 @"data":@[@"接入光猫号",@"JX-060-060-180410-1223956494",
                                                           @"已接单",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"@接入光猫号",
                                                           @"工单转派",
                                                           @"2019-05-13 09:06:30",
                                                           @"2019-05-10 09:06:30",
                                                           @"2019-05-10 09:06:30",
                                                           @"2019-05-10 09:06:30",],
                                                 },
                                               @{@"id":@"JX-060-060-180410-1223956494",
                                                 @"title":@"k光缆线路重装",
                                                 @"ordertype":@"预约工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-10 09:06:30",
                                                 @"stauts":@"已接单未处理",
                                                 @"step":@"预约接单",
                                                 @"data":@[@"k光缆线路重装",@"JX-060-060-180410-1223956494",
                                                           @"已接单",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"k光缆线路重装",
                                                           @"预约接单",
                                                           @"2019-05-13 09:06:30",
                                                           @"2019-05-10 09:06:30",
                                                           @"2019-05-10 09:06:30",
                                                           @"2019-05-10 09:06:30",],
                                                 },
                                               @{@"id":@"JX-060-060-180410-1223956494",
                                                 @"title":@"宽带线路问题",
                                                 @"ordertype":@"预约工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-10 09:06:30",
                                                 @"stauts":@"已接单未处理",
                                                 @"step":@"外线排查",
                                                 @"data":@[@"宽带线路问题",@"JX-060-060-180410-1223956494",
                                                           @"已接单未处理",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"外线排查",
                                                           @"外线排查",
                                                           @"2019-05-13 09:06:30",
                                                           @"2019-05-10 09:06:30",
                                                           @"2019-05-10 09:06:30",
                                                           @"2019-05-10 09:06:30",],
                                                 }]];
        [_leftOrderTableView reloadData];
    }else if([_orderType isEqualToString:@"投诉工单"]){
        [_leftDataSource addObjectsFromArray:@[@{@"id":@"JX-060-060-180410-1223956494",
                                                 @"title":@"带宽不稳定",
                                                 @"ordertype":@"投诉工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-13 09:06:30",
                                                 @"stauts":@"已接单",
                                                 @"step":@"转派",
                                                 @"data":@[@"带宽不稳定",@"JX-060-060-180410-1223956494",
                                                           @"已接单",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"带宽不稳定",
                                                           @"工单转派",
                                                           @"2019-05-23 09:06:30",
                                                           @"2019-05-11 09:06:30",
                                                           @"2019-05-18 09:06:30",
                                                           @"2019-05-10 09:06:30",],
                                                 },
                                               @{@"id":@"JX-060-060-180410-1223956494",
                                                 @"title":@"FTTH系统问题",
                                                 @"ordertype":@"投诉工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-10 09:06:30",
                                                 @"stauts":@"已接单未处理",
                                                 @"step":@"预约接单",
                                                 @"data":@[@"FTTH系统问题",@"JX-060-060-180410-1223956494",
                                                           @"已接单未处理",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"FTTH系统问题",
                                                           @"预约接单",
                                                           @"2019-05-13 09:06:30",
                                                           @"2019-05-10 09:07:30",
                                                           @"2019-05-11 09:06:30",
                                                           @"2019-05-12 12:06:30",],
                                                 },
                                               @{@"id":@"JX-060-060-180410-1223956494",
                                                 @"title":@"宽带网络不稳定",
                                                 @"ordertype":@"投诉工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-10 09:06:30",
                                                 @"stauts":@"已接单未处理",
                                                 @"step":@"外线排查",
                                                 @"data":@[@"宽带网络不稳定",@"JX-060-060-180410-1223956494",
                                                           @"已接单未处理",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"安装激活",
                                                           @"安装激活",
                                                           @"2019-05-13 09:06:30",
                                                           @"2019-05-12 09:06:30",
                                                           @"2019-05-12 09:06:30",
                                                           @"2019-05-12 12:06:30",],
                                                 }]];
        [_leftOrderTableView reloadData];
    }else if([_orderType isEqualToString:@"跳纤工单"]){
        [_leftDataSource addObjectsFromArray:@[@{@"id":@"JX-060-060-180410-1223956494",
                                                 @"title":@"带宽不稳定",
                                                 @"ordertype":@"跳纤工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-13 09:06:30",
                                                 @"stauts":@"已接单",
                                                 @"step":@"转派",
                                                 @"data":@[@"带宽不稳定",@"JX-060-060-180410-1223956494",
                                                           @"已接单",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"带宽不稳定",
                                                           @"工单转派",
                                                           @"2019-05-23 09:06:30",
                                                           @"2019-05-11 09:06:30",
                                                           @"2019-05-18 09:06:30",
                                                           @"2019-05-10 09:06:30",],
                                                 },
                                               @{@"id":@"JX-060-060-180410-1223956494",
                                                 @"title":@"k光缆线路重装",
                                                 @"ordertype":@"跳纤工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-10 09:06:30",
                                                 @"stauts":@"已接单未处理",
                                                 @"step":@"预约接单",
                                                 @"data":@[@"k光缆线路重装",@"JX-060-060-180410-1223956494",
                                                           @"已接单未处理",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"k光缆线路重装",
                                                           @"预约接单",
                                                           @"2019-05-13 09:06:30",
                                                           @"2019-05-10 09:07:30",
                                                           @"2019-05-11 09:06:30",
                                                           @"2019-05-12 12:06:30",],
                                                 },
                                               @{@"id":@"JX-060-060-180410-1223956494",
                                                 @"title":@"宽带网络不稳定",
                                                 @"ordertype":@"跳纤工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-10 09:06:30",
                                                 @"stauts":@"已接单未处理",
                                                 @"step":@"外线排查",
                                                 @"data":@[@"宽带网络不稳定",@"JX-060-060-180410-1223956494",
                                                           @"已接单未处理",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"安装激活",
                                                           @"安装激活",
                                                           @"2019-05-13 09:06:30",
                                                           @"2019-05-12 09:06:30",
                                                           @"2019-05-12 09:06:30",
                                                           @"2019-05-12 12:06:30",],
                                                 }]];
        [_leftOrderTableView reloadData];
    }else if([_orderType isEqualToString:@"勘察工单"]){
        [_leftDataSource addObjectsFromArray:@[@{@"id":@"JX-060-060-180410-1223956494",
                                                 @"title":@"带宽不稳定",
                                                 @"ordertype":@"勘察工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-13 09:06:30",
                                                 @"stauts":@"已接单",
                                                 @"step":@"转派",
                                                 @"data":@[@"带宽不稳定",@"JX-060-060-180410-1223956494",
                                                           @"已接单",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"带宽不稳定",
                                                           @"工单转派",
                                                           @"2019-05-21 10:06:30",
                                                           @"2019-05-11 12:06:30",
                                                           @"2019-05-13 09:06:30",
                                                           @"苏杭东排查宽带问题",
                                                           @"江苏省",
                                                           @"苏州市"],
                                                 },
                                               @{@"id":@"JX-060-060-180410-1223956494",
                                                 @"title":@"k光缆线路重装",
                                                 @"ordertype":@"勘察工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-10 09:06:30",
                                                 @"stauts":@"已接单未处理",
                                                 @"step":@"预约接单",
                                                 @"data":@[@"k光缆线路重装",@"JX-060-060-180410-1223956494",
                                                           @"已接单未处理",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"k光缆线路重装",
                                                          
                                                           @"2019-05-13 09:06:30",
                                                           @"2019-05-10 09:07:30",
                                                           @"2019-05-11 09:06:30",
                                                          
                                                           @"简单简单就xndnvndk",
                                                           @"湖南省",
                                                           @"长沙市"],
                                                 },
                                               @{@"id":@"JX-060-060-180410-1223956494",
                                                 @"title":@"宽带网络不稳定",
                                                 @"ordertype":@"勘察工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-10 09:06:30",
                                                 @"stauts":@"已接单未处理",
                                                 @"step":@"外线排查",
                                                 @"data":@[@"宽带网络不稳定",@"JX-060-060-180410-1223956494",
                                                           @"已接单未处理",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"安装激活",
                                                           
                                                           @"2019-05-13 09:06:30",
                                                           @"2019-05-12 09:06:30",
                                                           @"2019-05-12 09:06:30",
                                                          
                                                           @"rjgdkg光猫问题",
                                                           @"寒冬省",
                                                           @"周元市"],
                                                 }]];
        [_leftOrderTableView reloadData];
    }else if([_orderType isEqualToString:@"宽带配置工单"]){
        [_leftDataSource addObjectsFromArray:@[@{@"id":@"JX-060-0440-180410-1hdddkk",
                                                 @"title":@"带宽不稳定",
                                                 @"ordertype":@"宽带配置工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-13 09:06:30",
                                                 @"stauts":@"已接单",
                                                 @"step":@"转派",
                                                 @"data":@[@"带宽不稳定",@"JX-060-060-180410-1223956494",
                                                           @"已接单",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"带宽不稳定", @"工单转派",
                                                           @"2019-05-23 09:06:30",
                                                           @"2019-05-11 09:06:30",
                                                           @"2019-05-18 09:06:30",
                                                           
                                                           @"外线排查宽带问题",
                                                           @"江西省",
                                                           @"赣州市"],
                                                 },
                                               @{@"id":@"JX-060-060-180410-fff956494",
                                                 @"title":@"k光缆线路重装",
                                                 @"ordertype":@"宽带配置工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-10 09:06:30",
                                                 @"stauts":@"已接单未处理",
                                                 @"step":@"预约接单",
                                                 @"data":@[@"k光缆线路重装",@"JX-060-060-180410-1223956494",
                                                           @"已接单未处理",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"k光缆线路重装",
                                                          
                                                           @"2019-05-13 09:06:30",
                                                           @"2019-05-10 09:07:30",
                                                        
                                                           @"2019-05-12 12:06:30",
                                                           @"苏杭东排查宽带问题",
                                                           @"江苏省",
                                                           @"苏州市"],
                                                 },
                                               @{@"id":@"JX-060-060-180410-1223956494",
                                                 @"title":@"宽带网络不稳定",
                                                 @"ordertype":@"宽带配置工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-10 09:06:30",
                                                 @"stauts":@"已接单未处理",
                                                 @"step":@"外线排查",
                                                 @"data":@[@"宽带网络不稳定",@"JX-060-060-180410-1223956494",
                                                           @"已接单未处理",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"安装激活",
                                                           
                                                           @"2019-05-13 09:06:30",
                                                           @"2019-05-12 09:06:30",
                                                          
                                                           @"2019-05-12 12:06:30",
                                                           @"新增宽带问题",
                                                           @"广东省",
                                                           @"广州市"],
                                                 }]];
        [_leftOrderTableView reloadData];
    }else{
        
        [_leftDataSource addObjectsFromArray:@[@{@"id":@"JX-060-0440-180410-1hdddkk",
                                                 @"title":@"带宽不稳定",
                                                 @"ordertype":@"宽带配置工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-13 09:06:30",
                                                 @"stauts":@"已接单",
                                                 @"step":@"转派",
                                                 @"data":@[@"带宽不稳定",@"JX-060-060-180410-1223956494",
                                                           @"已接单",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"带宽不稳定", @"工单转派",
                                                           @"2019-05-23 09:06:30",
                                                           @"2019-05-11 09:06:30",
                                                           @"2019-05-18 09:06:30",
                                                           
                                                           @"外线排查宽带问题",
                                                           @"江西省",
                                                           @"赣州市"],
                                                 },
                                               @{@"id":@"JX-060-060-180410-fff956494",
                                                 @"title":@"k光缆线路重装",
                                                 @"ordertype":@"宽带配置工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-10 09:06:30",
                                                 @"stauts":@"已接单未处理",
                                                 @"step":@"预约接单",
                                                 @"data":@[@"k光缆线路重装",@"JX-060-060-180410-1223956494",
                                                           @"已接单未处理",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"k光缆线路重装",
                                                           
                                                           @"2019-05-13 09:06:30",
                                                           @"2019-05-10 09:07:30",
                                                           
                                                           @"2019-05-12 12:06:30",
                                                           @"苏杭东排查宽带问题",
                                                           @"江苏省",
                                                           @"苏州市"],
                                                 },
                                               @{@"id":@"JX-060-060-180410-1223956494",
                                                 @"title":@"宽带网络不稳定",
                                                 @"ordertype":@"宽带配置工单",
                                                 @"date1":@"2019-05-10 09:06:30",
                                                 @"date2":@"2019-05-10 09:06:30",
                                                 @"date3":@"2019-05-10 09:06:30",
                                                 @"stauts":@"已接单未处理",
                                                 @"step":@"外线排查",
                                                 @"data":@[@"宽带网络不稳定",@"JX-060-060-180410-1223956494",
                                                           @"已接单未处理",
                                                           @"张师傅",
                                                           @"2019-05-10 09:06:30",
                                                           @"施工部",
                                                           @"省公司",
                                                           @"15526738485",
                                                           @"李工",
                                                           @"186526374856",
                                                           @"安装激活",
                                                           
                                                           @"2019-05-13 09:06:30",
                                                           @"2019-05-12 09:06:30",
                                                           
                                                           @"2019-05-12 12:06:30",
                                                           @"新增宽带问题",
                                                           @"广东省",
                                                           @"广州市"],
                                                 
                                                 },@{@"id":@"JX-060-060-180410-1223956494",
                                                       @"ordertype":@"装机工单",
                                                       @"title":@"花园小区一栋101安装宽带",
                                                       @"date1":@"2019-05-10 09:06:30",
                                                       @"date2":@"2019-05-10 09:06:30",
                                                       @"date3":@"2019-05-13 09:06:30",
                                                       @"stauts":@"已接单",
                                                       @"step":@"上门安装",
                                                       @"data":@[@"花园小区一栋101安装宽带",@"JX-060-060-180410-1223956494",
                                                                 @"已接单",
                                                                 @"张师傅",
                                                                 @"2019-05-10 09:06:30",
                                                                 @"施工部",
                                                                 @"省公司",
                                                                 @"15526738485",
                                                                 @"李工",
                                                                 @"186526374856",
                                                                 @"上门安装宽带服务",
                                                                 @"上门安装",
                                                                 @"2019-05-13 09:06:30",
                                                                 @"2019-05-10 09:06:30",
                                                                 @"2019-05-10 09:06:30",
                                                                 @"2019-05-10 09:06:30",],
                                                       },
                                                     @{@"id":@"JX-060-060-180410-1223956494",
                                                       @"ordertype":@"装机工单",
                                                       @"title":@"龙城小区一栋201安装宽带",
                                                       @"date1":@"2019-05-10 09:06:30",
                                                       @"date2":@"2019-05-10 09:06:30",
                                                       @"date3":@"2019-05-10 09:06:30",
                                                       @"stauts":@"已接单",
                                                       @"step":@"上门安装",
                                                       @"data":@[@"龙城小区一栋201安装宽带",@"JX-060-060-180410-1223956494",
                                                                 @"已接单",
                                                                 @"张师傅",
                                                                 @"2019-05-10 09:06:30",
                                                                 @"施工部",
                                                                 @"省公司",
                                                                 @"15526738485",
                                                                 @"李工",
                                                                 @"186526374856",
                                                                 @"上门安装宽带服务",
                                                                 @"上门安装",
                                                                 @"2019-05-13 09:06:30",
                                                                 @"2019-05-10 09:06:30",
                                                                 @"2019-05-10 09:06:30",
                                                                 @"2019-05-10 09:06:30",],
                                                       },
                                                     @{@"id":@"JX-060-060-180410-1223956494",
                                                       @"ordertype":@"装机工单",
                                                       @"title":@"雨花小区一栋601安装宽带",
                                                       @"date1":@"2019-05-10 09:06:30",
                                                       @"date2":@"2019-05-10 09:06:30",
                                                       @"date3":@"2019-05-10 09:06:30",
                                                       @"stauts":@"已接单",
                                                       @"step":@"上门安装",
                                                       @"data":@[@"雨花小区一栋601安装宽带",@"JX-060-060-180410-1223956494",
                                                                 @"已接单",
                                                                 @"张师傅",
                                                                 @"2019-05-10 09:06:30",
                                                                 @"施工部",
                                                                 @"省公司",
                                                                 @"15526738485",
                                                                 @"李工",
                                                                 @"186526374856",
                                                                 @"上门安装宽带服务",
                                                                 @"上门安装",
                                                                 @"2019-05-13 09:06:30",
                                                                 @"2019-05-10 09:06:30",
                                                                 @"2019-05-10 09:06:30",
                                                                 @"2019-05-10 09:06:30",],
                                                       },
                                               @{@"id":@"JX-060-060-180410-1223956494",
                                                   @"title":@"带宽不稳定",
                                                   @"ordertype":@"投诉工单",
                                                   @"date1":@"2019-05-10 09:06:30",
                                                   @"date2":@"2019-05-10 09:06:30",
                                                   @"date3":@"2019-05-13 09:06:30",
                                                   @"stauts":@"已接单",
                                                   @"step":@"转派",
                                                   @"data":@[@"带宽不稳定",@"JX-060-060-180410-1223956494",
                                                             @"已接单",
                                                             @"张师傅",
                                                             @"2019-05-10 09:06:30",
                                                             @"施工部",
                                                             @"省公司",
                                                             @"15526738485",
                                                             @"李工",
                                                             @"186526374856",
                                                             @"带宽不稳定",
                                                             @"工单转派",
                                                             @"2019-05-23 09:06:30",
                                                             @"2019-05-11 09:06:30",
                                                             @"2019-05-18 09:06:30",
                                                             @"2019-05-10 09:06:30",],
                                                   },
                                                 @{@"id":@"JX-060-060-180410-1223956494",
                                                   @"title":@"k光缆线路重装",
                                                   @"ordertype":@"投诉工单",
                                                   @"date1":@"2019-05-10 09:06:30",
                                                   @"date2":@"2019-05-10 09:06:30",
                                                   @"date3":@"2019-05-10 09:06:30",
                                                   @"stauts":@"已接单未处理",
                                                   @"step":@"预约接单",
                                                   @"data":@[@"k光缆线路重装",@"JX-060-060-180410-1223956494",
                                                             @"已接单未处理",
                                                             @"张师傅",
                                                             @"2019-05-10 09:06:30",
                                                             @"施工部",
                                                             @"省公司",
                                                             @"15526738485",
                                                             @"李工",
                                                             @"186526374856",
                                                             @"k光缆线路重装",
                                                             @"预约接单",
                                                             @"2019-05-13 09:06:30",
                                                             @"2019-05-10 09:07:30",
                                                             @"2019-05-11 09:06:30",
                                                             @"2019-05-12 12:06:30",],
                                                   },
                                                 @{@"id":@"JX-060-060-180410-1223956494",
                                                   @"title":@"宽带网络不稳定",
                                                   @"ordertype":@"投诉工单",
                                                   @"date1":@"2019-05-10 09:06:30",
                                                   @"date2":@"2019-05-10 09:06:30",
                                                   @"date3":@"2019-05-10 09:06:30",
                                                   @"stauts":@"已接单未处理",
                                                   @"step":@"外线排查",
                                                   @"data":@[@"宽带网络不稳定",@"JX-060-060-180410-1223956494",
                                                             @"已接单未处理",
                                                             @"张师傅",
                                                             @"2019-05-10 09:06:30",
                                                             @"施工部",
                                                             @"省公司",
                                                             @"15526738485",
                                                             @"李工",
                                                             @"186526374856",
                                                             @"安装激活",
                                                             @"安装激活",
                                                             @"2019-05-13 09:06:30",
                                                             @"2019-05-12 09:06:30",
                                                             @"2019-05-12 09:06:30",
                                                             @"2019-05-12 12:06:30",],
                                                   },
                                               @{@"id":@"JX-060-060-180410-1223956494",
                                                   @"title":@"带宽不稳定",
                                                   @"ordertype":@"跳纤工单",
                                                   @"date1":@"2019-05-10 09:06:30",
                                                   @"date2":@"2019-05-10 09:06:30",
                                                   @"date3":@"2019-05-13 09:06:30",
                                                   @"stauts":@"已接单",
                                                   @"step":@"转派",
                                                   @"data":@[@"带宽不稳定",@"JX-060-060-180410-1223956494",
                                                             @"已接单",
                                                             @"张师傅",
                                                             @"2019-05-10 09:06:30",
                                                             @"施工部",
                                                             @"省公司",
                                                             @"15526738485",
                                                             @"李工",
                                                             @"186526374856",
                                                             @"带宽不稳定",
                                                             @"工单转派",
                                                             @"2019-05-23 09:06:30",
                                                             @"2019-05-11 09:06:30",
                                                             @"2019-05-18 09:06:30",
                                                             @"2019-05-10 09:06:30",],
                                                   },
                                                 @{@"id":@"JX-060-060-180410-1223956494",
                                                   @"title":@"k光缆线路重装",
                                                   @"ordertype":@"跳纤工单",
                                                   @"date1":@"2019-05-10 09:06:30",
                                                   @"date2":@"2019-05-10 09:06:30",
                                                   @"date3":@"2019-05-10 09:06:30",
                                                   @"stauts":@"已接单未处理",
                                                   @"step":@"预约接单",
                                                   @"data":@[@"k光缆线路重装",@"JX-060-060-180410-1223956494",
                                                             @"已接单未处理",
                                                             @"张师傅",
                                                             @"2019-05-10 09:06:30",
                                                             @"施工部",
                                                             @"省公司",
                                                             @"15526738485",
                                                             @"李工",
                                                             @"186526374856",
                                                             @"k光缆线路重装",
                                                             @"预约接单",
                                                             @"2019-05-13 09:06:30",
                                                             @"2019-05-10 09:07:30",
                                                             @"2019-05-11 09:06:30",
                                                             @"2019-05-12 12:06:30",],
                                                   },
                                                 @{@"id":@"JX-060-060-180410-1223956494",
                                                   @"title":@"宽带网络不稳定",
                                                   @"ordertype":@"跳纤工单",
                                                   @"date1":@"2019-05-10 09:06:30",
                                                   @"date2":@"2019-05-10 09:06:30",
                                                   @"date3":@"2019-05-10 09:06:30",
                                                   @"stauts":@"已接单未处理",
                                                   @"step":@"外线排查",
                                                   @"data":@[@"宽带网络不稳定",@"JX-060-060-180410-1223956494",
                                                             @"已接单未处理",
                                                             @"张师傅",
                                                             @"2019-05-10 09:06:30",
                                                             @"施工部",
                                                             @"省公司",
                                                             @"15526738485",
                                                             @"李工",
                                                             @"186526374856",
                                                             @"安装激活",
                                                             @"安装激活",
                                                             @"2019-05-13 09:06:30",
                                                             @"2019-05-12 09:06:30",
                                                             @"2019-05-12 09:06:30",
                                                             @"2019-05-12 12:06:30",],
                                                   },
                                               @{@"id":@"JX-060-060-180410-1223956494",
                                                   @"title":@"带宽不稳定",
                                                   @"ordertype":@"勘察工单",
                                                   @"date1":@"2019-05-10 09:06:30",
                                                   @"date2":@"2019-05-10 09:06:30",
                                                   @"date3":@"2019-05-13 09:06:30",
                                                   @"stauts":@"已接单",
                                                   @"step":@"转派",
                                                   @"data":@[@"带宽不稳定",@"JX-060-060-180410-1223956494",
                                                             @"已接单",
                                                             @"张师傅",
                                                             @"2019-05-10 09:06:30",
                                                             @"施工部",
                                                             @"省公司",
                                                             @"15526738485",
                                                             @"李工",
                                                             @"186526374856",
                                                             @"带宽不稳定",
                                                             @"工单转派",
                                                             @"2019-05-21 10:06:30",
                                                             @"2019-05-11 12:06:30",
                                                             @"2019-05-13 09:06:30",
                                                             @"苏杭东排查宽带问题",
                                                             @"江苏省",
                                                             @"苏州市"],
                                                   },
                                                 @{@"id":@"JX-060-060-180410-1223956494",
                                                   @"title":@"k光缆线路重装",
                                                   @"ordertype":@"勘察工单",
                                                   @"date1":@"2019-05-10 09:06:30",
                                                   @"date2":@"2019-05-10 09:06:30",
                                                   @"date3":@"2019-05-10 09:06:30",
                                                   @"stauts":@"已接单未处理",
                                                   @"step":@"预约接单",
                                                   @"data":@[@"k光缆线路重装",@"JX-060-060-180410-1223956494",
                                                             @"已接单未处理",
                                                             @"张师傅",
                                                             @"2019-05-10 09:06:30",
                                                             @"施工部",
                                                             @"省公司",
                                                             @"15526738485",
                                                             @"李工",
                                                             @"186526374856",
                                                             @"k光缆线路重装",
                                                             
                                                             @"2019-05-13 09:06:30",
                                                             @"2019-05-10 09:07:30",
                                                             @"2019-05-11 09:06:30",
                                                             
                                                             @"简单简单就xndnvndk",
                                                             @"湖南省",
                                                             @"长沙市"],
                                                   },
                                                 @{@"id":@"JX-060-060-180410-1223956494",
                                                   @"title":@"宽带网络不稳定",
                                                   @"ordertype":@"勘察工单",
                                                   @"date1":@"2019-05-10 09:06:30",
                                                   @"date2":@"2019-05-10 09:06:30",
                                                   @"date3":@"2019-05-10 09:06:30",
                                                   @"stauts":@"已接单未处理",
                                                   @"step":@"外线排查",
                                                   @"data":@[@"宽带网络不稳定",@"JX-060-060-180410-1223956494",
                                                             @"已接单未处理",
                                                             @"张师傅",
                                                             @"2019-05-10 09:06:30",
                                                             @"施工部",
                                                             @"省公司",
                                                             @"15526738485",
                                                             @"李工",
                                                             @"186526374856",
                                                             @"安装激活",
                                                             
                                                             @"2019-05-13 09:06:30",
                                                             @"2019-05-12 09:06:30",
                                                             @"2019-05-12 09:06:30",
                                                             
                                                             @"rjgdkg光猫问题",
                                                             @"寒冬省",
                                                             @"周元市"],
                                                   },
                                               @{@"id":@"JX-060-0440-180410-1hdddkk",
                                                   @"title":@"带宽不稳定",
                                                   @"ordertype":@"宽带配置工单",
                                                   @"date1":@"2019-05-10 09:06:30",
                                                   @"date2":@"2019-05-10 09:06:30",
                                                   @"date3":@"2019-05-13 09:06:30",
                                                   @"stauts":@"已接单",
                                                   @"step":@"转派",
                                                   @"data":@[@"带宽不稳定",@"JX-060-060-180410-1223956494",
                                                             @"已接单",
                                                             @"张师傅",
                                                             @"2019-05-10 09:06:30",
                                                             @"施工部",
                                                             @"省公司",
                                                             @"15526738485",
                                                             @"李工",
                                                             @"186526374856",
                                                             @"带宽不稳定", @"工单转派",
                                                             @"2019-05-23 09:06:30",
                                                             @"2019-05-11 09:06:30",
                                                             @"2019-05-18 09:06:30",
                                                             
                                                             @"外线排查宽带问题",
                                                             @"江西省",
                                                             @"赣州市"],
                                                   },
                                                 @{@"id":@"JX-060-060-180410-fff956494",
                                                   @"title":@"k光缆线路重装",
                                                   @"ordertype":@"宽带配置工单",
                                                   @"date1":@"2019-05-10 09:06:30",
                                                   @"date2":@"2019-05-10 09:06:30",
                                                   @"date3":@"2019-05-10 09:06:30",
                                                   @"stauts":@"已接单未处理",
                                                   @"step":@"预约接单",
                                                   @"data":@[@"k光缆线路重装",@"JX-060-060-180410-1223956494",
                                                             @"已接单未处理",
                                                             @"张师傅",
                                                             @"2019-05-10 09:06:30",
                                                             @"施工部",
                                                             @"省公司",
                                                             @"15526738485",
                                                             @"李工",
                                                             @"186526374856",
                                                             @"k光缆线路重装",
                                                             
                                                             @"2019-05-13 09:06:30",
                                                             @"2019-05-10 09:07:30",
                                                             
                                                             @"2019-05-12 12:06:30",
                                                             @"苏杭东排查宽带问题",
                                                             @"江苏省",
                                                             @"苏州市"],
                                                   },
                                                 @{@"id":@"JX-060-060-180410-1223956494",
                                                   @"title":@"宽带网络不稳定",
                                                   @"ordertype":@"宽带配置工单",
                                                   @"date1":@"2019-05-10 09:06:30",
                                                   @"date2":@"2019-05-10 09:06:30",
                                                   @"date3":@"2019-05-10 09:06:30",
                                                   @"stauts":@"已接单未处理",
                                                   @"step":@"外线排查",
                                                   @"data":@[@"宽带网络不稳定",@"JX-060-060-180410-1223956494",
                                                             @"已接单未处理",
                                                             @"张师傅",
                                                             @"2019-05-10 09:06:30",
                                                             @"施工部",
                                                             @"省公司",
                                                             @"15526738485",
                                                             @"李工",
                                                             @"186526374856",
                                                             @"安装激活",
                                                             
                                                             @"2019-05-13 09:06:30",
                                                             @"2019-05-12 09:06:30",
                                                             
                                                             @"2019-05-12 12:06:30",
                                                             @"新增宽带问题",
                                                             @"广东省",
                                                             @"广州市"],
                                                   },
                                               
                                               
                                               
                                               
                                               
                                               ]];
        [_leftOrderTableView reloadData];
    }
}





- (void)createUI {
    _scrollContentViewConstraints.constant = kScreenW ;
    _scrollView.contentSize=CGSizeMake(kViewCount*_scrollView.bounds.size.width, 0);
    _leftOrderTableView.delegate =self;
    _leftOrderTableView.dataSource = self;
    _leftOrderTableView.rowHeight = UITableViewAutomaticDimension;
    _leftOrderTableView.estimatedRowHeight = 142;
   self.leftOrderTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
   
}

#pragma mark - UITableView
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
        
        return [_leftDataSource count];
    
}

-(UITableViewCell*) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    

        JXEOMSCell *cell = [JXEOMSCell initCellWithTableView:tableView];
        if(_leftDataSource.count!=0 && _leftDataSource!=NULL){
            NSDictionary *dict=[_leftDataSource objectAtIndex:indexPath.row];
            _orderType=isnull(@"ordertype", dict);
            cell.orderType = _orderType;
        
            cell.model = [_leftDataSource objectAtIndex:indexPath.row];
        }
        
        return cell;
    
}

-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath  {
    
    JXEOMSDetailViewController *vc=[JXEOMSDetailViewController new];
    vc.orderType=_orderType;
    vc.leftdata=_leftDataSource[indexPath.row][@"data"];
    vc.dict=_leftDataSource[indexPath.row];
    [self pushViewController:vc];
    
    
}



@end
