//
//  JXMyOrderViewController.h
//  JXWWNOP
//
//  Created by hqf on 2017/6/20.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//

#import "MTBaseViewController.h"



#define kViewCount 1

@interface JXEMOSViewController : MTBaseViewController<UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource>



@property (nonatomic ,strong) NSString  *naviTitle;

@property (nonatomic ,strong) NSString *orderType;  //工单类型  PnrFamilyBackOut 拆机,PnrFamilyBroadband 装机,PnrFamilyBespeak,预约,PnrFamilyComplaint 投诉
@property (nonatomic ,strong) NSString *isMutil;    //请求所有接口标志 0 失效  1 一次性请求所有工单类型接口 2 和1相同，但是每个类型只请求一条或0条数据

@property (nonatomic ,strong) NSString  *district; //地市
@property (nonatomic ,strong) NSString  *task_name;//处理环节

@end
