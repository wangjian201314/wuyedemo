//
//  ToolsViewController.m
//  Health
//
//  Created by Mac on 2019/5/22.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "ToolsViewController.h"
#import "HealthCollectionViewCell.h"
#import "JXTempMainViewCell.h"
#import <MJRefresh.h>
#import "JXEMOSViewController.h"
@interface ToolsViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate,UIAlertViewDelegate>{
    
    UICollectionViewFlowLayout *flowLayout_;
    NSMutableArray *_textArr;//mid
    NSMutableArray *_imgArr; //mid
    NSArray *_imageArr;//top
    NSArray *_textDataArr;
    
}
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *collectionHeight;
@property (strong, nonatomic) UIScrollView *scrollerview;
@property (strong, nonatomic) UIPageControl *pagectl;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionview;
@property (weak, nonatomic) IBOutlet UITableView *mytableview;

//@property(strong,nonatomic)NSArray *imageArray;//lower
//@property(strong,nonatomic)NSArray *nameLabArray;//lower
//@property(strong,nonatomic)NSArray *titleLabArray;//lower
//@property(strong,nonatomic)NSArray *urlArray;


@end

@implementation ToolsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _imgArr=[NSMutableArray array];
    _textArr=[NSMutableArray array];
    [self setNaviTitle:@"首页" leftButtonShow:NO rightButtom:nil];
    [_textArr addObjectsFromArray :@[@{@"id":@"JX-060-060-180410-1223956494",
                 @"date":@"2019-05-10 09:06:30",
                 @"抢单标识":@"已接单",
                 @"推送标识":@(1),
                 @"color":@"#66CDAA",
                 },
               @{@"id":@"JX-060-060-180410-1223956494",
                 @"date":@"2019-05-10 09:06:30",
                 @"抢单标识":@"已接单",
                 @"推送标识":@(2),
                 @"color":@"#66CDAA",
                 },
               @{@"id":@"JX-060-060-180410-1223956494",
                 @"date":@"2019-05-10 09:06:30",
                 @"抢单标识":@"未接单",
                 @"推送标识":@(1),
                 @"color":@"#FF0000",
                 },
               @{@"id":@"JX-060-060-180410-1223956494",
                 @"date":@"2019-05-10 09:06:30",
                 @"抢单标识":@"未接单",
                 @"推送标识":@(3),
                 @"color":@"#FF0000",
                 },
               @{@"id":@"JX-060-060-180410-1223956494",
                 @"date":@"2019-05-10 09:06:30",
                 @"抢单标识":@"未接单",
                 @"推送标识":@(1),
                 @"color":@"#FF0000",
                 }]];
   [ _imgArr addObjectsFromArray: @[@"Group 20 Copy 2",@"Group 20 Copy 2",@"Group 20",@"Group 20",@"Group 20"]];
    [SVProgressHUD showWithStatus:@"正在加载..."];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        [self setUpData];
        //    [self setUIScrollerview];
        [self initCollectionView];
        
        id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
        if([namestr isEqualToString:@"15976070261"]){
            [self setUITableview];
        }else{
            [SVProgressHUD showErrorWithStatus:@"暂无抢单数据!"];
        }
    });
    
    
}

//初始化数据
-(void)setUpData{
    
    _textDataArr= @[@"装机工单",@"拆机工单",@"预约工单",@"投诉工单",@"跳纤工单",@"勘察工单",@"宽带配置工单",@"我的工单"];
    _imageArr=@[@"chaiji_icon",@"kancha_icon",@"kancha",@"kanchazi",@"tiaoxian_icon",@"tousu_icon",@"yuyue_icon",@"wode_icon"];
}

//- (void)setUIScrollerview{
//
//
//    self.scrollerview=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, kScreenW, 200)];
//    [self.view addSubview:self.scrollerview];
//    self.pagectl=[[UIPageControl alloc]initWithFrame:CGRectMake((kScreenW-80)/2, 180, 80, 20)];
//    self.pagectl.numberOfPages=3;
//    self.pagectl.currentPageIndicatorTintColor=[UIColor redColor];
//    [self.view addSubview:self.pagectl];
//    self.scrollerview.contentSize=CGSizeMake(kScreenW*_imageArr.count, 0);
//    _pagectl.numberOfPages=_imageArr.count;
//    self.scrollerview.delegate=self;
//    [self.scrollerview setPagingEnabled:YES];
//    [self.scrollerview setDelegate:self];
//    [self.scrollerview setBounces:NO];
//    [self.scrollerview setUserInteractionEnabled:YES];
//    [self.scrollerview setShowsHorizontalScrollIndicator:NO];
//    [self.scrollerview setShowsVerticalScrollIndicator:NO];
//    for(int i=0;i<_imageArr.count;i++){
//
//        UIImageView *img=[[UIImageView alloc]initWithFrame:CGRectMake(i*kScreenW, 0, kScreenW, 200)];
//        [img sd_setImageWithURL:[NSURL URLWithString:_imageArr[i]] placeholderImage:nil options:SDWebImageRefreshCached];
//        img.userInteractionEnabled=YES;
//        UIButton *btn=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, kScreenW, kScHeight)];
//        [img addSubview:btn];
//        btn.tag=10+i;
//        [btn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
//        [self.scrollerview addSubview:img];
//    }
//}

- (void)setUITableview{
    
    self.mytableview.delegate=self;
    self.mytableview.dataSource=self;
    [self.mytableview registerNib:[UINib nibWithNibName:@"JXTempMainViewCell" bundle:nil] forCellReuseIdentifier:@"JXTempMainViewCell"];
    self.mytableview.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
//    self.mytableview.mj_header = [MJRefreshGifHeader  headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
//    [self.mytableview.mj_header beginRefreshing];
}

- (void)headerRefresh{
    
    [self.mytableview.mj_header endRefreshing];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self setUpData];
    });
}
#pragma mark - ---------- 初始化CollectionView ----------
- (void)initCollectionView {
    flowLayout_ = [[UICollectionViewFlowLayout alloc] init];
    [flowLayout_ setScrollDirection:UICollectionViewScrollDirectionVertical];
    self.collectionview.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.collectionview.showsHorizontalScrollIndicator = NO;
    self.collectionview.delaysContentTouches = YES;
    self.collectionview.pagingEnabled = NO;
    [self.collectionview setDataSource:self];
    [self.collectionview setDelegate:self];
    self.collectionview.backgroundColor=[UIColor whiteColor];
    self.collectionHeight.constant=kScWidth/4*2;
    [self.collectionview registerNib:[UINib nibWithNibName:@"HealthCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"HealthCollectionViewCell"];
  
}

#pragma mark--
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    _pagectl.currentPage=scrollView.contentOffset.x/kScreenW;
}

//设置每个item的尺寸
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
   
        return CGSizeMake(kScWidth/4, kScWidth/4);
    
}

//设置每个item的UIEdgeInsets
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0,0,0,0);
}

//设置每个item水平间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}


//设置每个item垂直间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
    
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return _textDataArr.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    HealthCollectionViewCell *cell = (HealthCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"HealthCollectionViewCell" forIndexPath:indexPath];
        cell.textlb.text=_textDataArr[indexPath.row];
        cell.imgview.image=[UIImage imageNamed:_imageArr[indexPath.row]];

    return cell;
}


#pragma mark - ---------- 每个Cell的点击事件 ----------
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if(indexPath.row==7){
        self.tabBarController.selectedIndex=1;
    }else{
        JXEMOSViewController *vc=[JXEMOSViewController new];
        vc.orderType=_textDataArr[indexPath.row];
        [self pushViewController:vc];
    }
    
    
}

#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _textArr.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 100.f;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"JXTempMainViewCell";
    
    JXTempMainViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil) {
        cell = [[JXTempMainViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    NSDictionary *dict=_textArr[indexPath.row];
    cell.imgView.image = [UIImage imageNamed:_imgArr[indexPath.row]];
    cell.label0.text =[NSString stringWithFormat:@"工单号:%@",dict[@"id"]];
    cell.label1.text =[NSString stringWithFormat:@"抢单时限:%@",dict[@"date"]];
    cell.bottomlb.text=[NSString stringWithFormat:@"推送标识:第%zd波推送",[dict[@"推送标识"] integerValue]];
    cell.detailLb.textColor = [UIColor colorWithHexString:dict[@"color"]];
    cell.detailLb.text = dict[@"抢单标识"];
    
    return cell;
}

#pragma mark - UITableView Delegate methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UIAlertView *alterview=[[UIAlertView alloc]initWithTitle:@"提示" message:@"是否确定抢单" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:@"取消", nil];
    alterview.delegate=self;
    alterview.tag=10+indexPath.row;
    [alterview show];
   
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    NSMutableDictionary *dict=[NSMutableDictionary dictionaryWithDictionary:_textArr[alertView.tag-10]];
    if(buttonIndex==0){
        if(![dict[@"抢单标识"] isEqualToString:@"已接单"]){
            [dict setObject:@"已接单" forKey:@"抢单标识"];
            [dict setObject:@"#66CDAA" forKey:@"color"];
            [_textArr replaceObjectAtIndex:alertView.tag-10 withObject:dict];
            [_imgArr replaceObjectAtIndex:alertView.tag-10 withObject:@"Group 20 Copy 2"];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.mytableview reloadData];
            });
//            [SVProgressHUD showSuccessWithStatus:@"抢单成功!"];
            [[[UIToastView alloc]initWithTitle:@"抢单成功!"]show];
        }else{
            dispatch_async(dispatch_get_main_queue(), ^{
                [[[UIToastView alloc]initWithTitle:@"该工单已被抢!"]show];
            });
            
        }
        
    }
}
- (void)click:(UIButton *)sender{
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
