//
//  AppDelegate.m
//  Attendance
//
//  Created by Mac on 2019/5/20.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "AppDelegate.h"
#import "MTTabBarController.h"
#import <IQKeyboardManager.h>
#import "LoginViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    [self.window makeKeyAndVisible];
    [[IQKeyboardManager sharedManager] setEnable:YES];
    NSNumber * autLogin = [[NSUserDefaults standardUserDefaults] objectForKey:@"autologin"];
    NSLog(@"%@",autLogin);
    if(autLogin && [autLogin isEqual:@(1)]){
        MTTabBarController *tabBarController = [[MTTabBarController alloc]init];
        self.window.rootViewController = tabBarController;
        
    }else{
        LoginViewController *tabBarController = [[LoginViewController alloc]init];
        self.window.rootViewController = tabBarController;
    }
    self.window.backgroundColor = [UIColor whiteColor];
    
    
    return YES;
}


@end
