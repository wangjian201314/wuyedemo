//
//  FacebackViewController.m
//  Compass
//
//  Created by Mac on 2019/5/7.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "FacebackViewController.h"
#import "UITextView+Placeholder.h"
@interface FacebackViewController ()
@property (weak, nonatomic) IBOutlet UIButton *buttob;
@property (weak, nonatomic) IBOutlet UITextView *textview;

@end

@implementation FacebackViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setNaviTitle:@"意见反馈" leftButtonShow:YES rightButtom:nil];
    _buttob.layer.cornerRadius = 5.0;
//    _buttob.layer.borderColor = [UIColor darkGrayColor].CGColor;
//    _buttob.layer.borderWidth = 1;
    _buttob.layer.masksToBounds = YES;
    self.textview.layer.cornerRadius = 5.0;
    self.textview.layer.borderColor = [UIColor colorWithHexString:@"#4994F4"].CGColor;
    self.textview.layer.borderWidth = 1;
    self.textview.layer.masksToBounds = YES;
    [_textview setPlaceHolder:@"请输入反馈意见信息。。。"];
    // Do any additional setup after loading the view from its nib.
}
- (IBAction)faceback:(UIButton *)sender {
    
    if([self.textview.text isEqualToString:@""] || self.textview.text.length==0){
        [SVProgressHUD showWithStatus:@"Submit the content cannot be empty"];
         dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [SVProgressHUD dismiss];
        });
        return;
    }
    [SVProgressHUD showWithStatus:@"Submitting"];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        [SVProgressHUD showSuccessWithStatus:@"Submitted successfully"];
    });
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
