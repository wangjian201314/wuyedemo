//
//  MyViewController.m
//  Broadband
//
//  Created by Mac on 2019/5/20.
//  Copyright © 2019年 Mac. All rights reserved.
//
#import "UIImage+Exction.h"
#import "MyViewController.h"
#import "MyTableViewCell.h"
#import "FacebackViewController.h"
#import "ModifyPWDViewController.h"
#import "LoginViewController.h"
#import "AppDelegate.h"
@interface MyViewController ()<UITableViewDelegate,UITableViewDataSource>{
    
    NSArray *_imgdata;
    NSArray *_datasource;
}
@property (weak, nonatomic) IBOutlet UITableView *mytableView;
@property (weak, nonatomic) IBOutlet UILabel *companylb;
@property (weak, nonatomic) IBOutlet UIImageView *headimg;

@end

@implementation MyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
   
    [self setNaviTitle:@"我的" leftButtonShow:NO rightButtom:nil];
    _imgdata=@[@"me_pwd",@"me_setup",@"me_update",@"me_about"];
    _datasource=@[@"修改密码",@"我的工单",@"意见反馈",@"退出"];
    _mytableView.delegate=self;
    _mytableView.dataSource=self;
//    _mytableView.estimatedRowHeight=200;
    _mytableView.showsVerticalScrollIndicator=NO;
    _mytableView.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    [self.view addSubview:_mytableView];
    [_mytableView registerNib:[UINib nibWithNibName:@"MyTableViewCell" bundle:nil] forCellReuseIdentifier:@"MyTableViewCell"];
    
    id companystr=[[NSUserDefaults standardUserDefaults]objectForKey:@"company"];
    if(companystr){
        _companylb.text=[NSString stringWithFormat:@"所属公司名称:%@",companystr];
    }
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(recognize)];
    NSString *path=[[ NSSearchPathForDirectoriesInDomains ( NSDocumentDirectory , NSUserDomainMask , YES ) firstObject ]stringByAppendingPathComponent:@"headimg"];
    NSData *imgdata=[NSData dataWithContentsOfFile:path];
    if(imgdata){
        self.headimg.image=[UIImage imageWithData:[NSData dataWithContentsOfFile:path]];
        self.headimg.image= [self.headimg.image circleImage];
    }
    
    [self.headimg addGestureRecognizer:tap];
}

#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _datasource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    MyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyTableViewCell"];
    
    if(cell == nil) {
        cell = [[MyTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyTableViewCell"];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    cell.imgview.image=[UIImage imageNamed:_imgdata[indexPath.row]];
    cell.textlb.text=_datasource[indexPath.row];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 50;
}
#pragma mark - UITableView Delegate methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row) {
        case 0:{
            
            
            ModifyPWDViewController *vc=[ModifyPWDViewController new];
            [self pushViewController:vc];
        }
            
            break;
        case 1:{
            
            self.tabBarController.selectedIndex=1;
//            RecentlyViewController *vc=[RecentlyViewController new];
//            [self pushViewController:vc];
        }
            
            break;
        
        case 2:{
            FacebackViewController *vc=[FacebackViewController new];
            [self pushViewController:vc];
        }
            
            break;
        case 3:{
            [SVProgressHUD showWithStatus:@"退出登录..."];
             dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [SVProgressHUD dismiss];
                LoginViewController *vc=[LoginViewController new];
                AppDelegate *delegate=(AppDelegate *)[UIApplication sharedApplication].delegate;
                delegate.window.rootViewController = vc;
                [[NSUserDefaults standardUserDefaults]setObject:@(0) forKey:@"autologin"];
                
            });
        }
            
            break;
            
        default:
            break;
    }
    
}

#pragma mark--更换头像
- (void)recognize{
    
    UIActionSheet *sheet=[[UIActionSheet alloc]initWithTitle:@"" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"拍照" otherButtonTitles:@"从相册选择", nil];
    sheet.delegate=self;
    [sheet showInView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    UIImagePickerControllerSourceType sourcetape=UIImagePickerControllerSourceTypeCamera;
    //    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){

    switch (buttonIndex) {
        case 0:
            sourcetape=UIImagePickerControllerSourceTypeCamera;
            break;
        case 1:
            sourcetape=UIImagePickerControllerSourceTypePhotoLibrary;
            break;
        case 2:
            
            return;
            break;
        default:
            break;
    }
    
    //    }
    UIImagePickerController  *imagepicker=[[UIImagePickerController alloc]init];
    imagepicker.delegate=self;
    imagepicker.allowsEditing=YES;
    imagepicker.sourceType=sourcetape;
    [self presentViewController:imagepicker animated:NO completion:nil];
    
}
- ( void )imagePickerController:( UIImagePickerController *)picker didFinishPickingMediaWithInfo:( NSDictionary *)info{
    
    [picker dismissViewControllerAnimated:NO completion:nil];
    UIImage *image=[info objectForKey:UIImagePickerControllerEditedImage];
    self.headimg.image=[image circleImage];
    [self saveImage:image withname:@"headimg"];
}

- (void)saveImage:(UIImage *)img withname:(NSString *)name{
    
    NSData *imgdata=UIImageJPEGRepresentation(img, 0.5);
    NSString *path=[[ NSSearchPathForDirectoriesInDomains ( NSDocumentDirectory , NSUserDomainMask , YES ) firstObject ]stringByAppendingPathComponent:name];
    BOOL ishave= [imgdata writeToFile:path atomically:NO];
    if(ishave){
        
    }
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
